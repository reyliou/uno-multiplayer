# UNO Multiplayer - Full Source Code Package

> Generated for AI prompt / code review. Contains the entire architecture, game engine, P2P networking, and UI components.

## Table of Contents

1. [package.json](#package-json)
2. [vite.config.js](#vite-config-js)
3. [vercel.json](#vercel-json)
4. [index.html](#index-html)
5. [src/main.jsx](#src-main-jsx)
6. [src/App.jsx](#src-app-jsx)
7. [src/index.css](#src-index-css)
8. [src/App.css](#src-app-css)
9. [src/game/unoEngine.js](#src-game-unoengine-js)
10. [src/game/unoAi.js](#src-game-unoai-js)
11. [src/services/p2p.js](#src-services-p2p-js)
12. [src/services/sound.js](#src-services-sound-js)
13. [src/services/animation.js](#src-services-animation-js)
14. [src/components/HomeView.jsx](#src-components-homeview-jsx)
15. [src/components/LobbyView.jsx](#src-components-lobbyview-jsx)
16. [src/components/GameTableView.jsx](#src-components-gametableview-jsx)
17. [src/components/CardView.jsx](#src-components-cardview-jsx)
18. [src/components/VictoryModal.jsx](#src-components-victorymodal-jsx)

---

## package.json

`json
{
  "name": "uno-multiplayer",
  "private": true,
  "version": "0.0.0",
  "type": "module",
  "scripts": {
    "dev": "vite",
    "build": "vite build",
    "lint": "oxlint",
    "preview": "vite preview"
  },
  "dependencies": {
    "@tailwindcss/vite": "^4.3.3",
    "canvas-confetti": "^1.9.4",
    "lucide-react": "^1.55.0",
    "peerjs": "^1.5.5",
    "react": "^19.2.8",
    "react-dom": "^19.2.8",
    "tailwindcss": "^4.3.3"
  },
  "devDependencies": {
    "@types/react": "^19.2.18",
    "@types/react-dom": "^19.2.7",
    "@vitejs/plugin-react": "^6.1.1",
    "oxlint": "^1.81.0",
    "vite": "^8.3.0"
  }
}

`

---

## vite.config.js

`javascript
import { defineConfig } from 'vite'
import react from '@vitejs/plugin-react'
import tailwindcss from '@tailwindcss/vite'

// https://vite.dev/config/
export default defineConfig({
  plugins: [
    tailwindcss(),
    react()
  ],
})

`

---

## vercel.json

`json
{
  "rewrites": [
    {
      "source": "/(.*)",
      "destination": "/index.html"
    }
  ]
}

`

---

## index.html

`html
<!doctype html>
<html lang="zh-TW">
  <head>
    <meta charset="UTF-8" />
    <link rel="icon" type="image/svg+xml" href="/cards_modern/wild.svg" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=no, viewport-fit=cover" />
    <title>UNO! 線上多人對戰 (P2P Host-Authoritative)</title>
  </head>
  <body class="bg-[#07170e] text-white">
    <div id="root"></div>
    <script type="module" src="/src/main.jsx"></script>
  </body>
</html>

`

---

## src/main.jsx

`javascript
import { StrictMode } from 'react'
import { createRoot } from 'react-dom/client'
import './index.css'
import App from './App.jsx'

createRoot(document.getElementById('root')).render(
  <StrictMode>
    <App />
  </StrictMode>,
)

`

---

## src/App.jsx

`javascript
// App.jsx - Main UNO Multiplayer Application
import React, { useState, useEffect } from 'react';
import { HomeView } from './components/HomeView';
import { LobbyView } from './components/LobbyView';
import { GameTableView } from './components/GameTableView';
import { VictoryModal } from './components/VictoryModal';
import { p2pNetwork } from './services/p2p';
import { AlertCircle, X } from 'lucide-react';

export default function App() {
  const [view, setView] = useState('home'); // 'home' | 'lobby' | 'game'
  const [isHost, setIsHost] = useState(false);
  const [roomCode, setRoomCode] = useState('');
  const [lobbyPlayers, setLobbyPlayers] = useState([]);
  const [allowStacking, setAllowStacking] = useState(true);
  const [allowChallengeWildDraw4, setAllowChallengeWildDraw4] = useState(true);
  const [gameMode, setGameMode] = useState('ffa'); // 'ffa' | '2v2'
  const [targetScore, setTargetScore] = useState(500); // 0 = casual/no score limit
  const [drawRule, setDrawRule] = useState('draw_one'); // 'draw_one' | 'draw_until_playable'
  const [gameState, setGameState] = useState(null);
  const [errorMessage, setErrorMessage] = useState('');

  // Register P2P network event listeners (only on mount)
  useEffect(() => {
    p2pNetwork.onLobbyUpdate = (data) => {
      setLobbyPlayers([...data.players]);
      setAllowStacking(data.allowStacking);
      if (data.allowChallengeWildDraw4 !== undefined) setAllowChallengeWildDraw4(data.allowChallengeWildDraw4);
      setGameMode(data.gameMode || 'ffa');
      setRoomCode(data.roomCode);
      if (data.targetScore !== undefined) setTargetScore(data.targetScore);
      if (data.drawRule) setDrawRule(data.drawRule);
      setView((prev) => (prev === 'home' ? 'lobby' : prev));
    };

    p2pNetwork.onStateUpdate = (state) => {
      setGameState({ ...state });
      setView((prev) => (prev !== 'game' ? 'game' : prev));
    };

    p2pNetwork.onReturnToLobby = (data) => {
      if (data && data.players) setLobbyPlayers([...data.players]);
      if (data && data.allowChallengeWildDraw4 !== undefined) setAllowChallengeWildDraw4(data.allowChallengeWildDraw4);
      if (data && data.targetScore !== undefined) setTargetScore(data.targetScore);
      if (data && data.drawRule) setDrawRule(data.drawRule);
      setView('lobby');
    };

    p2pNetwork.onRoomDisbanded = (reason) => {
      setErrorMessage(reason || '房主已解散房間！');
      setGameState(null);
      setLobbyPlayers([]);
      setView('home');
      window.location.hash = '';
      setTimeout(() => setErrorMessage(''), 5000);
    };

    p2pNetwork.onError = (msg) => {
      setErrorMessage(msg);
      setTimeout(() => setErrorMessage(''), 5000);
    };

    return () => {
      p2pNetwork.disconnect();
    };
  }, []);

  // Auto-disband room if host closes window/tab or refreshes
  useEffect(() => {
    const handleBeforeUnload = () => {
      if (isHost && p2pNetwork.isHost) {
        p2pNetwork.disbandRoom('房主已關閉頁面，房間已自動解散！');
      }
    };
    window.addEventListener('beforeunload', handleBeforeUnload);
    return () => {
      window.removeEventListener('beforeunload', handleBeforeUnload);
    };
  }, [isHost]);

  // Host creates room
  const handleCreateRoom = (code, hostName, stacking, mode = 'ffa') => {
    setIsHost(true);
    setRoomCode(code);
    setAllowStacking(stacking);
    setGameMode(mode);
    p2pNetwork.createRoom(code, hostName, stacking, mode);
    setView('lobby');
  };

  // Guest joins room
  const handleJoinRoom = (code, guestName) => {
    setIsHost(false);
    setRoomCode(code);
    p2pNetwork.joinRoom(code, guestName);
    setView('lobby');
  };

  // Host starts game
  const handleStartGame = () => {
    p2pNetwork.startGame();
  };

  // Host restarts game
  const handleRestartGame = () => {
    p2pNetwork.restartGame();
  };

  // Toggle slot AI (Host only)
  const handleToggleAi = (slotIndex) => {
    p2pNetwork.toggleSlotAi(slotIndex);
  };

  // Toggle stacking rule (Host only)
  const handleToggleStacking = () => {
    p2pNetwork.toggleStackingRule();
  };

  // Toggle challenge wild draw 4 rule (Host only)
  const handleToggleChallengeRule = () => {
    p2pNetwork.toggleChallengeRule();
  };

  // Set target score (Host only)
  const handleSetTargetScore = (score) => {
    setTargetScore(score);
    p2pNetwork.setTargetScore(score);
  };

  // Set draw rule (Host only)
  const handleSetDrawRule = (rule) => {
    setDrawRule(rule);
    p2pNetwork.setDrawRule(rule);
  };

  // Start next round (Host only)
  const handleNextRound = (resetMatch = false) => {
    p2pNetwork.startNextRound(resetMatch);
  };

  // Return to lobby from game (Host only)
  const handleReturnToLobby = () => {
    p2pNetwork.returnToLobby();
    setView('lobby');
  };

  // Set game mode (Host only)
  const handleSetGameMode = (mode) => {
    setGameMode(mode);
    p2pNetwork.setGameMode(mode);
  };

  // Set FFA player count (Host only)
  const handleSetFfaCount = (count) => {
    p2pNetwork.setFfaPlayerCount(count);
  };

  // Swap slots (Host only)
  const handleSwapSlots = (idxA, idxB) => {
    p2pNetwork.swapSlots(idxA, idxB);
  };

  // Leave or disband room
  const handleLeaveRoom = () => {
    if (isHost) {
      p2pNetwork.disbandRoom('房主已解散房間！');
    } else {
      p2pNetwork.disconnect();
    }
    setGameState(null);
    setLobbyPlayers([]);
    setView('home');
    window.location.hash = '';
  };

  // Game actions
  const handlePlayCard = (cardId, chosenColor, calledUno) => {
    if (isHost) {
      p2pNetwork.hostPlayCard(cardId, chosenColor, calledUno);
    } else {
      p2pNetwork.clientPlayCard(cardId, chosenColor, calledUno);
    }
  };

  const handleDrawCard = () => {
    if (isHost) {
      p2pNetwork.hostDrawCard();
    } else {
      p2pNetwork.clientDrawCard();
    }
  };

  const handlePassTurn = () => {
    if (isHost) {
      p2pNetwork.hostPassTurn();
    } else {
      p2pNetwork.clientPassTurn();
    }
  };

  const handleCallUno = () => {
    if (isHost) {
      p2pNetwork.hostCallUno();
    } else {
      p2pNetwork.clientCallUno();
    }
  };

  const handleChallengeUno = (targetIndex) => {
    if (isHost) {
      p2pNetwork.hostChallengeUno(targetIndex);
    } else {
      p2pNetwork.clientChallengeUno(targetIndex);
    }
  };

  const handleChallengeWildDraw4 = () => {
    if (isHost) {
      p2pNetwork.hostChallengeWildDraw4();
    } else {
      p2pNetwork.clientChallengeWildDraw4();
    }
  };

  const handleChooseColor = (chosenColor) => {
    if (isHost) {
      p2pNetwork.hostChooseColor(chosenColor);
    } else {
      p2pNetwork.clientChooseColor(chosenColor);
    }
  };

  return (
    <div className="relative min-h-[100dvh]">
      {/* Global Toast Notification */}
      {errorMessage && (
        <div className="fixed top-4 left-1/2 -translate-x-1/2 z-50 flex items-center gap-2 px-4 py-2.5 rounded-xl bg-red-600 text-white text-xs sm:text-sm font-bold shadow-2xl animate-bounce">
          <AlertCircle className="w-4 h-4 shrink-0" />
          <span>{errorMessage}</span>
          <button
            type="button"
            onClick={() => setErrorMessage('')}
            className="p-1 hover:bg-white/20 rounded"
          >
            <X className="w-3.5 h-3.5" />
          </button>
        </div>
      )}

      {/* Screen Router */}
      {view === 'home' && (
        <HomeView
          onCreateRoom={handleCreateRoom}
          onJoinRoom={handleJoinRoom}
        />
      )}

      {view === 'lobby' && (
        <LobbyView
          roomCode={roomCode}
          isHost={isHost}
          players={lobbyPlayers}
          gameMode={gameMode}
          allowStacking={allowStacking}
          allowChallengeWildDraw4={allowChallengeWildDraw4}
          targetScore={targetScore}
          drawRule={drawRule}
          onToggleAi={handleToggleAi}
          onToggleStacking={handleToggleStacking}
          onToggleChallengeRule={handleToggleChallengeRule}
          onSetTargetScore={handleSetTargetScore}
          onSetDrawRule={handleSetDrawRule}
          onSetGameMode={handleSetGameMode}
          onSetFfaCount={handleSetFfaCount}
          onSwapSlots={handleSwapSlots}
          onStartGame={handleStartGame}
          onLeaveRoom={handleLeaveRoom}
        />
      )}

      {view === 'game' && gameState && (
        <GameTableView
          gameState={gameState}
          roomCode={roomCode}
          isHost={isHost}
          onPlayCard={handlePlayCard}
          onChooseColor={handleChooseColor}
          onDrawCard={handleDrawCard}
          onPassTurn={handlePassTurn}
          onCallUno={handleCallUno}
          onChallengeUno={handleChallengeUno}
          onChallengeWildDraw4={handleChallengeWildDraw4}
          onLeaveRoom={handleLeaveRoom}
        />
      )}

      {/* Victory Celebration Modal */}
      {view === 'game' && gameState && gameState.gameStatus === 'game_over' && (
        <VictoryModal
          winner={gameState.winner}
          isHost={isHost}
          players={gameState.players}
          targetScore={gameState.targetScore}
          isMatchOver={gameState.isMatchOver}
          matchWinner={gameState.matchWinner}
          lastRoundPoints={gameState.lastRoundPoints}
          onNextRound={() => handleNextRound(false)}
          onReturnToLobby={handleReturnToLobby}
          onRestart={() => handleNextRound(true)}
          onLeave={handleLeaveRoom}
        />
      )}
    </div>
  );
}

`

---

## src/index.css

`css
@import "tailwindcss";

@layer base {
  :root {
    --felt-bg: #072012;
    --felt-surface: #0f3e22;
    --felt-border: rgba(255, 255, 255, 0.12);
    --gold: #f4c430;
    --gold-hover: #e0b020;
    --card-shadow: 0 16px 32px rgba(0,0,0,0.5), 0 10px 10px rgba(0,0,0,0.3);
  }

  body {
    margin: 0;
    padding: 0;
    background-color: #041209;
    color: #e6f4ea;
    font-family: -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, "Helvetica Neue", Arial, sans-serif;
    user-select: none;
    -webkit-font-smoothing: antialiased;
    overflow-x: hidden;
  }
}

/* Casino Felt Outer Background */
.felt-table {
  background-color: #041209;
}

/* Classic UNO Game Arena Table Surface (From Screenshot) */
.table-surface {
  width: 100%;
  max-width: 1240px;
  height: min(860px, calc(100dvh - 64px));
  min-height: 580px;
  border-radius: 40px;
  background: radial-gradient(ellipse at center, rgba(28, 92, 48, 0.95) 0%, rgba(13, 48, 25, 0.98) 60%, rgba(5, 22, 11, 1) 100%);
  border: 7px solid #281a0e;
  box-shadow: 
    inset 0 0 70px rgba(0, 0, 0, 0.75),
    0 16px 48px rgba(0, 0, 0, 0.85),
    0 0 0 2px rgba(244, 196, 48, 0.25);
  display: flex;
  flex-direction: column;
  justify-content: space-between;
  padding: 16px 24px;
  position: relative;
  overflow: visible;
}

/* Active Turn Pill Ring */
.active-turn-ring {
  border-color: #f4c430 !important;
  background: rgba(30, 65, 38, 0.95) !important;
  box-shadow: 0 0 18px rgba(244, 196, 48, 0.65), 0 4px 12px rgba(0, 0, 0, 0.5) !important;
}

/* Card Landing Impact Bounce */
@keyframes impact-bounce {
  0% { transform: scale(1); }
  40% { transform: scale(1.08) rotate(-2deg); }
  100% { transform: scale(1); }
}
.impact-bounce {
  animation: impact-bounce 0.28s cubic-bezier(0.18, 0.89, 0.32, 1.28);
}

/* Skip Card Impact Shake */
@keyframes skip-shake {
  0%, 100% { transform: translateX(0); }
  20%, 60% { transform: translateX(-6px) rotate(-3deg); }
  40%, 80% { transform: translateX(6px) rotate(3deg); }
}
.skip-shake {
  animation: skip-shake 0.45s cubic-bezier(0.36, 0.07, 0.19, 0.97) both;
}

/* UNO Alert Pulse */
@keyframes uno-pulse {
  0%, 100% {
    transform: scale(1);
    box-shadow: 0 0 20px rgba(239, 68, 68, 0.6);
  }
  50% {
    transform: scale(1.06);
    box-shadow: 0 0 35px rgba(239, 68, 68, 0.95);
  }
}
.uno-alert-btn {
  animation: uno-pulse 1.1s infinite ease-in-out;
}

/* Custom Scrollbar */
::-webkit-scrollbar {
  width: 6px;
  height: 6px;
}
::-webkit-scrollbar-track {
  background: rgba(0, 0, 0, 0.2);
}
::-webkit-scrollbar-thumb {
  background: rgba(255, 255, 255, 0.2);
  border-radius: 3px;
}

`

---

## src/App.css

`css
.counter {
  font-size: 16px;
  padding: 5px 10px;
  border-radius: 5px;
  color: var(--accent);
  background: var(--accent-bg);
  border: 2px solid transparent;
  transition: border-color 0.3s;
  margin-bottom: 24px;

  &:hover {
    border-color: var(--accent-border);
  }
  &:focus-visible {
    outline: 2px solid var(--accent);
    outline-offset: 2px;
  }
}

.hero {
  position: relative;

  .base,
  .framework,
  .vite {
    inset-inline: 0;
    margin: 0 auto;
  }

  .base {
    width: 170px;
    position: relative;
    z-index: 0;
  }

  .framework,
  .vite {
    position: absolute;
  }

  .framework {
    z-index: 1;
    top: 34px;
    height: 28px;
    transform: perspective(2000px) rotateZ(300deg) rotateX(44deg) rotateY(39deg)
      scale(1.4);
  }

  .vite {
    z-index: 0;
    top: 107px;
    height: 26px;
    width: auto;
    transform: perspective(2000px) rotateZ(300deg) rotateX(40deg) rotateY(39deg)
      scale(0.8);
  }
}

#center {
  display: flex;
  flex-direction: column;
  gap: 25px;
  place-content: center;
  place-items: center;
  flex-grow: 1;

  @media (max-width: 1024px) {
    padding: 32px 20px 24px;
    gap: 18px;
  }
}

#next-steps {
  display: flex;
  border-top: 1px solid var(--border);
  text-align: left;

  & > div {
    flex: 1 1 0;
    padding: 32px;
    @media (max-width: 1024px) {
      padding: 24px 20px;
    }
  }

  .icon {
    margin-bottom: 16px;
    width: 22px;
    height: 22px;
  }

  @media (max-width: 1024px) {
    flex-direction: column;
    text-align: center;
  }
}

#docs {
  border-right: 1px solid var(--border);

  @media (max-width: 1024px) {
    border-right: none;
    border-bottom: 1px solid var(--border);
  }
}

#next-steps ul {
  list-style: none;
  padding: 0;
  display: flex;
  gap: 8px;
  margin: 32px 0 0;

  .logo {
    height: 18px;
  }

  a {
    color: var(--text-h);
    font-size: 16px;
    border-radius: 6px;
    background: var(--social-bg);
    display: flex;
    padding: 6px 12px;
    align-items: center;
    gap: 8px;
    text-decoration: none;
    transition: box-shadow 0.3s;

    &:hover {
      box-shadow: var(--shadow);
    }
    .button-icon {
      height: 18px;
      width: 18px;
    }
  }

  @media (max-width: 1024px) {
    margin-top: 20px;
    flex-wrap: wrap;
    justify-content: center;

    li {
      flex: 1 1 calc(50% - 8px);
    }

    a {
      width: 100%;
      justify-content: center;
      box-sizing: border-box;
    }
  }
}

#spacer {
  height: 88px;
  border-top: 1px solid var(--border);
  @media (max-width: 1024px) {
    height: 48px;
  }
}

.ticks {
  position: relative;
  width: 100%;

  &::before,
  &::after {
    content: '';
    position: absolute;
    top: -4.5px;
    border: 5px solid transparent;
  }

  &::before {
    left: 0;
    border-left-color: var(--border);
  }
  &::after {
    right: 0;
    border-right-color: var(--border);
  }
}

`

---

## src/game/unoEngine.js

`javascript
// unoEngine.js - Authoritative UNO Game Engine with Stacking, State Masking & 2v2 Team Mode

export class UnoEngine {
  constructor(playerCount = 4, customPlayers = null, allowStacking = true, gameMode = 'ffa', options = {}) {
    this.gameMode = gameMode; // 'ffa' | '2v2'
    this.playerCount = this.gameMode === '2v2' ? 4 : Math.max(2, Math.min(4, playerCount));
    this.colors = ['red', 'yellow', 'green', 'blue'];
    this.colorHex = {
      red: '#ef4444',
      yellow: '#eab308',
      green: '#22c55e',
      blue: '#3b82f6',
      wild: '#1f2937'
    };
    this.colorNames = {
      red: '紅色',
      yellow: '黃色',
      green: '綠色',
      blue: '藍色',
      wild: '黑色萬用'
    };

    this.allowStacking = allowStacking;
    this.customPlayers = customPlayers;
    this.targetScore = options.targetScore !== undefined ? options.targetScore : 500; // 0 = casual/no score limit
    this.drawRule = options.drawRule || 'draw_one'; // 'draw_one' | 'draw_until_playable'
    this.allowChallengeWildDraw4 = options.allowChallengeWildDraw4 !== undefined ? options.allowChallengeWildDraw4 : true;
    this.isMatchOver = false;
    this.matchWinner = null;
    this.lastRoundPoints = 0;
    this.reset();
  }

  reset() {
    this.drawPile = this.generateDeck();
    this.shuffle(this.drawPile);
    this.discardPile = [];

    // Stacking penalty pool
    this.stackedDrawCount = 0;
    this.stackedDrawType = null; // 'draw2' or 'wild_draw4'
    this.lastWildDraw4Info = null; // Tracks info for +4 challenge
    this.pendingWildDraw4Info = null;

    // Continuous drawing state
    this.isContinuousDrawing = false;
    this.drawingPlayerIndex = null;
    this.drawingStepCount = 0;

    // Preserve existing scores across rounds if players already exist
    const existingScores = this.players ? this.players.map(p => p.score) : null;

    // Players setup
    this.players = [];
    for (let i = 0; i < this.playerCount; i++) {
      const pInfo = this.customPlayers ? this.customPlayers[i] : null;
      const teamId = this.gameMode === '2v2' ? (i % 2 === 0 ? 'team_a' : 'team_b') : null;
      const teamName = this.gameMode === '2v2' ? (i % 2 === 0 ? '金隊 (隊伍 A)' : '藍隊 (隊伍 B)') : null;
      const teammateIndex = this.gameMode === '2v2' ? (i + 2) % 4 : null;

      const score = existingScores && existingScores[i] !== undefined
        ? existingScores[i]
        : (pInfo && pInfo.score ? pInfo.score : 0);

      this.players.push({
        id: i,
        name: pInfo ? pInfo.name : (i === 0 ? '房主' : `玩家 ${i + 1}`),
        isAi: pInfo ? !!pInfo.isAi : (i !== 0),
        peerId: pInfo ? pInfo.peerId : null,
        teamId,
        teamName,
        teammateIndex,
        hand: [],
        calledUno: false,
        unoVulnerable: false,
        pendingUnoCall: false,
        score
      });
    }

    // Deal 7 cards to each player
    for (let r = 0; r < 7; r++) {
      for (let p = 0; p < this.playerCount; p++) {
        this.players[p].hand.push(this.drawCardRaw());
      }
    }

    // Flip first card (must not be Wild Draw 4)
    let firstCard = this.drawCardRaw();
    while (firstCard.value === 'wild_draw4') {
      this.drawPile.unshift(firstCard);
      this.shuffle(this.drawPile);
      firstCard = this.drawCardRaw();
    }
    this.discardPile.push(firstCard);

    this.currentColor = firstCard.color === 'wild' ? 'red' : firstCard.color;
    if (firstCard.color === 'wild') {
      firstCard.chosenColor = this.currentColor;
    }
    this.currentValue = firstCard.value;
    this.direction = 1; // 1 = clockwise, -1 = counter-clockwise
    this.currentTurn = 0;
    this.gameStatus = 'playing';
    this.isDealing = true; // Opening deal phase
    this.winner = null;
    this.log = [];
    this.hasDrawnThisTurn = false;
    this.turnDuration = 15;
    this.turnStartTime = null;
    this.isChoosingColor = false;
    this.colorChoosingPlayerIndex = null;
    this.pendingWildCard = null;

    // Apply initial card action
    this.applyInitialCardAction(firstCard);
  }

  finishDealing() {
    this.isDealing = false;
    this.turnStartTime = Date.now();
    this.addLog(`🎴 發牌完畢！輪到【${this.players[this.currentTurn]?.name || '第 1 位玩家'}】行動。`);
    return { success: true };
  }

  applyInitialCardAction(card) {
    if (card.value === 'skip') {
      this.addLog(`首張牌是【禁止牌】，跳過 ${this.players[0].name}！`);
      this.currentTurn = this.getNextTurnIndex();
    } else if (card.value === 'reverse') {
      if (this.playerCount === 2) {
        this.addLog(`首張牌是【反轉牌】(兩人局視為跳過)，跳過 ${this.players[0].name}！`);
        this.currentTurn = this.getNextTurnIndex();
      } else {
        this.direction *= -1;
        this.addLog(`首張牌是【反轉牌】，轉向為逆時針！`);
      }
    } else if (card.value === 'draw2') {
      if (this.allowStacking) {
        this.stackedDrawCount = 2;
        this.stackedDrawType = 'draw2';
        this.addLog(`首張牌是【+2 罰抽牌】，目前累積 +2 張！輪到 ${this.players[0].name}，可出 +2 疊牌或抽牌！`);
      } else {
        this.addLog(`首張牌是【+2 罰抽牌】，${this.players[0].name} 抽 2 張牌且跳過出牌！`);
        this.drawCardsForPlayer(0, 2);
        this.currentTurn = this.getNextTurnIndex();
      }
    } else if (card.value === 'wild') {
      this.addLog(`首張牌是【萬用牌】，起始玩家 ${this.players[0].name} 可自選任意顏色！`);
    }
  }

  generateDeck() {
    const deck = [];
    let idCounter = 1;

    for (const color of this.colors) {
      // 1x '0'
      deck.push({
        id: `c_${idCounter++}`,
        color,
        value: '0',
        assetKey: `${color}_0`,
        points: 0
      });

      // 2x '1'..'9'
      for (let n = 1; n <= 9; n++) {
        const val = n.toString();
        deck.push({
          id: `c_${idCounter++}`,
          color,
          value: val,
          assetKey: `${color}_${val}`,
          points: n
        });
        deck.push({
          id: `c_${idCounter++}`,
          color,
          value: val,
          assetKey: `${color}_${val}`,
          points: n
        });
      }

      // 2x Skip, 2x Reverse, 2x Draw 2
      ['skip', 'reverse', 'draw2'].forEach(action => {
        deck.push({
          id: `c_${idCounter++}`,
          color,
          value: action,
          assetKey: `${color}_${action}`,
          points: 20
        });
        deck.push({
          id: `c_${idCounter++}`,
          color,
          value: action,
          assetKey: `${color}_${action}`,
          points: 20
        });
      });
    }

    // 4x Wild, 4x Wild Draw 4
    for (let i = 0; i < 4; i++) {
      deck.push({
        id: `c_${idCounter++}`,
        color: 'wild',
        value: 'wild',
        assetKey: 'wild',
        points: 50
      });
      deck.push({
        id: `c_${idCounter++}`,
        color: 'wild',
        value: 'wild_draw4',
        assetKey: 'wild_draw4',
        points: 50
      });
    }

    return deck;
  }

  shuffle(array) {
    for (let i = array.length - 1; i > 0; i--) {
      const j = Math.floor(Math.random() * (i + 1));
      [array[i], array[j]] = [array[j], array[i]];
    }
    return array;
  }

  drawCardRaw() {
    if (this.drawPile.length === 0) {
      if (this.discardPile.length <= 1) {
        this.drawPile = this.generateDeck();
        this.shuffle(this.drawPile);
      } else {
        const top = this.discardPile.pop();
        // Reset all recycled cards so wild cards return to pristine uncolored state
        const recycledCards = this.discardPile.map((c) => {
          if (c.color === 'wild') {
            const { chosenColor, ...rest } = c;
            return { ...rest, displayAssetKey: c.assetKey };
          }
          return { ...c, displayAssetKey: c.assetKey };
        });
        this.drawPile = this.shuffle(recycledCards);
        this.discardPile = [top];
        this.addLog(`牌庫抽盡，棄牌堆重新洗牌放入抽牌堆！`);
      }
    }
    const card = this.drawPile.pop();
    if (card && card.color === 'wild') {
      delete card.chosenColor;
      card.displayAssetKey = card.assetKey;
    }
    return card;
  }

  drawCardsForPlayer(playerIndex, count) {
    const drawn = [];
    for (let i = 0; i < count; i++) {
      const card = this.drawCardRaw();
      this.players[playerIndex].hand.push(card);
      drawn.push(card);
    }
    if (this.players[playerIndex].hand.length > 1) {
      this.players[playerIndex].calledUno = false;
      this.players[playerIndex].unoVulnerable = false;
      this.players[playerIndex].pendingUnoCall = false;
    }
    return drawn;
  }

  getTopCard() {
    return this.discardPile[this.discardPile.length - 1];
  }

  canPlayCard(card) {
    if (!card) return false;
    if (this.isChoosingColor) return false;

    // ACTIVE STACK PENALTY: Only stacking cards of the exact same type (+2 on +2, +4 on +4) are allowed!
    if (this.stackedDrawCount > 0) {
      if (!this.allowStacking) return false;
      return card.value === this.stackedDrawType;
    }

    // Normal play rules:
    if (card.color === 'wild') return true;
    if (card.color === this.currentColor) return true;
    if (card.value === this.currentValue) return true;
    return false;
  }

  getValidCardsForPlayer(playerIndex) {
    const p = this.players[playerIndex];
    if (!p) return [];
    return p.hand.filter(c => this.canPlayCard(c));
  }

  getNextTurnIndex(step = 1) {
    let next = (this.currentTurn + this.direction * step) % this.playerCount;
    if (next < 0) next += this.playerCount;
    return next;
  }

  // Find the color that the player has the most cards of in their remaining hand
  getBestColorForPlayer(playerIndex) {
    const player = this.players[playerIndex];
    if (!player || player.hand.length === 0) return 'red';
    const counts = { red: 0, yellow: 0, green: 0, blue: 0 };
    player.hand.forEach(c => {
      if (counts[c.color] !== undefined) counts[c.color]++;
    });
    let best = 'red';
    let maxC = -1;
    for (const [col, count] of Object.entries(counts)) {
      if (count > maxC) {
        maxC = count;
        best = col;
      }
    }
    return best;
  }

  // Play a card
  playCard(playerIndex, cardId, chosenColor = null) {
    if (this.isDealing) {
      return { success: false, reason: '開局發牌中，尚未能出牌！' };
    }
    if (this.isChoosingColor) {
      return { success: false, reason: '正在等待選擇顏色中！' };
    }
    if (this.currentTurn !== playerIndex) {
      return { success: false, reason: '不是你的回合！' };
    }

    const player = this.players[playerIndex];
    const cardIdx = player.hand.findIndex(c => c.id === cardId);
    if (cardIdx === -1) {
      return { success: false, reason: '找不到這張牌！' };
    }

    const card = player.hand[cardIdx];
    if (!this.canPlayCard(card)) {
      return { success: false, reason: '此牌不符合出牌規則！' };
    }

    // Save Wild Draw 4 challenge verification info BEFORE card is removed from hand!
    // Steam / Official UNO rule: strictly check if player held cards matching current active COLOR!
    if (card.value === 'wild_draw4') {
      const prevColor = this.currentColor;
      // Illegal ONLY if player had cards matching current color (excluding wild cards)
      const matchingCards = player.hand.filter(c => c.id !== card.id && c.color === prevColor);
      this.pendingWildDraw4Info = {
        playerIndex,
        playerName: player.name,
        targetColorName: this.colorNames[prevColor] || prevColor,
        hasMatchingCard: matchingCards.length > 0,
        matchingCardNames: matchingCards.map(c => this.getCardDisplayName(c)),
        priorStackedCount: this.stackedDrawCount || 0
      };
    } else {
      this.pendingWildDraw4Info = null;
      this.lastWildDraw4Info = null;
    }

    // Remove from player's hand and put on discard pile immediately
    player.hand.splice(cardIdx, 1);
    this.discardPile.push(card);

    // UNO State Management (When down to 1 card)
    let needsUnoGracePeriod = false;
    if (player.hand.length === 1) {
      if (player.calledUno) {
        player.unoVulnerable = false;
        player.pendingUnoCall = false;
      } else {
        if (player.isAi) {
          if (Math.random() < 0.8) {
            player.calledUno = true;
            player.unoVulnerable = false;
            this.addLog(`🚨 【${player.name}】大喊了「UNO！」 (剩最後 1 張牌)`);
          } else {
            player.calledUno = false;
            player.unoVulnerable = true;
            this.addLog(`👀 【${player.name}】剩最後 1 張牌但忘記喊 UNO！大家快抓漏！`);
          }
        } else {
          // Human player did NOT manually click the UNO button!
          player.calledUno = false;
          player.unoVulnerable = true;
          player.pendingUnoCall = false;
          this.addLog(`👀 【${player.name}】打出牌剩最後 1 張，但尚未喊 UNO！大家快抓漏！`);
        }
      }
    } else {
      player.calledUno = false;
      player.unoVulnerable = false;
      player.pendingUnoCall = false;
    }

    // Check Win Condition
    if (player.hand.length === 0) {
      if (card.color === 'wild') {
        const winColor = chosenColor || this.getBestColorForPlayer(playerIndex);
        this.currentColor = winColor;
        card.chosenColor = winColor;
        card.displayAssetKey = card.value === 'wild_draw4' ? `wild_draw4_${winColor}` : `wild_${winColor}`;
      }
      this.gameStatus = 'game_over';
      this.winner = player;
      this.calculateScores();

      const winMsg = this.gameMode === '2v2'
        ? `🎉 恭喜！${player.name} 出完手牌，【${player.teamName}】贏得 2V2 勝利！`
        : `🎉 恭喜！${player.name} 出完所有手牌，贏得本局勝利！`;
      this.addLog(winMsg);

      this.lastAction = {
        type: 'play',
        playerId: playerIndex,
        playerName: player.name,
        card: { ...card },
        timestamp: Date.now()
      };

      return {
        success: true,
        gameOver: true,
        winner: player,
        card,
        effectMsg: ''
      };
    }

    // If card is wild and no chosenColor is provided yet (Human player): enter 6-second color selection phase!
    if (card.color === 'wild' && !chosenColor) {
      if (player.isAi) {
        chosenColor = this.getBestColorForPlayer(playerIndex);
      } else {
        this.isChoosingColor = true;
        this.colorChoosingPlayerIndex = playerIndex;
        this.pendingWildCard = card;
        this.currentColor = 'wild';
        this.currentValue = card.value;
        card.displayAssetKey = card.assetKey;
        this.turnStartTime = Date.now();
        this.turnDuration = 6; // 6 SECONDS EXTRA FOR COLOR SELECTION!

        this.addLog(`🌈 ${player.name} 打出了【${this.getCardDisplayName(card)}】！進入選色階段 (限時 6 秒)...`);

        this.lastAction = {
          type: 'play',
          playerId: playerIndex,
          playerName: player.name,
          card: { ...card },
          timestamp: Date.now()
        };

        return {
          success: true,
          isChoosingColor: true,
          card,
          needsUnoGracePeriod
        };
      }
    }

    let effectMsg = '';
    let nextStep = 1;

    // Apply color & transformed visual asset key
    if (card.color === 'wild') {
      this.currentColor = chosenColor || 'red';
      this.currentValue = card.value;
      card.chosenColor = this.currentColor;
      card.displayAssetKey = card.value === 'wild_draw4' ? `wild_draw4_${this.currentColor}` : `wild_${this.currentColor}`;
      effectMsg = `指定顏色為【${this.colorNames[this.currentColor]}】！`;
    } else {
      this.currentColor = card.color;
      this.currentValue = card.value;
      card.displayAssetKey = card.assetKey;
    }

    // Special card actions & STACKING RULE
    if (card.value === 'draw2') {
      if (this.allowStacking) {
        this.stackedDrawCount += 2;
        this.stackedDrawType = 'draw2';
        const nextVictim = this.players[this.getNextTurnIndex(1)];
        nextStep = 1;
        effectMsg += ` ⚡ +2 疊加！目前累積罰抽【+${this.stackedDrawCount} 張】！輪到 ${nextVictim.name}！`;
      } else {
        const victim = this.getNextTurnIndex(1);
        this.drawCardsForPlayer(victim, 2);
        nextStep = 2;
        effectMsg += ` 💥 ${this.players[victim].name} 強制抽 2 張牌並跳過出牌！`;
      }
    } else if (card.value === 'wild_draw4') {
      if (this.pendingWildDraw4Info) {
        this.lastWildDraw4Info = this.pendingWildDraw4Info;
        this.pendingWildDraw4Info = null;
      }
      if (this.allowStacking) {
        this.stackedDrawCount += 4;
        this.stackedDrawType = 'wild_draw4';
        const nextVictim = this.players[this.getNextTurnIndex(1)];
        nextStep = 1;
        effectMsg += ` 🔥 +4 萬用疊加！目前累積罰抽【+${this.stackedDrawCount} 張】！輪到 ${nextVictim.name}！`;
      } else if (this.allowChallengeWildDraw4) {
        this.stackedDrawCount = 4;
        this.stackedDrawType = 'wild_draw4';
        const nextVictim = this.players[this.getNextTurnIndex(1)];
        nextStep = 1;
        effectMsg += ` 🔥 +4 萬用牌！輪到 ${nextVictim.name}，可質疑出牌合法性或承受罰抽！`;
      } else {
        const victim = this.getNextTurnIndex(1);
        this.drawCardsForPlayer(victim, 4);
        nextStep = 2;
        effectMsg += ` 🔥 ${this.players[victim].name} 強制抽 4 張牌並跳過出牌！`;
      }
    }

    let skippedPlayer = null;
    if (card.value === 'skip') {
      skippedPlayer = this.players[this.getNextTurnIndex(1)];
      nextStep = 2;
      effectMsg += ` 🚫 跳過 ${skippedPlayer.name} 的回合！`;
    } else if (card.value === 'reverse') {
      if (this.playerCount === 2) {
        nextStep = 2;
        effectMsg += ` 🔄 兩人局反轉牌視同跳過！`;
      } else {
        this.direction *= -1;
        effectMsg += ` 🔄 出牌方向反轉為${this.direction === 1 ? '順時針' : '逆時針'}！`;
      }
    }

    this.addLog(`${player.name} 打出【${this.getCardDisplayName(card)}】。${effectMsg}`);

    this.lastAction = {
      type: 'play',
      playerId: playerIndex,
      playerName: player.name,
      card: { ...card },
      skippedPlayerId: skippedPlayer ? skippedPlayer.id : null,
      skippedPlayerName: skippedPlayer ? skippedPlayer.name : null,
      timestamp: Date.now()
    };

    // Move to next turn
    this.hasDrawnThisTurn = false;
    this.currentTurn = this.getNextTurnIndex(nextStep);
    this.turnStartTime = Date.now();
    this.turnDuration = 15;

    return {
      success: true,
      card,
      effectMsg,
      needsUnoGracePeriod,
      stackedCount: this.stackedDrawCount,
      nextPlayer: this.players[this.currentTurn]
    };
  }

  confirmWildColor(playerIndex, chosenColor) {
    if (!this.isChoosingColor || this.colorChoosingPlayerIndex !== playerIndex) {
      return { success: false, reason: '目前非選色階段或不是你的選色回合！' };
    }

    const player = this.players[playerIndex];
    const card = this.pendingWildCard || this.getTopCard();
    if (!card) return { success: false };

    const validColors = ['red', 'yellow', 'green', 'blue'];
    const finalColor = validColors.includes(chosenColor) ? chosenColor : this.getBestColorForPlayer(playerIndex);

    this.currentColor = finalColor;
    this.currentValue = card.value;
    card.chosenColor = finalColor;
    card.displayAssetKey = card.value === 'wild_draw4' ? `wild_draw4_${finalColor}` : `wild_${finalColor}`;

    this.isChoosingColor = false;
    this.colorChoosingPlayerIndex = null;
    this.pendingWildCard = null;

    let effectMsg = `指定顏色為【${this.colorNames[finalColor]}】！`;
    let nextStep = 1;

    if (card.value === 'wild_draw4') {
      if (this.pendingWildDraw4Info) {
        this.lastWildDraw4Info = this.pendingWildDraw4Info;
        this.pendingWildDraw4Info = null;
      }
      if (this.allowStacking) {
        this.stackedDrawCount += 4;
        this.stackedDrawType = 'wild_draw4';
        const nextVictim = this.players[this.getNextTurnIndex(1)];
        nextStep = 1;
        effectMsg += ` 🔥 +4 萬用疊加！目前累積罰抽【+${this.stackedDrawCount} 張】！輪到 ${nextVictim.name}！`;
      } else if (this.allowChallengeWildDraw4) {
        this.stackedDrawCount = 4;
        this.stackedDrawType = 'wild_draw4';
        const nextVictim = this.players[this.getNextTurnIndex(1)];
        nextStep = 1;
        effectMsg += ` 🔥 +4 萬用牌！輪到 ${nextVictim.name}，可質疑出牌合法性或承受罰抽！`;
      } else {
        const victim = this.getNextTurnIndex(1);
        this.drawCardsForPlayer(victim, 4);
        nextStep = 2;
        effectMsg += ` 🔥 ${this.players[victim].name} 強制抽 4 張牌並跳過出牌！`;
      }
    }

    this.addLog(`${player.name} ${effectMsg}`);

    this.lastAction = {
      type: 'color_chosen',
      playerId: playerIndex,
      playerName: player.name,
      chosenColor: finalColor,
      card: { ...card },
      timestamp: Date.now()
    };

    // Move to next turn with fresh 15s timer
    this.hasDrawnThisTurn = false;
    this.currentTurn = this.getNextTurnIndex(nextStep);
    this.turnStartTime = Date.now();
    this.turnDuration = 15;

    return {
      success: true,
      card,
      chosenColor: finalColor,
      nextPlayer: this.players[this.currentTurn]
    };
  }

  playerDrawCard(playerIndex) {
    if (this.isDealing) {
      return { success: false, reason: '開局發牌中，尚未能抽牌！' };
    }
    if (this.isChoosingColor) {
      return { success: false, reason: '正在等待選擇顏色中！' };
    }
    if (this.currentTurn !== playerIndex) {
      return { success: false, reason: '不是你的回合！' };
    }
    if (this.hasDrawnThisTurn) {
      return { success: false, reason: '本回合已經主動抽過牌了，無法重複抽牌！' };
    }

    // Normal draw of 1 card
    const card = this.drawCardRaw();
    this.players[playerIndex].hand.push(card);
    if (this.players[playerIndex].hand.length > 1) {
      this.players[playerIndex].calledUno = false;
      this.players[playerIndex].unoVulnerable = false;
      this.players[playerIndex].pendingUnoCall = false;
    }

    const canPlay = this.canPlayCard(card);
    this.addLog(`${this.players[playerIndex].name} 抽了一張牌。`);

    if (!canPlay) {
      this.hasDrawnThisTurn = false;
      this.lastAction = {
        type: 'draw_step',
        playerId: playerIndex,
        playerName: this.players[playerIndex].name,
        card: { ...card },
        canPlay: false,
        timestamp: Date.now()
      };
      return {
        success: true,
        card,
        drawnCards: [card],
        wasPenalty: false,
        canPlay: false,
        autoPassed: true
      };
    }

    this.hasDrawnThisTurn = true;
    this.turnStartTime = Date.now();
    this.lastAction = {
      type: 'draw_step',
      playerId: playerIndex,
      playerName: this.players[playerIndex].name,
      card: { ...card },
      canPlay: true,
      timestamp: Date.now()
    };
    return {
      success: true,
      card,
      drawnCards: [card],
      wasPenalty: false,
      canPlay: true,
      autoPassed: false
    };
  }

  // Explicitly advance turn to next player after animations conclude
  advanceTurn(step = 1) {
    this.hasDrawnThisTurn = false;
    this.currentTurn = this.getNextTurnIndex(step);
    this.turnStartTime = Date.now();
    return this.currentTurn;
  }

  // Finalize auto-passing turn after draw animation has fully played and paused
  finishAutoPass(playerIndex, card) {
    const player = this.players[playerIndex];
    if (!player) return;
    this.hasDrawnThisTurn = false;
    this.addLog(`💨 ${player.name} 抽牌後仍無法出牌，跳過回合！`);
    this.advanceTurn(1);
    this.lastAction = {
      type: 'draw_autopass',
      playerId: playerIndex,
      playerName: player.name,
      card: card ? { ...card } : null,
      timestamp: Date.now()
    };
  }

  // Finalize penalty draw sequence
  finishPenaltyDraw(playerIndex, count) {
    const player = this.players[playerIndex];
    if (!player) return;
    this.stackedDrawCount = 0;
    this.stackedDrawType = null;
    this.lastWildDraw4Info = null;
    this.hasDrawnThisTurn = false;
    this.addLog(`💥 ${player.name} 無法疊牌，被迫承受累積罰抽【+${count} 張】！回合結束！`);
    this.advanceTurn(1);
    this.lastAction = {
      type: 'penalty_finish',
      playerId: playerIndex,
      playerName: player.name,
      count,
      timestamp: Date.now()
    };
  }

  // Draw exactly one card step during continuous drawing sequence
  drawSingleCardStep(playerIndex) {
    if (this.isDealing) {
      return { success: false, reason: '開局發牌中，尚未能抽牌！' };
    }
    if (this.currentTurn !== playerIndex) {
      return { success: false, reason: '不是你的回合！' };
    }
    const player = this.players[playerIndex];
    if (!player) return { success: false, reason: '玩家不存在' };

    const card = this.drawCardRaw();
    player.hand.push(card);
    if (player.hand.length > 1) {
      player.calledUno = false;
      player.unoVulnerable = false;
      player.pendingUnoCall = false;
    }

    const canPlay = this.canPlayCard(card);
    this.lastAction = {
      type: 'draw_step',
      playerId: playerIndex,
      playerName: player.name,
      card: { ...card },
      timestamp: Date.now()
    };

    return {
      success: true,
      card,
      canPlay,
      handCount: player.hand.length
    };
  }

  // Finalize continuous drawing sequence once a playable card is found or limit reached
  finishContinuousDraw(playerIndex, drawnCards, canPlay) {
    const player = this.players[playerIndex];
    if (!player) return { success: false };

    const lastCard = drawnCards[drawnCards.length - 1];

    if (drawnCards.length > 1) {
      this.addLog(`${player.name} 連續抽取了 ${drawnCards.length} 張牌，直到抽到可出的牌！`);
    } else {
      this.addLog(`${player.name} 抽了一張牌。`);
    }

    if (!canPlay) {
      this.hasDrawnThisTurn = false;
      this.addLog(`💨 ${player.name} 連續抽牌已達上限仍無法出牌，自動跳過回合！`);
      this.currentTurn = this.getNextTurnIndex(1);
      this.lastAction = {
        type: 'draw_autopass',
        playerId: playerIndex,
        playerName: player.name,
        card: { ...lastCard },
        drawnCount: drawnCards.length,
        timestamp: Date.now()
      };
      return {
        success: true,
        canPlay: false,
        autoPassed: true,
        nextPlayer: this.players[this.currentTurn]
      };
    }

    this.hasDrawnThisTurn = true;
    this.lastAction = {
      type: 'draw_finished',
      playerId: playerIndex,
      playerName: player.name,
      card: { ...lastCard },
      drawnCount: drawnCards.length,
      canPlay: true,
      timestamp: Date.now()
    };

    return {
      success: true,
      card: lastCard,
      drawnCards,
      canPlay: true,
      autoPassed: false
    };
  }

  passTurn(playerIndex) {
    if (this.isDealing) {
      return { success: false, reason: '開局發牌中！' };
    }
    if (this.isChoosingColor) {
      return { success: false, reason: '正在等待選擇顏色中！' };
    }
    if (this.currentTurn !== playerIndex) {
      return { success: false, reason: '不是你的回合！' };
    }
    if (this.stackedDrawCount > 0) {
      return { success: false, reason: '有累積罰抽未承受，無法直接過牌！' };
    }
    if (!this.hasDrawnThisTurn) {
      return { success: false, reason: '必須先抽一張牌後才能過牌！' };
    }
    this.hasDrawnThisTurn = false;
    this.addLog(`${this.players[playerIndex].name} 選擇過牌。`);
    this.currentTurn = this.getNextTurnIndex(1);
    this.turnStartTime = Date.now();
    return {
      success: true,
      nextPlayer: this.players[this.currentTurn]
    };
  }

  callUno(playerIndex) {
    const player = this.players[playerIndex];
    if (!player) return { success: false };
    if (player.hand.length === 2) {
      const validCards = this.getValidCardsForPlayer(playerIndex);
      if (validCards.length === 0) {
        return { success: false, reason: '手牌剩 2 張但無牌可出，無法喊 UNO！' };
      }
      player.calledUno = true;
      player.unoVulnerable = false;
      player.pendingUnoCall = false;
      this.addLog(`🚨 【${player.name}】預先大喊「UNO！」 (準備出牌剩 1 張)`);
      return { success: true };
    } else if (player.hand.length === 1) {
      player.calledUno = true;
      player.unoVulnerable = false;
      player.pendingUnoCall = false;
      this.addLog(`🚨 【${player.name}】及時大喊「UNO！」！解除被抓漏危機！`);
      return { success: true };
    }
    return { success: false, reason: '手牌超過 2 張時不能喊 UNO！' };
  }

  challengeUno(challengerIndex, targetIndex) {
    const target = this.players[targetIndex];
    if (target && target.hand.length === 1 && target.unoVulnerable) {
      this.drawCardsForPlayer(targetIndex, 2);
      target.calledUno = false;
      target.unoVulnerable = false;
      target.pendingUnoCall = false;
      this.addLog(`⚖️ 【${this.players[challengerIndex].name}】眼明手快抓到了【${target.name}】沒喊 UNO！${target.name} 被罰抽 2 張牌！`);
      return { success: true, caught: true, targetName: target.name };
    }
    return { success: false, reason: '對方已喊 UNO 或目前不可抓漏！' };
  }

  // Challenge +4 legality rule:
  // If challenged player had matching color or number/action card before playing +4:
  // - Challenge succeeds: challenged player takes their own +4 (draws 4 penalty cards).
  //   Prior stacked '+' is still taken by challenger. If no prior stack, challenger takes 0 and continues turn.
  // - Challenge fails: challenger draws all stacked penalties + 2 extra cards, and is skipped.
  challengeWildDraw4(challengerIndex) {
    if (this.isDealing || this.isChoosingColor || this.gameStatus !== 'playing') {
      return { success: false, reason: '目前無法進行質疑！' };
    }
    if (this.currentTurn !== challengerIndex) {
      return { success: false, reason: '不是你的回合！' };
    }
    if (!this.allowChallengeWildDraw4 || !this.lastWildDraw4Info) {
      return { success: false, reason: '目前無可質疑的 +4 牌！' };
    }

    const info = this.lastWildDraw4Info;
    const challengedPlayer = this.players[info.playerIndex];
    const challenger = this.players[challengerIndex];

    if (info.hasMatchingCard) {
      // 質疑成功！被質疑者手牌中明明有當前顏色牌，違規出 +4
      this.drawCardsForPlayer(info.playerIndex, 4);
      const priorCount = info.priorStackedCount || 0;
      
      let msg = `⚖️ 【${challenger.name}】質疑成功！【${challengedPlayer.name}】手牌中明明有【${info.targetColorName}】的牌 (${info.matchingCardNames.join('、')})，違規出 +4！${challengedPlayer.name} 被罰抽 4 張！`;

      this.lastWildDraw4Info = null;
      this.stackedDrawCount = 0;
      this.stackedDrawType = null;
      this.hasDrawnThisTurn = false;

      if (priorCount > 0) {
        // 先前累積的 + 仍由質疑者吃下去
        this.drawCardsForPlayer(challengerIndex, priorCount);
        msg += ` 但先前累積的罰抽 (+${priorCount} 張) 仍由 ${challenger.name} 承受，回合結束！`;
        this.addLog(msg);
        this.advanceTurn(1);
        return {
          success: true,
          challengedWon: false,
          priorCount,
          msg
        };
      } else {
        // 無先前累積，質疑者免罰抽，繼續正常出牌
        msg += ` ${challenger.name} 免受罰抽，回合繼續，請出牌或抽牌！`;
        this.addLog(msg);
        this.turnStartTime = Date.now();
        this.turnDuration = 15;
        return {
          success: true,
          challengedWon: false,
          priorCount: 0,
          msg
        };
      }
    } else {
      // 質疑失敗！被質疑者確實無該顏色手牌 (合法出牌)
      // 質疑者承受所有累積罰抽 + 2 張額外罰抽，並跳過回合
      const totalPenalty = (this.stackedDrawCount || 4) + 2;
      this.drawCardsForPlayer(challengerIndex, totalPenalty);

      const msg = `⚖️ 【${challenger.name}】質疑失敗！【${challengedPlayer.name}】當時確實無【${info.targetColorName}】的手牌！${challenger.name} 承受所有罰抽加罰 2 張 (共抽 ${totalPenalty} 張) 並跳過回合！`;
      this.addLog(msg);

      this.lastWildDraw4Info = null;
      this.stackedDrawCount = 0;
      this.stackedDrawType = null;
      this.hasDrawnThisTurn = false;
      this.advanceTurn(1);

      return {
        success: true,
        challengedWon: true,
        penalty: totalPenalty,
        msg
      };
    }
  }

  calculateScores() {
    let totalPoints = 0;
    if (this.gameMode === '2v2' && this.winner) {
      // In 2v2: Opposing team hand cards are scored
      const winningTeamId = this.winner.teamId;
      this.players.forEach(p => {
        if (p.teamId !== winningTeamId) {
          p.hand.forEach(c => {
            totalPoints += c.points;
          });
        }
      });
      // Both teammates get the victory points
      this.players.forEach(p => {
        if (p.teamId === winningTeamId) {
          p.score += totalPoints;
        }
      });
      this.lastRoundPoints = totalPoints;

      // Check Target Score
      if (this.targetScore > 0) {
        const winningPlayer = this.players.find(p => p.teamId === winningTeamId);
        if (winningPlayer && winningPlayer.score >= this.targetScore) {
          this.isMatchOver = true;
          this.matchWinner = {
            teamId: winningTeamId,
            teamName: winningPlayer.teamName,
            score: winningPlayer.score
          };
          this.addLog(`🏆 賽事總冠軍誕生！【${winningPlayer.teamName}】累積達到 ${winningPlayer.score} 分，奪得最終冠軍！`);
        }
      }
    } else {
      this.players.forEach(p => {
        if (p !== this.winner) {
          p.hand.forEach(c => {
            totalPoints += c.points;
          });
        }
      });
      if (this.winner) {
        this.winner.score += totalPoints;
        this.lastRoundPoints = totalPoints;

        // Check Target Score
        if (this.targetScore > 0 && this.winner.score >= this.targetScore) {
          this.isMatchOver = true;
          this.matchWinner = {
            id: this.winner.id,
            name: this.winner.name,
            score: this.winner.score
          };
          this.addLog(`🏆 賽事總冠軍誕生！【${this.winner.name}】累積達到 ${this.winner.score} 分，奪得最終冠軍！`);
        }
      }
    }
  }

  getCardDisplayName(card) {
    const colName = this.colorNames[card.color] || '';
    if (card.value === 'skip') return `${colName} 禁止牌`;
    if (card.value === 'reverse') return `${colName} 反轉牌`;
    if (card.value === 'draw2') return `${colName} +2 罰抽牌`;
    if (card.value === 'wild') return `萬用牌 (Wild)`;
    if (card.value === 'wild_draw4') return `萬用 +4 罰抽牌 (Wild Draw 4)`;
    return `${colName} ${card.value}`;
  }

  addLog(msg) {
    this.log.unshift({
      time: new Date().toLocaleTimeString(),
      text: msg
    });
    if (this.log.length > 50) this.log.pop();
  }

  // Produce a security-masked state for a specific client (Prevents DevTools Cheating!)
  // In 2v2 mode: teammate's hand is sent, while opponents' hands remain hidden!
  getClientState(playerIndex) {
    const top = this.getTopCard();
    let topDisplayKey = top ? (top.displayAssetKey || top.assetKey) : 'card_back';
    if (top && top.color === 'wild') {
      if (this.isChoosingColor || !top.chosenColor) {
        topDisplayKey = top.value === 'wild_draw4' ? 'wild_draw4' : 'wild';
      } else {
        topDisplayKey = top.value === 'wild_draw4' ? `wild_draw4_${top.chosenColor}` : `wild_${top.chosenColor}`;
      }
    }

    const teammateIndex = this.gameMode === '2v2' ? (playerIndex + 2) % 4 : null;
    const teammatePlayer = teammateIndex !== null ? this.players[teammateIndex] : null;

    const sanitizeHandCard = (c) => {
      if (c && c.color === 'wild') {
        const { chosenColor, ...rest } = c;
        return { ...rest, displayAssetKey: c.assetKey };
      }
      return c;
    };

    return {
      gameMode: this.gameMode,
      targetScore: this.targetScore,
      drawRule: this.drawRule,
      isMatchOver: !!this.isMatchOver,
      matchWinner: this.matchWinner || null,
      lastRoundPoints: this.lastRoundPoints || 0,
      isContinuousDrawing: !!this.isContinuousDrawing,
      drawingPlayerIndex: this.drawingPlayerIndex !== undefined ? this.drawingPlayerIndex : null,
      drawingStepCount: this.drawingStepCount || 0,
      myIndex: playerIndex,
      teammateIndex,
      teammateHand: teammatePlayer ? teammatePlayer.hand.map(sanitizeHandCard) : [],
      players: this.players.map(p => ({
        id: p.id,
        name: p.name,
        isAi: p.isAi,
        teamId: p.teamId,
        teamName: p.teamName,
        cardCount: p.hand.length,
        calledUno: p.calledUno,
        unoVulnerable: p.unoVulnerable,
        score: p.score
      })),
      myHand: this.players[playerIndex] ? this.players[playerIndex].hand.map(sanitizeHandCard) : [],
      validCards: this.getValidCardsForPlayer(playerIndex).map(c => c.id),
      topCard: top ? {
        ...top,
        displayAssetKey: topDisplayKey
      } : null,
      currentColor: this.currentColor,
      currentValue: this.currentValue,
      direction: this.direction,
      currentTurn: this.currentTurn,
      turnStartTime: this.turnStartTime,
      turnDuration: this.turnDuration || 15,
      isChoosingColor: !!this.isChoosingColor,
      colorChoosingPlayerIndex: this.colorChoosingPlayerIndex !== undefined ? this.colorChoosingPlayerIndex : null,
      pendingWildCard: this.pendingWildCard ? { ...this.pendingWildCard } : null,
      hasDrawnThisTurn: this.hasDrawnThisTurn,
      stackedDrawCount: this.stackedDrawCount,
      stackedDrawType: this.stackedDrawType,
      allowStacking: this.allowStacking,
      allowChallengeWildDraw4: !!this.allowChallengeWildDraw4,
      canChallengeWildDraw4: !!this.allowChallengeWildDraw4 &&
        !!this.lastWildDraw4Info &&
        this.currentTurn === playerIndex &&
        this.stackedDrawType === 'wild_draw4' &&
        !this.isDealing &&
        !this.isChoosingColor &&
        this.gameStatus === 'playing',
      lastWildDraw4PlayerName: this.lastWildDraw4Info ? this.lastWildDraw4Info.playerName : null,
      gameStatus: this.gameStatus,
      isDealing: !!this.isDealing,
      winner: this.winner ? {
        id: this.winner.id,
        name: this.winner.name,
        teamId: this.winner.teamId,
        teamName: this.winner.teamName
      } : null,
      drawPileCount: this.drawPile.length,
      lastAction: this.lastAction || null,
      log: this.log.slice(0, 30)
    };
  }
}

`

---

## src/game/unoAi.js

`javascript
// unoAi.js - Intelligent UNO AI Bot with 2v2 Team Cooperative Heuristics

export class UnoAI {
  constructor(engine) {
    this.engine = engine;
  }

  decideMove(playerIndex) {
    const player = this.engine.players[playerIndex];
    if (!player || !player.isAi) return null;

    const is2v2 = this.engine.gameMode === '2v2';
    const teammate = is2v2 ? this.engine.players[(playerIndex + 2) % 4] : null;

    // AI Step 1: Challenge Check (Do NOT challenge your own teammate in 2v2!)
    for (let pIdx = 0; pIdx < this.engine.players.length; pIdx++) {
      if (pIdx !== playerIndex) {
        if (is2v2 && teammate && pIdx === teammate.id) {
          continue; // Protect teammate
        }
        const target = this.engine.players[pIdx];
        if (target.hand.length === 1 && target.unoVulnerable) {
          if (Math.random() < 0.65) {
            return {
              action: 'challenge',
              targetIndex: pIdx
            };
          }
        }
      }
    }

    // AI Step 2: Stacking Penalty Defense Check (+2/+4 stack defense or +4 challenge)
    if (this.engine.stackedDrawCount > 0) {
      const validStackCards = this.engine.getValidCardsForPlayer(playerIndex);
      if (validStackCards.length > 0) {
        const chosenCard = validStackCards.find(c => c.value === 'draw2') || validStackCards[0];
        let chosenColor = null;
        if (chosenCard.color === 'wild') {
          chosenColor = this.getBestColorForHand(player.hand, teammate);
        }
        return {
          action: 'play',
          card: chosenCard,
          chosenColor,
          callUno: player.hand.length === 2 && Math.random() < 0.85
        };
      } else {
        // AI has no card to stack: If facing wild_draw4, consider challenging!
        if (this.engine.stackedDrawType === 'wild_draw4' && this.engine.allowChallengeWildDraw4 && this.engine.lastWildDraw4Info) {
          // In 2v2, do not challenge teammate
          if (is2v2 && teammate && this.engine.lastWildDraw4Info.playerIndex === teammate.id) {
            return { action: 'draw' };
          }
          if (Math.random() < 0.5) {
            return { action: 'challenge_wild_draw4' };
          }
        }
        return { action: 'draw' };
      }
    }

    // AI Step 3: Legal Cards Check
    const validCards = this.engine.getValidCardsForPlayer(playerIndex);
    if (validCards.length === 0) {
      return { action: 'draw' };
    }

    // AI Step 4: Self-UNO Check
    const shouldCallUno = player.hand.length === 2 && Math.random() < 0.85;

    // AI Step 5: Strategic Card Selection
    const nextPlayerIndex = this.engine.getNextTurnIndex(1);
    const nextPlayer = this.engine.players[nextPlayerIndex];
    const isNextTeammate = is2v2 && teammate && nextPlayer.id === teammate.id;
    const isNextPlayerDanger = nextPlayer && !isNextTeammate && nextPlayer.hand.length <= 2;

    let chosenCard = null;

    if (isNextPlayerDanger) {
      // Emergency attack against danger opponent
      chosenCard = validCards.find(c => c.value === 'wild_draw4') ||
                   validCards.find(c => c.value === 'draw2') ||
                   validCards.find(c => c.value === 'skip') ||
                   validCards.find(c => c.value === 'reverse');
    }

    // In 2v2: If next player is your teammate, avoid attacking them!
    if (!chosenCard && isNextTeammate) {
      // Filter out +2, +4, skip if possible so we don't penalize teammate
      const gentleCards = validCards.filter(c => !['draw2', 'wild_draw4', 'skip'].includes(c.value));
      if (gentleCards.length > 0) {
        // Prefer reverse (reverses away from teammate) or matching teammate's color
        const teammateColors = this.getColorCounts(teammate.hand);
        gentleCards.sort((a, b) => (teammateColors[b.color] || 0) - (teammateColors[a.color] || 0));
        chosenCard = gentleCards[0];
      }
    }

    if (!chosenCard) {
      // Normal attack against opponent
      const actionCards = validCards.filter(c => ['draw2', 'skip', 'reverse'].includes(c.value));
      if (actionCards.length > 0 && !isNextTeammate) {
        chosenCard = actionCards[0];
      }
    }

    if (!chosenCard) {
      const numCards = validCards.filter(c => c.color !== 'wild');
      if (numCards.length > 0) {
        const colorCounts = this.getColorCounts(player.hand);
        numCards.sort((a, b) => (colorCounts[b.color] || 0) - (colorCounts[a.color] || 0));
        chosenCard = numCards[0];
      }
    }

    if (!chosenCard) {
      chosenCard = validCards.find(c => c.value === 'wild') || validCards[0];
    }

    let chosenColor = null;
    if (chosenCard.color === 'wild') {
      chosenColor = this.getBestColorForHand(player.hand, teammate);
    }

    return {
      action: 'play',
      card: chosenCard,
      chosenColor,
      callUno: shouldCallUno
    };
  }

  getColorCounts(hand) {
    const counts = { red: 0, yellow: 0, green: 0, blue: 0 };
    if (!hand) return counts;
    hand.forEach(c => {
      if (counts[c.color] !== undefined) {
        counts[c.color]++;
      }
    });
    return counts;
  }

  // In 2v2 mode, if teammate has 1-2 cards, choose the color teammate holds to assist win!
  getBestColorForHand(hand, teammate = null) {
    if (teammate && teammate.hand.length <= 2) {
      const teamCounts = this.getColorCounts(teammate.hand);
      for (const [col, count] of Object.entries(teamCounts)) {
        if (count > 0) return col;
      }
    }

    const counts = this.getColorCounts(hand);
    let bestColor = 'red';
    let maxCount = -1;
    for (const [col, count] of Object.entries(counts)) {
      if (count > maxCount) {
        maxCount = count;
        bestColor = col;
      }
    }
    return bestColor;
  }
}

`

---

## src/services/p2p.js

`javascript
// p2p.js - WebRTC Host-Authoritative P2P Networking with 2v2 Team Mode & Slot Management
import Peer from 'peerjs';
import { UnoEngine } from '../game/unoEngine';
import { UnoAI } from '../game/unoAi';
import { soundManager } from './sound';

export class P2PNetwork {
  constructor() {
    this.peer = null;
    this.isHost = false;
    this.roomCode = '';
    this.playerName = '玩家';
    this.hostConn = null; // Client's connection to Host
    this.guestConns = new Map(); // Host's map of peerId -> { conn, name, slotIndex }
    
    // Game engine & AI instances (Host only)
    this.engine = null;
    this.ai = null;
    this.aiTimer = null;

    // Callbacks for React state
    this.onLobbyUpdate = null;
    this.onStateUpdate = null;
    this.onConnectionStatus = null;
    this.onError = null;
    this.onRoomDisbanded = null;

    // Lobby player list (Host & Client)
    this.lobbyPlayers = [];
    this.allowStacking = true;
    this.allowChallengeWildDraw4 = true;
    this.gameMode = 'ffa'; // 'ffa' | '2v2'
    this.targetScore = 500; // 0 = casual/no score limit
    this.drawRule = 'draw_one'; // 'draw_one' | 'draw_until_playable'
    this.gameStarted = false;
    this.onReturnToLobby = null;

    // Continuous drawing timer & flag
    this.isContinuousDrawing = false;
    this.continuousDrawTimer = null;
    this.dealTimer = null;
    this.lobbyIdleTimer = null;
  }

  static generateRoomCode() {
    const num = Math.floor(1000 + Math.random() * 9000);
    return `UNO-${num}`;
  }

  formatPeerId(code) {
    const clean = code.replace(/[^a-zA-Z0-9]/g, '').toLowerCase();
    return `uno-p2p-${clean}`;
  }

  resetLobbyIdleTimer() {
    if (this.lobbyIdleTimer) {
      clearTimeout(this.lobbyIdleTimer);
      this.lobbyIdleTimer = null;
    }
    // Auto-disband room after 15 minutes of idle in lobby
    if (this.isHost && !this.gameStarted) {
      this.lobbyIdleTimer = setTimeout(() => {
        const msg = '房間在大廳閒置超過 15 分鐘無操作，系統已自動解散房間！';
        this.disbandRoom(msg);
        if (this.onRoomDisbanded) this.onRoomDisbanded(msg);
      }, 15 * 60 * 1000);
    }
  }

  disbandRoom(reason = '房主已解散房間') {
    if (this.isHost) {
      const packet = {
        type: 'ROOM_DISBANDED',
        reason
      };
      for (const guest of this.guestConns.values()) {
        if (guest.conn && guest.conn.open) {
          try {
            guest.conn.send(packet);
          } catch (e) {
            console.warn('Error sending disband packet to guest:', e);
          }
        }
      }
    }
    this.disconnect();
  }

  // ==========================================
  // HOST ROOM CREATION
  // ==========================================
  createRoom(roomCode, hostName = '房主', allowStacking = true, gameMode = 'ffa') {
    this.isHost = true;
    this.roomCode = roomCode.toUpperCase();
    this.playerName = hostName.trim() || '房主';
    this.allowStacking = allowStacking;
    this.allowChallengeWildDraw4 = true;
    this.gameMode = gameMode;
    this.gameStarted = false;
    this.guestConns.clear();
    this.resetLobbyIdleTimer();
    if (this.dealTimer) {
      clearTimeout(this.dealTimer);
      this.dealTimer = null;
    }
    if (this.aiTimer) {
      clearTimeout(this.aiTimer);
      this.aiTimer = null;
    }
    if (this.turnTimeoutTimer) {
      clearTimeout(this.turnTimeoutTimer);
      this.turnTimeoutTimer = null;
    }
    this.engine = null;
    this.ai = null;

    const hostPeerId = this.formatPeerId(this.roomCode);

    this.initLobbySlots();

    if (this.peer) this.peer.destroy();

    this.peer = new Peer(hostPeerId, {
      debug: 1,
      config: {
        iceServers: [
          { urls: 'stun:stun.l.google.com:19302' },
          { urls: 'stun:stun1.l.google.com:19302' },
          { urls: 'stun:stun2.l.google.com:19302' }
        ]
      }
    });

    this.peer.on('open', (id) => {
      if (this.onConnectionStatus) this.onConnectionStatus({ status: 'connected', peerId: id, isHost: true });
      this.broadcastLobbyUpdate();
    });

    this.peer.on('connection', (conn) => {
      this.handleIncomingConnection(conn);
    });

    this.peer.on('error', (err) => {
      console.error('PeerJS Host Error:', err);
      if (this.onError) this.onError(err.type === 'unavailable-id' ? '該房號已被佔用，請重新產生房號！' : `連線錯誤: ${err.message}`);
    });
  }

  initLobbySlots() {
    const count = this.gameMode === '2v2' ? 4 : (this.lobbyPlayers.length >= 2 ? this.lobbyPlayers.length : 4);
    const slots = [];
    for (let i = 0; i < count; i++) {
      const isHost = i === 0;
      const teamId = this.gameMode === '2v2' ? (i % 2 === 0 ? 'team_a' : 'team_b') : null;
      const teamName = this.gameMode === '2v2' ? (i % 2 === 0 ? '金隊 (隊伍 A)' : '藍隊 (隊伍 B)') : null;
      const partnerIdx = this.gameMode === '2v2' ? (i + 2) % 4 : null;

      slots.push({
        id: i,
        name: isHost ? this.playerName : `電腦 ${i}`,
        isHost,
        isAi: !isHost,
        isReady: true,
        peerId: isHost ? 'host' : null,
        teamId,
        teamName,
        partnerIdx
      });
    }
    this.lobbyPlayers = slots;
  }

  handleIncomingConnection(conn) {
    conn.on('open', () => {
      conn.on('data', (data) => {
        this.handleHostData(conn, data);
      });
    });

    conn.on('close', () => {
      this.handleGuestDisconnect(conn.peer);
    });

    conn.on('error', (err) => {
      console.warn('Guest connection error:', err);
      this.handleGuestDisconnect(conn.peer);
    });
  }

  handleGuestDisconnect(peerId) {
    const guestInfo = this.guestConns.get(peerId);
    if (!guestInfo) return;

    const slotIndex = guestInfo.slotIndex;
    this.guestConns.delete(peerId);

    if (!this.gameStarted) {
      if (this.lobbyPlayers[slotIndex]) {
        this.lobbyPlayers[slotIndex].name = `電腦 ${slotIndex}`;
        this.lobbyPlayers[slotIndex].isAi = true;
        this.lobbyPlayers[slotIndex].peerId = null;
        this.broadcastLobbyUpdate();
      }
    } else {
      if (this.engine && this.engine.players[slotIndex]) {
        this.engine.players[slotIndex].isAi = true;
        this.engine.players[slotIndex].name = `${this.engine.players[slotIndex].name} (AI 託管)`;
        this.engine.addLog(`⚠️ 玩家 ${guestInfo.name} 斷線，已自動切換為 AI 電腦託管！`);
        this.broadcastGameState();
        this.checkAiTurn();
      }
    }
  }

  handleHostData(conn, packet) {
    if (!packet || !packet.type) return;

    switch (packet.type) {
      case 'JOIN': {
        const guestName = (packet.name || '訪客').trim();
        
        // Find empty slot (either open "待加入..." or AI bot)
        let targetSlotIdx = this.lobbyPlayers.findIndex((p, idx) => idx > 0 && !p.isAi && !p.peerId);
        if (targetSlotIdx === -1) {
          targetSlotIdx = this.lobbyPlayers.findIndex((p, idx) => idx > 0 && p.isAi);
        }

        if (targetSlotIdx === -1) {
          conn.send({ type: 'JOIN_REJECTED', reason: '房間已滿！' });
          conn.close();
          return;
        }

        this.lobbyPlayers[targetSlotIdx].name = guestName;
        this.lobbyPlayers[targetSlotIdx].isAi = false;
        this.lobbyPlayers[targetSlotIdx].isReady = true;
        this.lobbyPlayers[targetSlotIdx].peerId = conn.peer;

        this.guestConns.set(conn.peer, {
          conn,
          name: guestName,
          slotIndex: targetSlotIdx
        });

        conn.send({
          type: 'JOIN_ACCEPTED',
          slotIndex: targetSlotIdx,
          roomCode: this.roomCode,
          gameMode: this.gameMode,
          allowStacking: this.allowStacking,
          allowChallengeWildDraw4: this.allowChallengeWildDraw4,
          targetScore: this.targetScore,
          drawRule: this.drawRule
        });

        this.broadcastLobbyUpdate();

        if (this.gameStarted && this.engine) {
          conn.send({
            type: 'SYNC_STATE',
            state: this.engine.getClientState(targetSlotIdx)
          });
        }
        break;
      }

      case 'ACTION_PLAY': {
        if (!this.gameStarted || !this.engine || this.engine.isDealing) return;
        if (this.isContinuousDrawing) return;
        const guest = this.guestConns.get(conn.peer);
        if (!guest) return;

        if (packet.calledUno) {
          this.engine.callUno(guest.slotIndex);
        }

        const res = this.engine.playCard(guest.slotIndex, packet.cardId, packet.chosenColor);
        if (res.success) {
          if (res.isChoosingColor) {
            soundManager.playCard();
            this.broadcastSoundEvent('card');
            this.broadcastGameState();
            this.resetTurnTimer();
            break;
          }

          if (res.card.color === 'wild') soundManager.playWild();
          else if (['skip', 'reverse', 'draw2', 'wild_draw4'].includes(res.card.value)) soundManager.playAction();
          else soundManager.playCard();

          if (res.gameOver) soundManager.playVictory();

          this.broadcastSoundEvent(res.card.color === 'wild' ? 'wild' : (['skip', 'reverse', 'draw2', 'wild_draw4'].includes(res.card.value) ? 'action' : 'card'));
          this.broadcastGameState();
          this.checkAiTurn();
        } else {
          conn.send({ type: 'ACTION_FAILED', reason: res.reason });
        }
        break;
      }

      case 'ACTION_CHOOSE_COLOR': {
        if (!this.gameStarted || !this.engine) return;
        const guest = this.guestConns.get(conn.peer);
        if (!guest) return;

        const res = this.engine.confirmWildColor(guest.slotIndex, packet.chosenColor);
        if (res.success) {
          soundManager.playWild();
          this.broadcastSoundEvent('wild');
          this.broadcastGameState();
          this.checkAiTurn();
        }
        break;
      }

      case 'ACTION_DRAW': {
        if (!this.gameStarted || !this.engine || this.engine.isDealing) return;
        if (this.isContinuousDrawing) return;
        const guest = this.guestConns.get(conn.peer);
        if (!guest) return;

        if (this.engine.currentTurn !== guest.slotIndex) {
          conn.send({ type: 'ACTION_FAILED', reason: '不是你的回合！' });
          return;
        }

        // Draw starts: cancel turn timeout timer!
        if (this.turnTimeoutTimer) {
          clearTimeout(this.turnTimeoutTimer);
          this.turnTimeoutTimer = null;
        }

        // Active penalty pool: draw penalty cards one by one
        if (this.engine.stackedDrawCount > 0) {
          this.executePenaltyDraw(guest.slotIndex);
          break;
        }

        // Voluntary draw can only be done ONCE per turn
        if (this.engine.hasDrawnThisTurn) {
          conn.send({ type: 'ACTION_FAILED', reason: '本回合已經主動抽過牌了！' });
          break;
        }

        // If continuous drawing rule is active:
        if (this.drawRule === 'draw_until_playable') {
          this.executeContinuousDraw(guest.slotIndex);
          break;
        }

        const res = this.engine.playerDrawCard(guest.slotIndex);
        if (res.success) {
          soundManager.playDraw();
          this.broadcastSoundEvent('draw');
          this.broadcastGameState();

          if (!res.canPlay) {
            // Cannot play: wait 750ms (300ms flight + 450ms natural pause) before advancing turn!
            this.isContinuousDrawing = true;
            setTimeout(() => {
              this.isContinuousDrawing = false;
              if (!this.engine || this.engine.gameStatus === 'game_over') return;
              this.engine.finishAutoPass(guest.slotIndex, res.card);
              this.broadcastGameState();
              this.checkAiTurn();
            }, 750);
          } else {
            // Playable card drawn: wait 380ms for flight to land before starting 15s timer!
            this.isContinuousDrawing = true;
            setTimeout(() => {
              this.isContinuousDrawing = false;
              if (!this.engine || this.engine.gameStatus === 'game_over') return;
              this.engine.turnStartTime = Date.now();
              this.engine.turnDuration = 15;
              this.resetTurnTimer();
              this.broadcastGameState();
            }, 380);
          }
        } else {
          conn.send({ type: 'ACTION_FAILED', reason: res.reason });
        }
        break;
      }

      case 'ACTION_PASS': {
        if (!this.gameStarted || !this.engine) return;
        const guest = this.guestConns.get(conn.peer);
        if (!guest) return;

        const res = this.engine.passTurn(guest.slotIndex);
        if (res.success) {
          this.broadcastGameState();
          this.checkAiTurn();
        } else {
          conn.send({ type: 'ACTION_FAILED', reason: res.reason });
        }
        break;
      }

      case 'ACTION_UNO': {
        if (!this.gameStarted || !this.engine) return;
        const guest = this.guestConns.get(conn.peer);
        if (!guest) return;

        const res = this.engine.callUno(guest.slotIndex);
        if (res.success) {
          soundManager.playUno();
          this.broadcastSoundEvent('uno');
          this.broadcastGameState();
        }
        break;
      }

      case 'ACTION_CHALLENGE': {
        if (!this.gameStarted || !this.engine) return;
        const guest = this.guestConns.get(conn.peer);
        if (!guest) return;

        const res = this.engine.challengeUno(guest.slotIndex, packet.targetIndex);
        if (res.success && res.caught) {
          soundManager.playPenalty();
          this.broadcastSoundEvent('penalty');
          this.broadcastGameState();
        }
        break;
      }

      case 'ACTION_CHALLENGE_WILD_DRAW4': {
        if (!this.gameStarted || !this.engine) return;
        const guest = this.guestConns.get(conn.peer);
        if (!guest) return;

        const res = this.engine.challengeWildDraw4(guest.slotIndex);
        if (res.success) {
          soundManager.playPenalty();
          this.broadcastSoundEvent('penalty');
          this.broadcastGameState();
          this.checkAiTurn();
        } else {
          conn.send({ type: 'ACTION_FAILED', reason: res.reason });
        }
        break;
      }

      default:
        break;
    }
  }

  // Toggle Game Mode between 'ffa' and '2v2' (Host only)
  setGameMode(mode) {
    if (!this.isHost || this.gameStarted) return;
    this.gameMode = mode;
    this.initLobbySlots();
    this.broadcastLobbyUpdate();
  }

  // Set Player Count in FFA Mode: 2, 3, or 4 (Host only)
  setFfaPlayerCount(count) {
    if (!this.isHost || this.gameStarted || this.gameMode === '2v2') return;
    const targetCount = Math.max(2, Math.min(4, count));
    if (targetCount === this.lobbyPlayers.length) return;

    if (targetCount > this.lobbyPlayers.length) {
      for (let i = this.lobbyPlayers.length; i < targetCount; i++) {
        this.lobbyPlayers.push({
          id: i,
          name: `電腦 ${i}`,
          isHost: false,
          isAi: true,
          isReady: true,
          peerId: null
        });
      }
    } else {
      // Shrinking: kick guests in removed slots
      for (let i = targetCount; i < this.lobbyPlayers.length; i++) {
        const p = this.lobbyPlayers[i];
        if (p.peerId) {
          const guest = this.guestConns.get(p.peerId);
          if (guest && guest.conn) {
            guest.conn.send({ type: 'KICKED', reason: '房主縮減人數' });
            guest.conn.close();
          }
          this.guestConns.delete(p.peerId);
        }
      }
      this.lobbyPlayers = this.lobbyPlayers.slice(0, targetCount);
    }

    this.broadcastLobbyUpdate();
  }

  // Swap two slots (Host only, crucial for 2v2 teammate configuration!)
  swapSlots(idxA, idxB) {
    if (!this.isHost || this.gameStarted) return;
    if (idxA === idxB || !this.lobbyPlayers[idxA] || !this.lobbyPlayers[idxB]) return;

    const pA = { ...this.lobbyPlayers[idxA] };
    const pB = { ...this.lobbyPlayers[idxB] };

    // Swap slots, keeping their respective slot id and team attributes
    this.lobbyPlayers[idxA] = {
      ...pB,
      id: idxA,
      isHost: idxA === 0,
      teamId: this.gameMode === '2v2' ? (idxA % 2 === 0 ? 'team_a' : 'team_b') : null,
      teamName: this.gameMode === '2v2' ? (idxA % 2 === 0 ? '金隊 (隊伍 A)' : '藍隊 (隊伍 B)') : null,
      partnerIdx: this.gameMode === '2v2' ? (idxA + 2) % 4 : null
    };

    this.lobbyPlayers[idxB] = {
      ...pA,
      id: idxB,
      isHost: idxB === 0,
      teamId: this.gameMode === '2v2' ? (idxB % 2 === 0 ? 'team_a' : 'team_b') : null,
      teamName: this.gameMode === '2v2' ? (idxB % 2 === 0 ? '金隊 (隊伍 A)' : '藍隊 (隊伍 B)') : null,
      partnerIdx: this.gameMode === '2v2' ? (idxB + 2) % 4 : null
    };

    // Update guestConns mappings
    if (pA.peerId && this.guestConns.has(pA.peerId)) {
      this.guestConns.get(pA.peerId).slotIndex = idxB;
    }
    if (pB.peerId && this.guestConns.has(pB.peerId)) {
      this.guestConns.get(pB.peerId).slotIndex = idxA;
    }

    this.broadcastLobbyUpdate();
  }

  // Toggle Slot between Computer Bot (AI) and Open for Human
  toggleSlotAi(slotIndex) {
    if (!this.isHost || slotIndex === 0 || this.gameStarted) return;
    const p = this.lobbyPlayers[slotIndex];
    if (!p) return;

    if (!p.isAi && p.peerId) {
      // Kick human guest and turn into Bot
      const guest = this.guestConns.get(p.peerId);
      if (guest && guest.conn) {
        guest.conn.send({ type: 'KICKED', reason: '已被房主移除！' });
        guest.conn.close();
      }
      this.guestConns.delete(p.peerId);
      p.isAi = true;
      p.name = `電腦 ${slotIndex}`;
      p.peerId = null;
    } else if (p.isAi) {
      // Switch from Bot to Open for Human
      p.isAi = false;
      p.name = `開放玩家加入...`;
      p.peerId = null;
    } else {
      // Switch from Open back to Bot
      p.isAi = true;
      p.name = `電腦 ${slotIndex}`;
      p.peerId = null;
    }

    this.broadcastLobbyUpdate();
  }

  toggleStackingRule() {
    if (!this.isHost || this.gameStarted) return;
    this.allowStacking = !this.allowStacking;
    this.broadcastLobbyUpdate();
  }

  toggleChallengeRule() {
    if (!this.isHost || this.gameStarted) return;
    this.allowChallengeWildDraw4 = !this.allowChallengeWildDraw4;
    this.broadcastLobbyUpdate();
  }

  setTargetScore(score) {
    if (!this.isHost || this.gameStarted) return;
    this.targetScore = Number(score);
    this.broadcastLobbyUpdate();
  }

  setDrawRule(rule) {
    if (!this.isHost || this.gameStarted) return;
    this.drawRule = rule;
    this.broadcastLobbyUpdate();
  }

  // Start Multiplayer Game (Host only)
  startGame() {
    if (!this.isHost || this.gameStarted) return;

    // Fill any remaining open slots with AI Bots
    this.lobbyPlayers.forEach((p, idx) => {
      if (!p.peerId && !p.isHost && !p.isAi) {
        p.isAi = true;
        p.name = `電腦 ${idx}`;
      }
    });

    this.gameStarted = true;
    if (this.lobbyIdleTimer) {
      clearTimeout(this.lobbyIdleTimer);
      this.lobbyIdleTimer = null;
    }

    // Create authoritative engine with 2v2 support & custom rules
    this.engine = new UnoEngine(
      this.lobbyPlayers.length,
      this.lobbyPlayers,
      this.allowStacking,
      this.gameMode,
      {
        targetScore: this.targetScore,
        drawRule: this.drawRule,
        allowChallengeWildDraw4: this.allowChallengeWildDraw4
      }
    );
    this.ai = new UnoAI(this.engine);

    // Initial game state has isDealing = true
    this.broadcastGameState();

    // Wait 2200ms for opening deal animation to fully complete before starting first turn!
    if (this.dealTimer) {
      clearTimeout(this.dealTimer);
      this.dealTimer = null;
    }
    this.dealTimer = setTimeout(() => {
      if (!this.engine || this.engine.gameStatus === 'game_over') return;
      this.engine.finishDealing();
      this.broadcastGameState();

      const hostIdx = this.getHostIndex();
      if (this.engine.currentTurn === hostIdx) {
        soundManager.playTurn();
      } else {
        this.checkAiTurn();
      }
    }, 2200);
  }

  startNextRound(resetMatch = false) {
    if (!this.isHost || !this.engine) return;

    if (resetMatch) {
      this.lobbyPlayers.forEach(p => { p.score = 0; });
      if (this.engine.players) this.engine.players.forEach(p => { p.score = 0; });
      this.engine.isMatchOver = false;
      this.engine.matchWinner = null;
    } else {
      // Sync latest scores from engine to lobbyPlayers
      if (this.engine.players) {
        this.engine.players.forEach(ep => {
          const lp = this.lobbyPlayers.find(p => p.id === ep.id);
          if (lp) lp.score = ep.score;
        });
      }
    }

    this.engine.reset();
    this.broadcastGameState();

    // Wait 2200ms for opening deal animation to fully complete before starting round
    if (this.dealTimer) {
      clearTimeout(this.dealTimer);
      this.dealTimer = null;
    }
    this.dealTimer = setTimeout(() => {
      if (!this.engine || this.engine.gameStatus === 'game_over') return;
      this.engine.finishDealing();
      this.broadcastGameState();

      const hostIdx = this.getHostIndex();
      if (this.engine.currentTurn === hostIdx) {
        soundManager.playTurn();
      } else {
        this.checkAiTurn();
      }
    }, 2200);
  }

  restartGame() {
    this.startNextRound(false);
  }

  returnToLobby() {
    if (!this.isHost) return;
    if (this.dealTimer) {
      clearTimeout(this.dealTimer);
      this.dealTimer = null;
    }
    if (this.aiTimer) {
      clearTimeout(this.aiTimer);
      this.aiTimer = null;
    }
    if (this.turnTimeoutTimer) {
      clearTimeout(this.turnTimeoutTimer);
      this.turnTimeoutTimer = null;
    }
    this.gameStarted = false;
    this.resetLobbyIdleTimer();
    if (this.engine && this.engine.players) {
      this.engine.players.forEach(ep => {
        const lp = this.lobbyPlayers.find(p => p.id === ep.id);
        if (lp) lp.score = ep.score;
      });
    }
    this.broadcastReturnToLobby();
  }

  broadcastReturnToLobby() {
    const data = {
      type: 'RETURN_TO_LOBBY',
      players: this.lobbyPlayers,
      gameMode: this.gameMode,
      allowStacking: this.allowStacking,
      allowChallengeWildDraw4: this.allowChallengeWildDraw4,
      targetScore: this.targetScore,
      drawRule: this.drawRule,
      roomCode: this.roomCode
    };

    if (this.onReturnToLobby) this.onReturnToLobby(data);

    for (const guest of this.guestConns.values()) {
      if (guest.conn && guest.conn.open) {
        guest.conn.send(data);
      }
    }
  }

  resetTurnTimer() {
    if (this.turnTimeoutTimer) {
      clearTimeout(this.turnTimeoutTimer);
      this.turnTimeoutTimer = null;
    }

    if (!this.isHost || !this.engine || this.engine.gameStatus === 'game_over' || this.engine.isDealing || this.isContinuousDrawing) {
      return;
    }

    // Color Selection Phase: 6 seconds timeout!
    if (this.engine.isChoosingColor) {
      const choosingIdx = this.engine.colorChoosingPlayerIndex;
      const choosingPlayer = this.engine.players[choosingIdx];
      if (choosingPlayer && !choosingPlayer.isAi) {
        this.turnTimeoutTimer = setTimeout(() => {
          this.handleColorTimeout(choosingIdx);
        }, 6000);
      }
      return;
    }

    const curIdx = this.engine.currentTurn;
    const curPlayer = this.engine.players[curIdx];
    if (!curPlayer) return;

    // AI operates on quick aiTimer (800-1200ms)
    if (!curPlayer.isAi) {
      this.turnTimeoutTimer = setTimeout(() => {
        this.handleTurnTimeout(curIdx);
      }, 15000);
    }
  }

  handleColorTimeout(playerIndex) {
    if (!this.isHost || !this.engine || !this.engine.isChoosingColor) return;
    if (this.engine.colorChoosingPlayerIndex !== playerIndex) return;

    const player = this.engine.players[playerIndex];
    const autoColor = this.engine.getBestColorForPlayer(playerIndex);
    this.engine.addLog(`⏰ 【${player?.name || '玩家'}】選色超時 (6 秒)，系統自動為其指定【${this.engine.colorNames[autoColor]}】！`);

    const res = this.engine.confirmWildColor(playerIndex, autoColor);
    if (res.success) {
      soundManager.playWild();
      this.broadcastSoundEvent('wild');
      this.broadcastGameState();
      this.checkAiTurn();
    }
  }

  handleTurnTimeout(playerIndex) {
    if (!this.isHost || !this.engine || this.engine.gameStatus === 'game_over' || this.engine.isDealing) return;
    if (this.engine.currentTurn !== playerIndex) return;

    const player = this.engine.players[playerIndex];
    if (!player) return;

    // 1. If player was facing stacked penalty, execute penalty draw
    if (this.engine.stackedDrawCount > 0) {
      this.executePenaltyDraw(playerIndex);
      return;
    }

    // 2. If player has already drawn this turn, auto-pass
    if (this.engine.hasDrawnThisTurn) {
      this.engine.addLog(`⏰ 【${player.name}】思考超時 (15 秒)，系統自動過牌！`);
      const passRes = this.engine.passTurn(playerIndex);
      if (passRes.success) {
        this.broadcastGameState();
        this.checkAiTurn();
      }
      return;
    }

    // 3. Player hasn't drawn: auto draw 1 card and pass!
    const card = this.engine.drawCardRaw();
    player.hand.push(card);
    if (player.hand.length > 1) {
      player.calledUno = false;
      player.unoVulnerable = false;
      player.pendingUnoCall = false;
    }

    this.engine.addLog(`⏰ 【${player.name}】思考超時 (15 秒)，系統自動抽一張牌並過牌！`);
    soundManager.playDraw();
    this.broadcastSoundEvent('draw');

    this.engine.advanceTurn(1);
    this.broadcastGameState();
    this.checkAiTurn();
  }

  checkAiTurn() {
    if (!this.isHost || !this.engine || this.engine.gameStatus === 'game_over' || this.engine.isDealing) return;

    if (this.aiTimer) {
      clearTimeout(this.aiTimer);
      this.aiTimer = null;
    }

    this.resetTurnTimer();

    const curIdx = this.engine.currentTurn;
    const curPlayer = this.engine.players[curIdx];
    const hostIdx = this.getHostIndex();

    if (!curPlayer || !curPlayer.isAi) {
      if (curIdx === hostIdx) {
        soundManager.playTurn();
      }
      return;
    }

    const delay = 800 + Math.random() * 400;
    this.aiTimer = setTimeout(() => {
      this.executeAiTurn(curIdx);
    }, delay);
  }

  executeAiTurn(aiIndex) {
    if (!this.isHost || !this.engine || this.engine.currentTurn !== aiIndex || this.engine.gameStatus === 'game_over' || this.engine.isDealing) return;

    const move = this.ai.decideMove(aiIndex);
    if (!move) return;

    if (move.action === 'challenge') {
      const res = this.engine.challengeUno(aiIndex, move.targetIndex);
      if (res.success && res.caught) {
        soundManager.playPenalty();
        this.broadcastSoundEvent('penalty');
        this.broadcastGameState();
      }
      this.checkAiTurn();
      return;
    }

    if (move.action === 'challenge_wild_draw4') {
      const res = this.engine.challengeWildDraw4(aiIndex);
      if (res.success) {
        soundManager.playPenalty();
        this.broadcastSoundEvent('penalty');
        this.broadcastGameState();
      }
      this.checkAiTurn();
      return;
    }

    if (move.callUno) {
      this.engine.callUno(aiIndex);
      soundManager.playUno();
      this.broadcastSoundEvent('uno');
    }

    if (move.action === 'play') {
      const res = this.engine.playCard(aiIndex, move.card.id, move.chosenColor);
      if (res.success) {
        if (res.card.color === 'wild') soundManager.playWild();
        else if (['skip', 'reverse', 'draw2', 'wild_draw4'].includes(res.card.value)) soundManager.playAction();
        else soundManager.playCard();

        if (res.gameOver) soundManager.playVictory();

        this.broadcastSoundEvent(res.card.color === 'wild' ? 'wild' : (['skip', 'reverse', 'draw2', 'wild_draw4'].includes(res.card.value) ? 'action' : 'card'));
        this.broadcastGameState();
        this.checkAiTurn();
      }
    } else if (move.action === 'draw') {
      if (this.engine.stackedDrawCount > 0) {
        this.executePenaltyDraw(aiIndex);
        return;
      }

      if (this.drawRule === 'draw_until_playable') {
        this.executeContinuousDraw(aiIndex, (res) => {
          if (res && res.canPlay && res.card) {
            setTimeout(() => {
              if (this.engine && this.engine.currentTurn === aiIndex) {
                const card = res.card;
                let chosenColor = null;
                if (card.color === 'wild') chosenColor = this.ai.getBestColorForHand(this.engine.players[aiIndex].hand);
                const playRes = this.engine.playCard(aiIndex, card.id, chosenColor);
                if (playRes.success) {
                  if (card.color === 'wild') soundManager.playWild();
                  else soundManager.playCard();
                  this.broadcastSoundEvent(card.color === 'wild' ? 'wild' : 'card');
                  this.broadcastGameState();
                  this.checkAiTurn();
                }
              }
            }, 600);
          } else {
            this.checkAiTurn();
          }
        });
        return;
      }

      const res = this.engine.playerDrawCard(aiIndex);
      if (res.success) {
        soundManager.playDraw();
        this.broadcastSoundEvent('draw');
        this.broadcastGameState();

        if (res.canPlay) {
          setTimeout(() => {
            if (this.engine && this.engine.currentTurn === aiIndex) {
              const card = res.card;
              let chosenColor = null;
              if (card.color === 'wild') chosenColor = this.ai.getBestColorForHand(this.engine.players[aiIndex].hand);
              const playRes = this.engine.playCard(aiIndex, card.id, chosenColor);
              if (playRes.success) {
                if (card.color === 'wild') soundManager.playWild();
                else soundManager.playCard();
                this.broadcastSoundEvent(card.color === 'wild' ? 'wild' : 'card');
                this.broadcastGameState();
                this.checkAiTurn();
              }
            }
          }, 600);
        } else {
          setTimeout(() => {
            if (!this.engine || this.engine.gameStatus === 'game_over') return;
            this.engine.finishAutoPass(aiIndex, res.card);
            this.broadcastGameState();
            this.checkAiTurn();
          }, 750);
        }
      }
    }
  }

  // Continuous one-by-one drawing sequence
  executeContinuousDraw(playerIndex, onComplete) {
    if (!this.isHost || !this.engine) return;
    if (this.engine.currentTurn !== playerIndex) return;
    if (this.isContinuousDrawing) return;
    if (this.engine.hasDrawnThisTurn) return;

    this.isContinuousDrawing = true;
    this.engine.isContinuousDrawing = true;
    this.engine.drawingPlayerIndex = playerIndex;
    this.engine.drawingStepCount = 0;

    const drawnCards = [];
    const maxLimit = 25;

    const drawStep = () => {
      if (!this.engine || this.engine.currentTurn !== playerIndex || this.engine.gameStatus === 'game_over') {
        this.finishDrawingCleanup();
        if (onComplete) onComplete({ success: false });
        return;
      }

      const res = this.engine.drawSingleCardStep(playerIndex);
      if (!res.success) {
        this.finishDrawingCleanup();
        if (onComplete) onComplete(res);
        return;
      }

      drawnCards.push(res.card);
      this.engine.drawingStepCount = drawnCards.length;

      // Broadcast single card arrival so everyone sees this card fly & hand increment
      this.broadcastSoundEvent('draw');
      soundManager.playDraw();
      this.broadcastGameState();

      // Check if the newly drawn card is playable
      if (res.canPlay || drawnCards.length >= maxLimit || (this.engine.drawPile.length === 0 && this.engine.discardPile.length <= 1)) {
        setTimeout(() => {
          if (!this.engine) return;
          const finalRes = this.engine.finishContinuousDraw(playerIndex, drawnCards, res.canPlay);
          this.finishDrawingCleanup();
          this.broadcastGameState();

          if (onComplete) onComplete(finalRes);
        }, 380);
      } else {
        // Draw next card with delay so each card flies rhythmically one by one
        this.continuousDrawTimer = setTimeout(() => {
          drawStep();
        }, 420);
      }
    };

    drawStep();
  }

  // Penalty draw sequence: deals each penalty card one by one with visible flight
  executePenaltyDraw(playerIndex, onComplete) {
    if (!this.isHost || !this.engine) return;
    if (this.isContinuousDrawing) return;

    const countToDraw = this.engine.stackedDrawCount;
    if (countToDraw <= 0) return;

    this.isContinuousDrawing = true;
    this.engine.isContinuousDrawing = true;
    this.engine.drawingPlayerIndex = playerIndex;
    this.engine.drawingStepCount = 0;

    let drawn = 0;

    const step = () => {
      if (!this.engine || this.engine.gameStatus === 'game_over') {
        this.finishDrawingCleanup();
        if (onComplete) onComplete({ success: false });
        return;
      }

      const res = this.engine.drawSingleCardStep(playerIndex);
      if (!res.success) {
        this.finishDrawingCleanup();
        if (onComplete) onComplete(res);
        return;
      }

      drawn++;
      this.engine.drawingStepCount = drawn;

      this.broadcastSoundEvent('draw');
      soundManager.playDraw();
      this.broadcastGameState();

      if (drawn >= countToDraw) {
        // Wait 700ms so the last card lands cleanly and spectators see the full penalty
        setTimeout(() => {
          if (!this.engine) return;
          this.engine.finishPenaltyDraw(playerIndex, countToDraw);
          this.finishDrawingCleanup();
          soundManager.playPenalty();
          this.broadcastSoundEvent('penalty');
          this.broadcastGameState();
          this.checkAiTurn();
          if (onComplete) onComplete({ success: true, count: countToDraw });
        }, 700);
      } else {
        // Next penalty card with 300ms spacing
        this.continuousDrawTimer = setTimeout(() => {
          step();
        }, 300);
      }
    };

    step();
  }

  finishDrawingCleanup() {
    this.isContinuousDrawing = false;
    if (this.continuousDrawTimer) {
      clearTimeout(this.continuousDrawTimer);
      this.continuousDrawTimer = null;
    }
    if (this.engine) {
      this.engine.isContinuousDrawing = false;
      this.engine.drawingPlayerIndex = null;
      this.engine.drawingStepCount = 0;
    }
  }

  getHostIndex() {
    const idx = this.lobbyPlayers.findIndex(p => p.isHost);
    return idx !== -1 ? idx : 0;
  }

  // Host local player actions
  hostPlayCard(cardId, chosenColor, calledUno) {
    if (!this.isHost || !this.engine || this.engine.isDealing) return { success: false, reason: '開局發牌中，尚未能出牌' };
    if (this.isContinuousDrawing) return { success: false, reason: '正在抽牌中' };
    const hostIdx = this.getHostIndex();
    if (calledUno) this.engine.callUno(hostIdx);

    const res = this.engine.playCard(hostIdx, cardId, chosenColor);
    if (res.success) {
      if (res.isChoosingColor) {
        soundManager.playCard();
        this.broadcastSoundEvent('card');
        this.broadcastGameState();
        this.resetTurnTimer();
        return res;
      }

      if (res.card.color === 'wild') soundManager.playWild();
      else if (['skip', 'reverse', 'draw2', 'wild_draw4'].includes(res.card.value)) soundManager.playAction();
      else soundManager.playCard();

      if (res.gameOver) soundManager.playVictory();

      this.broadcastSoundEvent(res.card.color === 'wild' ? 'wild' : (['skip', 'reverse', 'draw2', 'wild_draw4'].includes(res.card.value) ? 'action' : 'card'));
      this.broadcastGameState();
      this.checkAiTurn();
    }
    return res;
  }

  hostChooseColor(chosenColor) {
    if (!this.isHost || !this.engine) return { success: false };
    const hostIdx = this.getHostIndex();
    const res = this.engine.confirmWildColor(hostIdx, chosenColor);
    if (res.success) {
      soundManager.playWild();
      this.broadcastSoundEvent('wild');
      this.broadcastGameState();
      this.checkAiTurn();
    }
    return res;
  }

  hostDrawCard() {
    if (!this.isHost || !this.engine || this.engine.isDealing) return { success: false, reason: '開局發牌中，尚未能抽牌' };
    if (this.isContinuousDrawing) return { success: false, reason: '正在抽牌中' };
    const hostIdx = this.getHostIndex();
    if (this.engine.currentTurn !== hostIdx) return { success: false, reason: '不是你的回合！' };

    // Drawing starts: CANNOT be idle time!
    if (this.turnTimeoutTimer) {
      clearTimeout(this.turnTimeoutTimer);
      this.turnTimeoutTimer = null;
    }

    // Active penalty pool: draw penalty cards one by one
    if (this.engine.stackedDrawCount > 0) {
      this.executePenaltyDraw(hostIdx);
      return { success: true, penalty: true };
    }

    // Voluntary draw can only be done ONCE per turn
    if (this.engine.hasDrawnThisTurn) {
      return { success: false, reason: '本回合已經主動抽過牌了！' };
    }

    // If continuous drawing rule is active:
    if (this.drawRule === 'draw_until_playable') {
      this.executeContinuousDraw(hostIdx);
      return { success: true, continuous: true };
    }

    const res = this.engine.playerDrawCard(hostIdx);
    if (res.success) {
      soundManager.playDraw();
      this.broadcastSoundEvent('draw');
      this.broadcastGameState();

      if (!res.canPlay) {
        // Cannot play: wait 750ms before advancing turn to next player!
        this.isContinuousDrawing = true;
        setTimeout(() => {
          this.isContinuousDrawing = false;
          if (!this.engine || this.engine.gameStatus === 'game_over') return;
          this.engine.finishAutoPass(hostIdx, res.card);
          this.broadcastGameState();
          this.checkAiTurn();
        }, 750);
      } else {
        // Playable card drawn: wait 380ms for card flight to reach hand before starting 15s timer!
        this.isContinuousDrawing = true;
        setTimeout(() => {
          this.isContinuousDrawing = false;
          if (!this.engine || this.engine.gameStatus === 'game_over') return;
          this.engine.turnStartTime = Date.now();
          this.engine.turnDuration = 15;
          this.resetTurnTimer();
          this.broadcastGameState();
        }, 380);
      }
    }
    return res;
  }

  hostPassTurn() {
    if (!this.isHost || !this.engine) return { success: false, reason: '未在遊戲中' };
    const hostIdx = this.getHostIndex();
    const res = this.engine.passTurn(hostIdx);
    if (res.success) {
      this.broadcastGameState();
      this.checkAiTurn();
    }
    return res;
  }

  hostCallUno() {
    if (!this.isHost || !this.engine) return { success: false };
    const hostIdx = this.getHostIndex();
    const res = this.engine.callUno(hostIdx);
    if (res.success) {
      soundManager.playUno();
      this.broadcastSoundEvent('uno');
      this.broadcastGameState();
    }
    return res;
  }

  hostChallengeUno(targetIndex) {
    if (!this.isHost || !this.engine) return { success: false };
    const hostIdx = this.getHostIndex();
    const res = this.engine.challengeUno(hostIdx, targetIndex);
    if (res.success && res.caught) {
      soundManager.playPenalty();
      this.broadcastSoundEvent('penalty');
      this.broadcastGameState();
    }
    return res;
  }

  hostChallengeWildDraw4() {
    if (!this.isHost || !this.engine) return { success: false };
    const hostIdx = this.getHostIndex();
    const res = this.engine.challengeWildDraw4(hostIdx);
    if (res.success) {
      soundManager.playPenalty();
      this.broadcastSoundEvent('penalty');
      this.broadcastGameState();
      this.checkAiTurn();
    }
    return res;
  }

  // Broadcasts
  broadcastLobbyUpdate() {
    this.resetLobbyIdleTimer();
    const data = {
      type: 'LOBBY_UPDATE',
      players: this.lobbyPlayers,
      gameMode: this.gameMode,
      allowStacking: this.allowStacking,
      allowChallengeWildDraw4: this.allowChallengeWildDraw4,
      targetScore: this.targetScore,
      drawRule: this.drawRule,
      roomCode: this.roomCode
    };

    if (this.onLobbyUpdate) this.onLobbyUpdate(data);

    for (const guest of this.guestConns.values()) {
      if (guest.conn && guest.conn.open) {
        guest.conn.send(data);
      }
    }
  }

  broadcastGameState() {
    if (!this.engine) return;

    const hostIdx = this.getHostIndex();
    const hostState = this.engine.getClientState(hostIdx);
    if (this.onStateUpdate) this.onStateUpdate(hostState);

    for (const guest of this.guestConns.values()) {
      if (guest.conn && guest.conn.open) {
        const guestState = this.engine.getClientState(guest.slotIndex);
        guest.conn.send({
          type: 'SYNC_STATE',
          state: guestState
        });
      }
    }
  }

  broadcastSoundEvent(soundName) {
    for (const guest of this.guestConns.values()) {
      if (guest.conn && guest.conn.open) {
        guest.conn.send({
          type: 'SOUND_EVENT',
          sound: soundName
        });
      }
    }
  }

  // ==========================================
  // GUEST / CLIENT JOIN ROOM FLOW
  // ==========================================
  joinRoom(roomCode, guestName = '玩家') {
    this.isHost = false;
    this.roomCode = roomCode.toUpperCase();
    this.playerName = guestName.trim() || '玩家';
    this.gameStarted = false;

    const hostPeerId = this.formatPeerId(this.roomCode);

    if (this.peer) this.peer.destroy();

    this.peer = new Peer({
      debug: 1,
      config: {
        iceServers: [
          { urls: 'stun:stun.l.google.com:19302' },
          { urls: 'stun:stun1.l.google.com:19302' },
          { urls: 'stun:stun2.l.google.com:19302' }
        ]
      }
    });

    this.peer.on('open', (id) => {
      if (this.onConnectionStatus) this.onConnectionStatus({ status: 'connecting', peerId: id, isHost: false });

      this.hostConn = this.peer.connect(hostPeerId, {
        reliable: true
      });

      this.hostConn.on('open', () => {
        if (this.onConnectionStatus) this.onConnectionStatus({ status: 'connected', peerId: id, isHost: false });
        this.hostConn.send({
          type: 'JOIN',
          name: this.playerName
        });
      });

      this.hostConn.on('data', (packet) => {
        this.handleClientData(packet);
      });

      this.hostConn.on('close', () => {
        if (this.onRoomDisbanded) {
          this.onRoomDisbanded('房主已離開或斷線，房間已自動解散！');
        } else if (this.onError) {
          this.onError('與房主之連線已中斷，房間已解散！');
        }
        if (this.onConnectionStatus) this.onConnectionStatus({ status: 'disconnected', isHost: false });
        this.disconnect();
      });

      this.hostConn.on('error', (err) => {
        console.error('Host connection error:', err);
        if (this.onError) this.onError('無法連線至房主，請確認房號是否正確！');
      });
    });

    this.peer.on('error', (err) => {
      console.error('PeerJS Client Error:', err);
      if (this.onError) this.onError(`連線錯誤: ${err.message}`);
    });
  }

  handleClientData(packet) {
    if (!packet || !packet.type) return;

    switch (packet.type) {
      case 'ROOM_DISBANDED':
        if (this.onRoomDisbanded) {
          this.onRoomDisbanded(packet.reason || '房主已解散房間！');
        } else if (this.onError) {
          this.onError(packet.reason || '房主已解散房間！');
        }
        this.disconnect();
        break;
      case 'JOIN_ACCEPTED':
        this.mySlotIndex = packet.slotIndex;
        this.gameMode = packet.gameMode || 'ffa';
        this.allowStacking = packet.allowStacking;
        if (packet.allowChallengeWildDraw4 !== undefined) this.allowChallengeWildDraw4 = packet.allowChallengeWildDraw4;
        this.targetScore = packet.targetScore !== undefined ? packet.targetScore : 500;
        this.drawRule = packet.drawRule || 'draw_one';
        break;

      case 'JOIN_REJECTED':
      case 'KICKED':
        if (this.onError) this.onError(packet.reason || '連線被拒絕');
        this.disconnect();
        break;

      case 'LOBBY_UPDATE':
        this.lobbyPlayers = packet.players;
        this.gameMode = packet.gameMode || 'ffa';
        this.allowStacking = packet.allowStacking;
        if (packet.allowChallengeWildDraw4 !== undefined) this.allowChallengeWildDraw4 = packet.allowChallengeWildDraw4;
        this.targetScore = packet.targetScore !== undefined ? packet.targetScore : 500;
        this.drawRule = packet.drawRule || 'draw_one';
        if (this.onLobbyUpdate) this.onLobbyUpdate(packet);
        break;

      case 'RETURN_TO_LOBBY':
        this.gameStarted = false;
        this.lobbyPlayers = packet.players || this.lobbyPlayers;
        this.gameMode = packet.gameMode || 'ffa';
        this.allowStacking = packet.allowStacking;
        if (packet.allowChallengeWildDraw4 !== undefined) this.allowChallengeWildDraw4 = packet.allowChallengeWildDraw4;
        this.targetScore = packet.targetScore !== undefined ? packet.targetScore : 500;
        this.drawRule = packet.drawRule || 'draw_one';
        if (this.onReturnToLobby) this.onReturnToLobby(packet);
        break;

      case 'SYNC_STATE':
        this.gameStarted = true;
        if (this.onStateUpdate) this.onStateUpdate(packet.state);
        if (packet.state && packet.state.currentTurn === packet.state.myIndex) {
          soundManager.playTurn();
        }
        break;

      case 'SOUND_EVENT':
        if (packet.sound === 'card') soundManager.playCard();
        else if (packet.sound === 'draw') soundManager.playDraw();
        else if (packet.sound === 'action') soundManager.playAction();
        else if (packet.sound === 'wild') soundManager.playWild();
        else if (packet.sound === 'uno') soundManager.playUno();
        else if (packet.sound === 'penalty') soundManager.playPenalty();
        break;

      case 'ACTION_FAILED':
        if (this.onError) this.onError(packet.reason || '動作不合法');
        break;

      default:
        break;
    }
  }

  // Guest actions sent to Host
  clientPlayCard(cardId, chosenColor, calledUno) {
    if (!this.hostConn || !this.hostConn.open) return;
    this.hostConn.send({
      type: 'ACTION_PLAY',
      cardId,
      chosenColor,
      calledUno
    });
  }

  clientDrawCard() {
    if (!this.hostConn || !this.hostConn.open) return;
    this.hostConn.send({ type: 'ACTION_DRAW' });
  }

  clientPassTurn() {
    if (!this.hostConn || !this.hostConn.open) return;
    this.hostConn.send({ type: 'ACTION_PASS' });
  }

  clientCallUno() {
    if (!this.hostConn || !this.hostConn.open) return;
    this.hostConn.send({ type: 'ACTION_UNO' });
  }

  clientChallengeUno(targetIndex) {
    if (!this.hostConn || !this.hostConn.open) return;
    this.hostConn.send({
      type: 'ACTION_CHALLENGE',
      targetIndex
    });
  }

  clientChallengeWildDraw4() {
    if (!this.hostConn || !this.hostConn.open) return;
    this.hostConn.send({
      type: 'ACTION_CHALLENGE_WILD_DRAW4'
    });
  }

  clientChooseColor(chosenColor) {
    if (!this.hostConn || !this.hostConn.open) return;
    this.hostConn.send({
      type: 'ACTION_CHOOSE_COLOR',
      chosenColor
    });
  }

  disconnect() {
    this.finishDrawingCleanup();
    if (this.lobbyIdleTimer) {
      clearTimeout(this.lobbyIdleTimer);
      this.lobbyIdleTimer = null;
    }
    if (this.aiTimer) {
      clearTimeout(this.aiTimer);
      this.aiTimer = null;
    }
    if (this.dealTimer) {
      clearTimeout(this.dealTimer);
      this.dealTimer = null;
    }
    if (this.turnTimeoutTimer) {
      clearTimeout(this.turnTimeoutTimer);
      this.turnTimeoutTimer = null;
    }
    if (this.hostConn) {
      this.hostConn.close();
      this.hostConn = null;
    }
    for (const g of this.guestConns.values()) {
      if (g.conn) g.conn.close();
    }
    this.guestConns.clear();
    if (this.peer) {
      this.peer.destroy();
      this.peer = null;
    }
    this.engine = null;
    this.ai = null;
    this.gameStarted = false;
  }
}

export const p2pNetwork = new P2PNetwork();

`

---

## src/services/sound.js

`javascript
// sound.js - Web Audio API Sound Synthesizer (No external audio files needed)
class SoundManager {
  constructor() {
    this.ctx = null;
    this.muted = false;
  }

  init() {
    if (!this.ctx) {
      const AudioCtx = window.AudioContext || window.webkitAudioContext;
      if (AudioCtx) {
        this.ctx = new AudioCtx();
      }
    }
    if (this.ctx && this.ctx.state === 'suspended') {
      this.ctx.resume();
    }
  }

  toggleMute() {
    this.muted = !this.muted;
    return this.muted;
  }

  // Card slide / draw sound
  playDraw() {
    if (this.muted) return;
    if (this.lastDrawTime && Date.now() - this.lastDrawTime < 60) return;
    this.lastDrawTime = Date.now();
    this.init();
    if (!this.ctx) return;

    try {
      const t = this.ctx.currentTime;
      const osc = this.ctx.createOscillator();
      const gain = this.ctx.createGain();

      osc.type = 'triangle';
      osc.frequency.setValueAtTime(320, t);
      osc.frequency.exponentialRampToValueAtTime(140, t + 0.12);

      gain.gain.setValueAtTime(0.18, t);
      gain.gain.exponentialRampToValueAtTime(0.001, t + 0.12);

      osc.connect(gain);
      gain.connect(this.ctx.destination);

      osc.start(t);
      osc.stop(t + 0.12);
    } catch {
      // AudioContext error handling
    }
  }

  // Card play / snap sound
  playCard() {
    if (this.muted) return;
    this.init();
    if (!this.ctx) return;

    try {
      const t = this.ctx.currentTime;
      const osc1 = this.ctx.createOscillator();
      const osc2 = this.ctx.createOscillator();
      const gain = this.ctx.createGain();

      osc1.type = 'sine';
      osc1.frequency.setValueAtTime(440, t);
      osc1.frequency.exponentialRampToValueAtTime(220, t + 0.08);

      osc2.type = 'triangle';
      osc2.frequency.setValueAtTime(180, t);
      osc2.frequency.exponentialRampToValueAtTime(60, t + 0.08);

      gain.gain.setValueAtTime(0.25, t);
      gain.gain.exponentialRampToValueAtTime(0.001, t + 0.09);

      osc1.connect(gain);
      osc2.connect(gain);
      gain.connect(this.ctx.destination);

      osc1.start(t);
      osc2.start(t);
      osc1.stop(t + 0.09);
      osc2.stop(t + 0.09);
    } catch {
      // AudioContext error handling
    }
  }

  // Action card sound (Skip, Reverse, +2)
  playAction() {
    if (this.muted) return;
    this.init();
    if (!this.ctx) return;

    try {
      const t = this.ctx.currentTime;
      const osc = this.ctx.createOscillator();
      const gain = this.ctx.createGain();

      osc.type = 'sine';
      osc.frequency.setValueAtTime(523.25, t); // C5
      osc.frequency.setValueAtTime(659.25, t + 0.08); // E5
      osc.frequency.setValueAtTime(783.99, t + 0.16); // G5

      gain.gain.setValueAtTime(0.2, t);
      gain.gain.exponentialRampToValueAtTime(0.001, t + 0.3);

      osc.connect(gain);
      gain.connect(this.ctx.destination);

      osc.start(t);
      osc.stop(t + 0.3);
    } catch {
      // AudioContext error handling
    }
  }

  // Distinct "WHOOSH-BUZZ / DENIED" Skip sound
  playSkip() {
    if (this.muted) return;
    this.init();
    if (!this.ctx) return;

    try {
      const t = this.ctx.currentTime;
      const osc = this.ctx.createOscillator();
      const gain = this.ctx.createGain();

      osc.type = 'sawtooth';
      osc.frequency.setValueAtTime(520, t);
      osc.frequency.exponentialRampToValueAtTime(140, t + 0.28);

      gain.gain.setValueAtTime(0.26, t);
      gain.gain.exponentialRampToValueAtTime(0.001, t + 0.28);

      osc.connect(gain);
      gain.connect(this.ctx.destination);

      osc.start(t);
      osc.stop(t + 0.28);
    } catch {
      // AudioContext error handling
    }
  }

  // Wild Card change color chime
  playWild() {
    if (this.muted) return;
    this.init();
    if (!this.ctx) return;

    try {
      const t = this.ctx.currentTime;
      [523.25, 659.25, 783.99, 1046.5].forEach((freq, idx) => {
        const osc = this.ctx.createOscillator();
        const gain = this.ctx.createGain();
        osc.type = 'sine';
        osc.frequency.setValueAtTime(freq, t + idx * 0.06);

        gain.gain.setValueAtTime(0.18, t + idx * 0.06);
        gain.gain.exponentialRampToValueAtTime(0.001, t + idx * 0.06 + 0.25);

        osc.connect(gain);
        gain.connect(this.ctx.destination);

        osc.start(t + idx * 0.06);
        osc.stop(t + idx * 0.06 + 0.25);
      });
    } catch {
      // AudioContext error handling
    }
  }

  // Dramatic "UNO!" alert
  playUno() {
    if (this.muted) return;
    this.init();
    if (!this.ctx) return;

    try {
      const t = this.ctx.currentTime;
      [440, 554.37, 659.25, 880].forEach((freq, idx) => {
        const osc = this.ctx.createOscillator();
        const gain = this.ctx.createGain();
        osc.type = 'sawtooth';
        osc.frequency.setValueAtTime(freq, t + idx * 0.05);

        gain.gain.setValueAtTime(0.22, t + idx * 0.05);
        gain.gain.exponentialRampToValueAtTime(0.001, t + idx * 0.05 + 0.35);

        osc.connect(gain);
        gain.connect(this.ctx.destination);

        osc.start(t + idx * 0.05);
        osc.stop(t + idx * 0.05 + 0.35);
      });
    } catch {
      // AudioContext error handling
    }
  }

  // Penalty / Caught sound
  playPenalty() {
    if (this.muted) return;
    this.init();
    if (!this.ctx) return;

    try {
      const t = this.ctx.currentTime;
      const osc = this.ctx.createOscillator();
      const gain = this.ctx.createGain();

      osc.type = 'sawtooth';
      osc.frequency.setValueAtTime(180, t);
      osc.frequency.setValueAtTime(120, t + 0.15);

      gain.gain.setValueAtTime(0.25, t);
      gain.gain.exponentialRampToValueAtTime(0.001, t + 0.4);

      osc.connect(gain);
      gain.connect(this.ctx.destination);

      osc.start(t);
      osc.stop(t + 0.4);
    } catch {
      // AudioContext error handling
    }
  }

  // Player turn notification
  playTurn() {
    if (this.muted) return;
    this.init();
    if (!this.ctx) return;

    try {
      const t = this.ctx.currentTime;
      const osc = this.ctx.createOscillator();
      const gain = this.ctx.createGain();

      osc.type = 'sine';
      osc.frequency.setValueAtTime(880, t);
      osc.frequency.exponentialRampToValueAtTime(1174.66, t + 0.1);

      gain.gain.setValueAtTime(0.12, t);
      gain.gain.exponentialRampToValueAtTime(0.001, t + 0.18);

      osc.connect(gain);
      gain.connect(this.ctx.destination);

      osc.start(t);
      osc.stop(t + 0.18);
    } catch {
      // AudioContext error handling
    }
  }

  // Victory fanfare
  playVictory() {
    if (this.muted) return;
    this.init();
    if (!this.ctx) return;

    try {
      const notes = [523.25, 523.25, 523.25, 659.25, 783.99, 1046.5];
      const times = [0, 0.12, 0.24, 0.36, 0.48, 0.65];
      const durs = [0.1, 0.1, 0.1, 0.1, 0.15, 0.6];

      const t = this.ctx.currentTime;
      notes.forEach((freq, i) => {
        const osc = this.ctx.createOscillator();
        const gain = this.ctx.createGain();

        osc.type = 'triangle';
        osc.frequency.setValueAtTime(freq, t + times[i]);

        gain.gain.setValueAtTime(0.25, t + times[i]);
        gain.gain.exponentialRampToValueAtTime(0.001, t + times[i] + durs[i]);

        osc.connect(gain);
        gain.connect(this.ctx.destination);

        osc.start(t + times[i]);
        osc.stop(t + times[i] + durs[i]);
      });
    } catch {
      // AudioContext error handling
    }
  }

  // Fast dealing card sound with pitch stepping
  playDeal(step = 0) {
    if (this.muted) return;
    this.init();
    if (!this.ctx) return;

    try {
      const t = this.ctx.currentTime;
      const osc = this.ctx.createOscillator();
      const gain = this.ctx.createGain();

      const baseFreq = 260 + (step % 7) * 35;
      osc.type = 'triangle';
      osc.frequency.setValueAtTime(baseFreq, t);
      osc.frequency.exponentialRampToValueAtTime(baseFreq * 0.5, t + 0.08);

      gain.gain.setValueAtTime(0.15, t);
      gain.gain.exponentialRampToValueAtTime(0.001, t + 0.08);

      osc.connect(gain);
      gain.connect(this.ctx.destination);

      osc.start(t);
      osc.stop(t + 0.08);
    } catch {
      // AudioContext error handling
    }
  }

  // Card shuffle / fanning flutter sound
  playShuffle() {
    if (this.muted) return;
    this.init();
    if (!this.ctx) return;

    try {
      const t = this.ctx.currentTime;
      for (let i = 0; i < 6; i++) {
        const osc = this.ctx.createOscillator();
        const gain = this.ctx.createGain();

        const delay = i * 0.045;
        osc.type = 'sine';
        osc.frequency.setValueAtTime(380 + i * 40, t + delay);
        osc.frequency.exponentialRampToValueAtTime(160, t + delay + 0.07);

        gain.gain.setValueAtTime(0.12, t + delay);
        gain.gain.exponentialRampToValueAtTime(0.001, t + delay + 0.07);

        osc.connect(gain);
        gain.connect(this.ctx.destination);

        osc.start(t + delay);
        osc.stop(t + delay + 0.07);
      }
    } catch {
      // AudioContext error handling
    }
  }

  // Subtle countdown tick sound
  playTick() {
    if (this.muted) return;
    this.init();
    if (!this.ctx) return;

    try {
      const t = this.ctx.currentTime;
      const osc = this.ctx.createOscillator();
      const gain = this.ctx.createGain();

      osc.type = 'sine';
      osc.frequency.setValueAtTime(800, t);
      osc.frequency.exponentialRampToValueAtTime(400, t + 0.04);

      gain.gain.setValueAtTime(0.08, t);
      gain.gain.exponentialRampToValueAtTime(0.001, t + 0.04);

      osc.connect(gain);
      gain.connect(this.ctx.destination);

      osc.start(t);
      osc.stop(t + 0.04);
    } catch {
      // AudioContext error handling
    }
  }
}

export const soundManager = new SoundManager();

`

---

## src/services/animation.js

`javascript
// animation.js - Flying Card Motion System for UNO Tabletop
import { soundManager } from './sound';

// Immediate browser preloading for card back asset
if (typeof window !== 'undefined') {
  const cardBackImg = new Image();
  cardBackImg.src = '/cards_modern/card_back.png';
}

class CardAnimationService {
  constructor() {
    this.isAnimating = false;
  }

  // Base flight animation between two screen rectangles
  animateFlight({
    fromRect,
    toRect,
    imgSrc,
    startRot = 0,
    endRot = 0,
    duration = 340,
    onComplete
  }) {
    if (!fromRect || !toRect) {
      if (onComplete) onComplete();
      return;
    }

    const flying = document.createElement('div');
    flying.className = 'flying-card';

    const startW = fromRect.width || 70;
    const startH = fromRect.height || 105;
    const endW = toRect.width || 80;
    const endH = toRect.height || 120;

    Object.assign(flying.style, {
      position: 'fixed',
      zIndex: '9999',
      pointerEvents: 'none',
      width: `${startW}px`,
      height: `${startH}px`,
      left: `${fromRect.left}px`,
      top: `${fromRect.top}px`,
      transform: `rotate(${startRot}deg) scale(1)`,
      transformOrigin: 'center center',
      willChange: 'transform, left, top, width, height',
      filter: 'drop-shadow(0 14px 28px rgba(0,0,0,0.6))'
    });

    const img = document.createElement('img');
    img.src = imgSrc;
    img.style.width = '100%';
    img.style.height = '100%';
    img.style.objectFit = 'contain';
    flying.appendChild(img);

    document.body.appendChild(flying);

    // Force browser reflow
    void flying.offsetWidth;

    // Trigger smooth flight transition
    requestAnimationFrame(() => {
      Object.assign(flying.style, {
        transition: `all ${duration}ms cubic-bezier(0.22, 0.85, 0.32, 1.05)`,
        left: `${toRect.left}px`,
        top: `${toRect.top}px`,
        width: `${endW}px`,
        height: `${endH}px`,
        transform: `rotate(${endRot}deg) scale(1.04)`
      });
    });

    setTimeout(() => {
      flying.remove();
      if (onComplete) onComplete();
    }, duration);
  }

  // Animate playing a card from a hand element to the discard pile
  animatePlayCard(fromEl, toEl, cardAssetKey, onComplete) {
    if (!fromEl || !toEl) {
      soundManager.playCard();
      if (onComplete) onComplete();
      return;
    }

    const fromRect = fromEl.getBoundingClientRect();
    const toRect = toEl.getBoundingClientRect();
    const imgSrc = `/cards_modern/${cardAssetKey}.png`;
    const randomTilt = Math.floor(Math.random() * 16) - 8;

    soundManager.playCard();

    this.animateFlight({
      fromRect,
      toRect,
      imgSrc,
      startRot: 0,
      endRot: randomTilt,
      duration: 320,
      onComplete: () => {
        toEl.classList.remove('impact-bounce');
        void toEl.offsetWidth;
        toEl.classList.add('impact-bounce');
        if (onComplete) onComplete();
      }
    });
  }

  // Animate drawing a card from the draw pile into a player's hand
  animateDrawCard(fromEl, toEl, cardAssetKey = 'card_back', onComplete) {
    if (!fromEl || !toEl) {
      soundManager.playDraw();
      if (onComplete) onComplete();
      return;
    }

    fromEl.classList.add('scale-95');
    setTimeout(() => fromEl.classList.remove('scale-95'), 150);

    const fromRect = fromEl.getBoundingClientRect();
    const toRect = toEl.getBoundingClientRect();
    const imgSrc = `/cards_modern/${cardAssetKey}.png`;

    soundManager.playDraw();

    this.animateFlight({
      fromRect,
      toRect,
      imgSrc,
      startRot: 0,
      endRot: 0,
      duration: 300,
      onComplete
    });
  }

  // Animate multi-draw cascade (for +2, +4, +6 penalties)
  animateMultiDraw(fromEl, toEl, count, onComplete) {
    const actualCount = Math.min(count, 8);
    let drawn = 0;
    const interval = setInterval(() => {
      this.animateDrawCard(fromEl, toEl, 'card_back');
      drawn++;
      if (drawn >= actualCount) {
        clearInterval(interval);
        if (onComplete) setTimeout(onComplete, 320);
      }
    }, 180);
  }

  // Opening deal: deal a card to each active seat just like drawing a card
  animateOpeningDeal({
    drawPileEl,
    seatElements,
    discardPileEl,
    firstCardKey = 'card_back',
    onComplete
  }) {
    if (!drawPileEl || !seatElements || seatElements.length === 0) {
      if (onComplete) onComplete();
      return;
    }

    const seats = seatElements.filter(Boolean);
    if (seats.length === 0) {
      if (onComplete) onComplete();
      return;
    }

    // Deal one card to each seat sequentially (staggered 140ms apart)
    seats.forEach((seatEl, i) => {
      setTimeout(() => {
        try {
          this.animateDrawCard(drawPileEl, seatEl, 'card_back');
        } catch {
          // ignore error
        }
      }, i * 140);
    });

    // After players receive cards, flip the top card to discard pile
    const finishDelay = seats.length * 140 + 80;
    setTimeout(() => {
      try {
        if (drawPileEl && discardPileEl) {
          this.animatePlayCard(drawPileEl, discardPileEl, firstCardKey, () => {
            if (onComplete) onComplete();
          });
        } else {
          if (onComplete) onComplete();
        }
      } catch {
        if (onComplete) onComplete();
      }
    }, finishDelay);
  }
}

export const cardAnimationService = new CardAnimationService();

`

---

## src/components/HomeView.jsx

`javascript
// HomeView.jsx - Lobby Entry & Room Creator / Joiner with 2v2 Mode Selection
import React, { useState, useEffect } from 'react';
import { PlusCircle, LogIn, Users, Flame, ShieldCheck, Sparkles, Swords, UserCheck } from 'lucide-react';
import { P2PNetwork } from '../services/p2p';

export function HomeView({ onCreateRoom, onJoinRoom }) {
  const [playerName, setPlayerName] = useState(() => localStorage.getItem('uno_player_name') || '玩家');
  const [roomCodeInput, setRoomCodeInput] = useState('');
  const [allowStacking, setAllowStacking] = useState(true);
  const [gameMode, setGameMode] = useState('ffa'); // 'ffa' | '2v2'
  const [tab, setTab] = useState('create'); // 'create' | 'join'

  useEffect(() => {
    const hash = window.location.hash.replace('#', '').trim();
    if (hash && hash.startsWith('UNO-')) {
      setRoomCodeInput(hash.toUpperCase());
      setTab('join');
    }
  }, []);

  const handleNameChange = (e) => {
    const val = e.target.value;
    setPlayerName(val);
    localStorage.setItem('uno_player_name', val);
  };

  const handleCreate = (e) => {
    e.preventDefault();
    const code = P2PNetwork.generateRoomCode();
    onCreateRoom(code, playerName, allowStacking, gameMode);
  };

  const handleJoin = (e) => {
    e.preventDefault();
    if (!roomCodeInput.trim()) return;
    onJoinRoom(roomCodeInput.trim().toUpperCase(), playerName);
  };

  return (
    <div className="min-h-screen felt-table flex items-center justify-center p-4">
      <div className="w-full max-w-lg bg-[#0e2a1b]/95 border border-amber-500/30 rounded-2xl shadow-2xl p-6 sm:p-8 backdrop-blur-md">
        {/* Brand Header */}
        <div className="text-center mb-6">
          <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-amber-500/10 border border-amber-500/30 text-amber-300 text-xs font-semibold tracking-wider uppercase mb-3">
            <Sparkles className="w-3.5 h-3.5 text-amber-400" />
            Host-Authoritative P2P
          </div>
          <h1 className="text-4xl sm:text-5xl font-black tracking-tight text-white flex items-center justify-center gap-2">
            <span className="text-red-500 drop-shadow-[0_2px_10px_rgba(239,68,68,0.5)]">U</span>
            <span className="text-amber-400 drop-shadow-[0_2px_10px_rgba(244,196,48,0.5)]">N</span>
            <span className="text-blue-500 drop-shadow-[0_2px_10px_rgba(59,130,246,0.5)]">O</span>
            <span className="text-green-500 drop-shadow-[0_2px_10px_rgba(34,197,94,0.5)]">!</span>
          </h1>
          <p className="text-xs sm:text-sm text-emerald-200/70 mt-1">
            房主自架極速連線 • 支援 2V2 組隊與多人混戰 • 3D 官方精靈卡牌
          </p>
        </div>

        {/* Player Name Input */}
        <div className="mb-5">
          <label className="block text-xs font-medium text-emerald-300 mb-1.5 uppercase tracking-wider">
            玩家暱稱
          </label>
          <input
            type="text"
            value={playerName}
            onChange={handleNameChange}
            maxLength={12}
            placeholder="請輸入你的暱稱..."
            className="w-full px-4 py-2.5 bg-[#081a10] border border-emerald-500/30 rounded-xl text-white placeholder-emerald-700 focus:outline-none focus:border-amber-400 focus:ring-1 focus:ring-amber-400 transition"
          />
        </div>

        {/* Tab Switcher */}
        <div className="grid grid-cols-2 gap-2 p-1 bg-[#07170e] rounded-xl border border-emerald-500/20 mb-5">
          <button
            type="button"
            onClick={() => setTab('create')}
            className={`py-2 px-3 text-xs sm:text-sm font-semibold rounded-lg flex items-center justify-center gap-1.5 transition ${
              tab === 'create'
                ? 'bg-amber-500 text-black shadow-md'
                : 'text-emerald-300 hover:text-white'
            }`}
          >
            <PlusCircle className="w-4 h-4" />
            建立房間
          </button>
          <button
            type="button"
            onClick={() => setTab('join')}
            className={`py-2 px-3 text-xs sm:text-sm font-semibold rounded-lg flex items-center justify-center gap-1.5 transition ${
              tab === 'join'
                ? 'bg-amber-500 text-black shadow-md'
                : 'text-emerald-300 hover:text-white'
            }`}
          >
            <LogIn className="w-4 h-4" />
            加入房間
          </button>
        </div>

        {/* Tab 1: Create Room */}
        {tab === 'create' && (
          <form onSubmit={handleCreate} className="space-y-4">
            {/* Game Mode Selection */}
            <div>
              <label className="block text-xs font-medium text-emerald-300 mb-1.5 uppercase tracking-wider">
                遊戲模式 (Game Mode)
              </label>
              <div className="grid grid-cols-2 gap-2.5">
                <button
                  type="button"
                  onClick={() => setGameMode('ffa')}
                  className={`p-3 rounded-xl border text-left transition flex flex-col justify-between ${
                    gameMode === 'ffa'
                      ? 'bg-amber-500/20 border-amber-400 text-white shadow-md'
                      : 'bg-[#081a10] border-emerald-500/20 text-emerald-300/70 hover:border-emerald-500/40'
                  }`}
                >
                  <div className="flex items-center gap-1.5 font-bold text-xs sm:text-sm text-white mb-1">
                    <Swords className="w-4 h-4 text-amber-400" />
                    多人混戰 (FFA)
                  </div>
                  <div className="text-[11px] opacity-75">
                    各自為戰，支援 2~4 人，對手手牌蓋牌
                  </div>
                </button>

                <button
                  type="button"
                  onClick={() => setGameMode('2v2')}
                  className={`p-3 rounded-xl border text-left transition flex flex-col justify-between ${
                    gameMode === '2v2'
                      ? 'bg-amber-500/20 border-amber-400 text-white shadow-md'
                      : 'bg-[#081a10] border-emerald-500/20 text-emerald-300/70 hover:border-emerald-500/40'
                  }`}
                >
                  <div className="flex items-center gap-1.5 font-bold text-xs sm:text-sm text-white mb-1">
                    <UserCheck className="w-4 h-4 text-amber-400" />
                    2V2 雙人組隊
                  </div>
                  <div className="text-[11px] opacity-75">
                    對面是隊友，即時可見隊友手牌共謀勝利
                  </div>
                </button>
              </div>
            </div>

            {/* Stacking Rule options */}
            <div className="bg-[#081a10] border border-emerald-500/20 rounded-xl p-3.5">
              <div className="flex items-center justify-between">
                <div className="flex items-center gap-2">
                  <Flame className="w-5 h-5 text-amber-400" />
                  <div>
                    <div className="text-xs sm:text-sm font-bold text-white">疊牌規則 (Stacking)</div>
                    <div className="text-[11px] text-emerald-300/70">
                      允許 +2 疊 +2，+4 疊 +4 累積罰抽
                    </div>
                  </div>
                </div>
                <button
                  type="button"
                  onClick={() => setAllowStacking(!allowStacking)}
                  className={`relative inline-flex h-6 w-11 items-center rounded-full transition-colors ${
                    allowStacking ? 'bg-amber-500' : 'bg-gray-700'
                  }`}
                >
                  <span
                    className={`inline-block h-4 w-4 transform rounded-full bg-white transition-transform ${
                      allowStacking ? 'translate-x-6' : 'translate-x-1'
                    }`}
                  />
                </button>
              </div>
            </div>

            <div className="p-3 bg-emerald-950/40 border border-emerald-500/20 rounded-xl text-xs text-emerald-300/80 flex items-start gap-2">
              <ShieldCheck className="w-4 h-4 text-emerald-400 shrink-0 mt-0.5" />
              <span>
                <strong>自選對手模式：</strong>進入房間後可自由切換每一席為「電腦」或「真人」，即使單人也能與 AI 電腦組隊練習！
              </span>
            </div>

            <button
              type="submit"
              className="w-full py-3.5 px-4 bg-gradient-to-r from-amber-500 to-amber-400 hover:from-amber-400 hover:to-amber-300 text-black font-extrabold text-sm sm:text-base rounded-xl shadow-lg shadow-amber-500/20 active:translate-y-0.5 transition duration-150 flex items-center justify-center gap-2"
            >
              <Users className="w-5 h-5" />
              建立房間並進入大廳
            </button>
          </form>
        )}

        {/* Tab 2: Join Room */}
        {tab === 'join' && (
          <form onSubmit={handleJoin} className="space-y-4">
            <div>
              <label className="block text-xs font-medium text-emerald-300 mb-1.5 uppercase tracking-wider">
                房間號碼 (Room Code)
              </label>
              <input
                type="text"
                value={roomCodeInput}
                onChange={(e) => setRoomCodeInput(e.target.value.toUpperCase())}
                placeholder="例如: UNO-7829"
                className="w-full px-4 py-3 bg-[#081a10] border border-emerald-500/30 rounded-xl text-white font-mono text-center tracking-widest text-lg placeholder-emerald-700 focus:outline-none focus:border-amber-400 focus:ring-1 focus:ring-amber-400 transition"
                autoFocus
              />
            </div>

            <button
              type="submit"
              disabled={!roomCodeInput.trim()}
              className="w-full py-3.5 px-4 bg-gradient-to-r from-emerald-500 to-emerald-400 hover:from-emerald-400 hover:to-emerald-300 disabled:opacity-50 disabled:cursor-not-allowed text-black font-extrabold text-sm sm:text-base rounded-xl shadow-lg shadow-emerald-500/20 active:translate-y-0.5 transition duration-150 flex items-center justify-center gap-2"
            >
              <LogIn className="w-5 h-5" />
              加入房間
            </button>
          </form>
        )}
      </div>
    </div>
  );
}

`

---

## src/components/LobbyView.jsx

`javascript
// LobbyView.jsx - Multiplayer Lobby with 2v2 Team Alignment & Human/Bot Configuration
import React, { useState } from 'react';
import {
  Copy,
  Check,
  Bot,
  User,
  Play,
  LogOut,
  Flame,
  Crown,
  Link as LinkIcon,
  Swords,
  UserCheck,
  ArrowLeftRight,
  Trophy,
  Layers,
  Scale
} from 'lucide-react';

export function LobbyView({
  roomCode,
  isHost,
  players = [],
  gameMode = 'ffa',
  allowStacking,
  allowChallengeWildDraw4 = true,
  targetScore = 500,
  drawRule = 'draw_one',
  onToggleAi,
  onToggleStacking,
  onToggleChallengeRule,
  onSetTargetScore,
  onSetDrawRule,
  onSetGameMode,
  onSetFfaCount,
  onSwapSlots,
  onStartGame,
  onLeaveRoom
}) {
  const [copiedCode, setCopiedCode] = useState(false);
  const [copiedLink, setCopiedLink] = useState(false);
  const [swapSource, setSwapSource] = useState(null);

  const inviteLink = `${window.location.origin}${window.location.pathname}#${roomCode}`;

  const handleCopyCode = () => {
    navigator.clipboard.writeText(roomCode);
    setCopiedCode(true);
    setTimeout(() => setCopiedCode(false), 2000);
  };

  const handleCopyLink = () => {
    navigator.clipboard.writeText(inviteLink);
    setCopiedLink(true);
    setTimeout(() => setCopiedLink(false), 2000);
  };

  const handleSlotClickForSwap = (idx) => {
    if (!isHost) return;
    if (swapSource === null) {
      setSwapSource(idx);
    } else {
      onSwapSlots(swapSource, idx);
      setSwapSource(null);
    }
  };

  const is2v2 = gameMode === '2v2';

  return (
    <div className="min-h-screen felt-table flex items-center justify-center p-4">
      <div className="w-full max-w-2xl bg-[#0e2a1b]/95 border border-amber-500/30 rounded-2xl shadow-2xl p-5 sm:p-7 backdrop-blur-md">
        {/* Room Header & Share Section */}
        <div className="flex flex-col sm:flex-row items-center justify-between gap-4 pb-5 border-b border-emerald-500/20">
          <div>
            <div className="text-xs uppercase tracking-widest text-emerald-400 font-semibold mb-1">
              房間代碼 (ROOM CODE)
            </div>
            <div className="flex items-center gap-2">
              <span className="font-mono text-3xl font-black text-amber-400 tracking-wider">
                {roomCode}
              </span>
              <button
                type="button"
                onClick={handleCopyCode}
                title="複製房號"
                className="p-1.5 px-2.5 rounded-lg bg-emerald-900/60 hover:bg-emerald-800 text-emerald-300 border border-emerald-500/30 transition flex items-center gap-1 text-xs"
              >
                {copiedCode ? <Check className="w-3.5 h-3.5 text-green-400" /> : <Copy className="w-3.5 h-3.5" />}
                {copiedCode ? '已複製' : '複製'}
              </button>
            </div>
          </div>

          {/* Invite Link Button */}
          <div className="flex items-center gap-2 w-full sm:w-auto">
            <button
              type="button"
              onClick={handleCopyLink}
              className="flex-1 sm:flex-none py-2 px-3 rounded-xl bg-amber-500/10 hover:bg-amber-500/20 text-amber-300 border border-amber-500/30 font-semibold text-xs transition flex items-center justify-center gap-1.5"
            >
              {copiedLink ? <Check className="w-3.5 h-3.5 text-green-400" /> : <LinkIcon className="w-3.5 h-3.5" />}
              {copiedLink ? '已複製邀請連結！' : '複製好友邀請連結'}
            </button>
            <button
              type="button"
              onClick={() => {
                if (isHost) {
                  if (window.confirm('確定要解散房間嗎？解散後所有玩家將自動返回首頁。')) {
                    onLeaveRoom();
                  }
                } else {
                  onLeaveRoom();
                }
              }}
              title={isHost ? '解散房間' : '離開房間'}
              className="py-2 px-3 rounded-xl bg-red-950/70 hover:bg-red-900 text-red-300 border border-red-500/40 font-bold text-xs transition flex items-center gap-1.5"
            >
              <LogOut className="w-4 h-4" />
              <span>{isHost ? '解散房間' : '離開房間'}</span>
            </button>
          </div>
        </div>

        {/* Mode & Rule Settings Panel */}
        <div className="my-5 p-4 bg-[#081a10] border border-emerald-500/25 rounded-2xl space-y-3.5">
          {/* Row 1: Game Mode Switcher */}
          <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2 pb-2.5 border-b border-emerald-500/15">
            <div className="text-xs font-bold text-white uppercase tracking-wider flex items-center gap-1.5">
              <span>對戰模式：</span>
              <span className="text-amber-400 font-extrabold">
                {is2v2 ? '2V2 雙人組隊戰' : `多人混戰 (${players.length}人局)`}
              </span>
            </div>

            {isHost ? (
              <div className="flex items-center gap-1.5">
                <button
                  type="button"
                  onClick={() => onSetGameMode('ffa')}
                  className={`py-1 px-2.5 rounded-lg text-xs font-bold transition flex items-center gap-1 ${
                    !is2v2
                      ? 'bg-amber-500 text-black shadow-sm'
                      : 'bg-emerald-950/80 text-emerald-300 hover:text-white border border-emerald-500/20'
                  }`}
                >
                  <Swords className="w-3 h-3" />
                  多人混戰
                </button>
                <button
                  type="button"
                  onClick={() => onSetGameMode('2v2')}
                  className={`py-1 px-2.5 rounded-lg text-xs font-bold transition flex items-center gap-1 ${
                    is2v2
                      ? 'bg-amber-500 text-black shadow-sm'
                      : 'bg-emerald-950/80 text-emerald-300 hover:text-white border border-emerald-500/20'
                  }`}
                >
                  <UserCheck className="w-3 h-3" />
                  2V2 組隊
                </button>
              </div>
            ) : (
              <span className="text-xs text-emerald-400/80 font-mono">
                {is2v2 ? '隊伍對局模式' : '個人各自為戰'}
              </span>
            )}
          </div>

          {/* Row 2: Sub-settings (FFA Count or 2v2 banner) */}
          {!is2v2 && isHost && (
            <div className="flex items-center justify-between pb-2.5 border-b border-emerald-500/10 text-xs">
              <span className="text-emerald-300/80 font-medium">混戰人數設定：</span>
              <div className="flex items-center gap-1.5">
                {[2, 3, 4].map((cnt) => (
                  <button
                    key={cnt}
                    type="button"
                    onClick={() => onSetFfaCount(cnt)}
                    className={`px-2.5 py-0.5 rounded font-mono font-bold transition ${
                      players.length === cnt
                        ? 'bg-amber-500 text-black'
                        : 'bg-emerald-950 text-emerald-300 hover:bg-emerald-900 border border-emerald-500/20'
                    }`}
                  >
                    {cnt} 人
                  </button>
                ))}
              </div>
            </div>
          )}

          {is2v2 && (
            <div className="text-[11px] text-amber-300/90 font-medium pb-2 border-b border-emerald-500/10">
              💡 <strong>2V2 規則：</strong>席位 0 & 2 為金隊（對面互為隊友），可即時看見隊友手牌；任一隊友出清即贏！
            </div>
          )}

          {/* Row 3: Target Score Setting */}
          <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2 pb-2.5 border-b border-emerald-500/10 text-xs">
            <div className="flex items-center gap-1 text-emerald-300/80">
              <Trophy className="w-3.5 h-3.5 text-amber-400" />
              <span>積分賽制目標：</span>
              <span className="text-amber-300 font-bold">
                {targetScore > 0 ? `${targetScore} 分完賽` : '無積分制 (暢玩)'}
              </span>
            </div>

            {isHost ? (
              <div className="flex flex-wrap items-center gap-1">
                {[
                  { label: '無積分暢玩', value: 0 },
                  { label: '250分', value: 250 },
                  { label: '500分(標準)', value: 500 },
                  { label: '1000分', value: 1000 }
                ].map((opt) => (
                  <button
                    key={opt.value}
                    type="button"
                    onClick={() => onSetTargetScore(opt.value)}
                    className={`px-2 py-0.5 rounded text-[11px] font-bold transition ${
                      targetScore === opt.value
                        ? 'bg-amber-500 text-black shadow-sm'
                        : 'bg-emerald-950/80 text-emerald-300 hover:bg-emerald-900 border border-emerald-500/20'
                    }`}
                  >
                    {opt.label}
                  </button>
                ))}
              </div>
            ) : (
              <span className="font-bold text-amber-400 font-mono">
                {targetScore > 0 ? `${targetScore} 分完賽` : '無積分暢玩'}
              </span>
            )}
          </div>

          {/* Row 4: Custom House Rules (抽牌規則 & 疊牌規則 & 質疑規則) */}
          <div className="grid grid-cols-1 sm:grid-cols-3 gap-2.5 text-xs pt-1">
            {/* Draw Rule */}
            <div className="flex items-center justify-between p-2 rounded-xl bg-emerald-950/40 border border-emerald-500/20">
              <span className="text-emerald-300/80 flex items-center gap-1">
                <Layers className="w-3.5 h-3.5 text-sky-400" />
                抽牌規則：
              </span>
              {isHost ? (
                <div className="flex items-center gap-1">
                  <button
                    type="button"
                    onClick={() => onSetDrawRule('draw_one')}
                    className={`px-1.5 py-0.5 rounded text-[10px] font-bold transition ${
                      drawRule === 'draw_one'
                        ? 'bg-sky-500 text-white'
                        : 'bg-black/40 text-gray-400 hover:text-white'
                    }`}
                  >
                    抽1張
                  </button>
                  <button
                    type="button"
                    onClick={() => onSetDrawRule('draw_until_playable')}
                    className={`px-1.5 py-0.5 rounded text-[10px] font-bold transition ${
                      drawRule === 'draw_until_playable'
                        ? 'bg-sky-500 text-white'
                        : 'bg-black/40 text-gray-400 hover:text-white'
                    }`}
                  >
                    抽到能出
                  </button>
                </div>
              ) : (
                <span className="font-bold text-sky-300">
                  {drawRule === 'draw_until_playable' ? '抽到能出' : '抽 1 張'}
                </span>
              )}
            </div>

            {/* Stacking Rule */}
            <div className="flex items-center justify-between p-2 rounded-xl bg-emerald-950/40 border border-emerald-500/20">
              <span className="text-emerald-300/80 flex items-center gap-1" title="+2疊+2、+4疊+4，不可混疊">
                <Flame className="w-3.5 h-3.5 text-amber-400" />
                +牌同類疊加：
              </span>
              {isHost ? (
                <button
                  type="button"
                  onClick={onToggleStacking}
                  className={`px-2.5 py-0.5 rounded text-[10px] font-bold transition ${
                    allowStacking
                      ? 'bg-amber-500 text-black'
                      : 'bg-gray-700 text-gray-300'
                  }`}
                >
                  {allowStacking ? '啟用' : '關閉'}
                </button>
              ) : (
                <span className="font-bold text-amber-400">
                  {allowStacking ? '啟用' : '關閉'}
                </span>
              )}
            </div>

            {/* Challenge Wild Draw 4 Rule */}
            <div className="flex items-center justify-between p-2 rounded-xl bg-emerald-950/40 border border-emerald-500/20">
              <span className="text-emerald-300/80 flex items-center gap-1" title="出+4時若手中已有該顏色手牌，可被下家質疑 (Steam官方規則)">
                <Scale className="w-3.5 h-3.5 text-amber-300" />
                質疑 +4 規則：
              </span>
              {isHost ? (
                <button
                  type="button"
                  onClick={onToggleChallengeRule}
                  className={`px-2.5 py-0.5 rounded text-[10px] font-bold transition ${
                    allowChallengeWildDraw4
                      ? 'bg-amber-500 text-black'
                      : 'bg-gray-700 text-gray-300'
                  }`}
                >
                  {allowChallengeWildDraw4 ? '啟用' : '關閉'}
                </button>
              ) : (
                <span className="font-bold text-amber-400">
                  {allowChallengeWildDraw4 ? '啟用' : '關閉'}
                </span>
              )}
            </div>
          </div>
        </div>

        {/* Player Slots Grid */}
        <div className="my-5">
          <div className="flex items-center justify-between mb-2.5">
            <span className="text-xs uppercase tracking-wider text-emerald-300 font-semibold">
              席位名單 {isHost && <span className="text-emerald-400/60 font-normal">(點擊兩位可交換位置)</span>}
            </span>
            {swapSource !== null && (
              <span className="text-xs text-amber-300 animate-pulse font-bold">
                請點擊目標席位完成交換...
              </span>
            )}
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
            {players.map((p, idx) => {
              const isSelectedForSwap = swapSource === idx;
              const isTeamA = is2v2 && idx % 2 === 0;
              const isTeamB = is2v2 && idx % 2 === 1;

              return (
                <div
                  key={idx}
                  onClick={isHost ? () => handleSlotClickForSwap(idx) : undefined}
                  className={`relative flex items-center justify-between p-3 rounded-xl transition border ${
                    isSelectedForSwap
                      ? 'bg-amber-500/25 border-amber-400 ring-2 ring-amber-400'
                      : isTeamA
                      ? 'bg-amber-950/20 border-amber-500/40'
                      : isTeamB
                      ? 'bg-blue-950/20 border-blue-500/40'
                      : 'bg-[#081a10] border-emerald-500/20'
                  } ${isHost ? 'cursor-pointer hover:border-amber-400/60' : ''}`}
                >
                  {/* Slot Avatar & Info */}
                  <div className="flex items-center gap-3">
                    <div
                      className={`w-9 h-9 rounded-full flex items-center justify-center font-bold text-xs border ${
                        p.isHost
                          ? 'bg-amber-500/20 border-amber-400 text-amber-300'
                          : isTeamA
                          ? 'bg-amber-500/15 border-amber-400 text-amber-300'
                          : isTeamB
                          ? 'bg-blue-500/15 border-blue-400 text-blue-300'
                          : p.isAi
                          ? 'bg-gray-800 border-gray-600 text-gray-400'
                          : 'bg-emerald-500/20 border-emerald-400 text-emerald-300'
                      }`}
                    >
                      {p.isHost ? (
                        <Crown className="w-4 h-4 text-amber-400" />
                      ) : p.isAi ? (
                        <Bot className="w-4 h-4" />
                      ) : (
                        <User className="w-4 h-4" />
                      )}
                    </div>

                    <div>
                      <div className="font-bold text-white text-xs sm:text-sm flex items-center gap-1.5">
                        <span className="truncate max-w-[120px]">{p.name}</span>
                        {p.isHost && (
                          <span className="text-[9px] px-1.5 py-0.2 rounded bg-amber-500/20 text-amber-300 border border-amber-500/40">
                            房主
                          </span>
                        )}
                        {p.score !== undefined && p.score > 0 && (
                          <span className="text-[10px] px-1.5 py-0.2 rounded-full bg-amber-400/20 text-amber-300 font-mono font-bold border border-amber-400/30">
                            ⭐ {p.score}分
                          </span>
                        )}
                      </div>

                      {/* Status / Team Tag */}
                      <div className="text-[11px] flex items-center gap-1.5">
                        {is2v2 && (
                          <span
                            className={`font-semibold text-[10px] px-1.5 rounded ${
                              isTeamA
                                ? 'bg-amber-500/20 text-amber-300 border border-amber-400/30'
                                : 'bg-blue-500/20 text-blue-300 border border-blue-400/30'
                            }`}
                          >
                            {isTeamA ? '👑 金隊 (隊友)' : '⚔️ 藍隊 (對手)'}
                          </span>
                        )}
                        <span className="text-emerald-400/70">
                          {p.isAi ? '電腦 Bot' : p.peerId || p.isHost ? '真人玩家' : '開放加入'}
                        </span>
                      </div>
                    </div>
                  </div>

                  {/* Slot Controls (Host Only) */}
                  {isHost && (
                    <div className="flex items-center gap-1">
                      {idx !== 0 && (
                        <button
                          type="button"
                          onClick={(e) => {
                            e.stopPropagation();
                            onToggleAi(idx);
                          }}
                          className={`text-[10px] py-1 px-2 rounded-lg font-semibold border transition ${
                            p.isAi
                              ? 'bg-emerald-950/80 text-emerald-300 border-emerald-500/30 hover:bg-emerald-900'
                              : 'bg-amber-950/80 text-amber-300 border-amber-500/30 hover:bg-amber-900'
                          }`}
                        >
                          {p.isAi ? '開放真人' : '換成電腦'}
                        </button>
                      )}
                      <button
                        type="button"
                        onClick={(e) => {
                          e.stopPropagation();
                          handleSlotClickForSwap(idx);
                        }}
                        title="換位"
                        className="p-1 text-gray-400 hover:text-white"
                      >
                        <ArrowLeftRight className="w-3.5 h-3.5" />
                      </button>
                    </div>
                  )}
                </div>
              );
            })}
          </div>
        </div>

        {/* Start Game CTA / Status */}
        {isHost ? (
          <button
            type="button"
            onClick={onStartGame}
            className="w-full py-3.5 px-6 bg-gradient-to-r from-amber-500 to-amber-400 hover:from-amber-400 hover:to-amber-300 text-black font-black text-base rounded-xl shadow-xl shadow-amber-500/25 active:translate-y-0.5 transition duration-150 flex items-center justify-center gap-2"
          >
            <Play className="w-5 h-5 fill-current" />
            {is2v2 ? '開始 2V2 組隊對局' : '開始多人對局'}
          </button>
        ) : (
          <div className="w-full py-3.5 px-6 rounded-xl bg-emerald-950/60 border border-emerald-500/30 text-center text-sm font-semibold text-emerald-300 flex items-center justify-center gap-2 animate-pulse">
            <div className="w-2.5 h-2.5 rounded-full bg-amber-400" />
            等待房主開始對局中...
          </div>
        )}
      </div>
    </div>
  );
}

`

---

## src/components/GameTableView.jsx

`javascript
// GameTableView.jsx - Classic Casino Felt Table Layout (Reverted & Polished to 1:1 match 螢幕擷取畫面 2026-10-13 150340.png)
import React, { useState, useRef, useEffect } from 'react';
import { CardView } from './CardView';
import {
  Volume2,
  VolumeX,
  History,
  RotateCw,
  RotateCcw,
  AlertTriangle,
  Flame,
  X,
  Check,
  UserCheck,
  Swords,
  Sparkles,
  LogOut
} from 'lucide-react';
import { soundManager } from '../services/sound';
import { cardAnimationService } from '../services/animation';

const colorOrder = { red: 1, yellow: 2, green: 3, blue: 4, wild: 5 };
const valueOrder = {
  '0': 0, '1': 1, '2': 2, '3': 3, '4': 4,
  '5': 5, '6': 6, '7': 7, '8': 8, '9': 9,
  'draw2': 10, 'skip': 11, 'reverse': 12,
  'wild': 13, 'wild_draw4': 14
};

function sortHandCards(cards) {
  return [...cards].sort((a, b) => {
    const colA = colorOrder[a.color] || 99;
    const colB = colorOrder[b.color] || 99;
    if (colA !== colB) return colA - colB;
    const valA = valueOrder[a.value] !== undefined ? valueOrder[a.value] : 99;
    const valB = valueOrder[b.value] !== undefined ? valueOrder[b.value] : 99;
    return valA - valB;
  });
}

// Circular Countdown Timer (15s decreasing radial ring next to character info card)
function TurnTimerCircle({ turnStartTime, duration = 15, isLocal = false }) {
  const [remaining, setRemaining] = useState(duration);
  const prevTickRef = useRef(null);

  useEffect(() => {
    const startTime = turnStartTime || Date.now();
    const update = () => {
      const elapsed = (Date.now() - startTime) / 1000;
      const rem = Math.max(0, duration - elapsed);
      setRemaining(rem);

      if (isLocal && rem > 0 && rem <= 3) {
        const sec = Math.ceil(rem);
        if (prevTickRef.current !== sec) {
          prevTickRef.current = sec;
          soundManager.playTick();
        }
      }
    };

    update();
    const interval = setInterval(update, 100);
    return () => clearInterval(interval);
  }, [turnStartTime, duration, isLocal]);

  const progress = Math.min(1, Math.max(0, remaining / duration));
  const r = 13;
  const circumference = 2 * Math.PI * r;
  const offset = circumference * (1 - progress);

  const isLow = remaining <= 5;
  const isCritical = remaining <= 2;
  const strokeColor = isCritical ? '#ef4444' : (isLow ? '#f59e0b' : '#10b981');

  return (
    <div
      className={`relative flex items-center justify-center transition-all select-none ${
        isCritical ? 'animate-pulse scale-105' : ''
      }`}
      title={`思考限時 ${duration} 秒（剩餘 ${Math.ceil(remaining)} 秒）`}
    >
      <svg className="w-8 h-8 sm:w-8.5 sm:h-8.5 -rotate-90 drop-shadow-md" viewBox="0 0 34 34">
        {/* Background track */}
        <circle
          cx="17"
          cy="17"
          r={r}
          stroke="rgba(255, 255, 255, 0.16)"
          strokeWidth="3.2"
          fill="rgba(10, 28, 18, 0.85)"
        />
        {/* Animated depleting ring */}
        <circle
          cx="17"
          cy="17"
          r={r}
          stroke={strokeColor}
          strokeWidth="3.2"
          fill="none"
          strokeDasharray={circumference}
          strokeDashoffset={offset}
          strokeLinecap="round"
          style={{ transition: 'stroke-dashoffset 100ms linear, stroke 250ms ease' }}
        />
      </svg>
      {/* Centered remaining seconds */}
      <span
        className={`absolute text-[11px] font-black tracking-tighter ${
          isCritical ? 'text-red-400 font-extrabold' : (isLow ? 'text-amber-300' : 'text-emerald-300')
        }`}
      >
        {Math.ceil(remaining)}
      </span>
    </div>
  );
}

export function GameTableView({
  gameState,
  onPlayCard,
  onChooseColor,
  onDrawCard,
  onPassTurn,
  onCallUno,
  onChallengeUno,
  onChallengeWildDraw4,
  isHost = false,
  onLeaveRoom,
  roomCode
}) {
  const [muted, setMuted] = useState(false);
  const [showLogDrawer, setShowLogDrawer] = useState(false);
  const [copiedCode, setCopiedCode] = useState(false);
  const [toastMessage, setToastMessage] = useState('');

  // Hand Fan & Sort Animation States
  const [isHandCollapsed, setIsHandCollapsed] = useState(false);
  const [isSorted, setIsSorted] = useState(true);
  const [skippedPlayerInfo, setSkippedPlayerInfo] = useState(null);
  const hasDealtRef = useRef(false);
  const prevActionTimeRef = useRef(0);

  // Refs for flight animations
  const drawPileRef = useRef(null);
  const discardPileRef = useRef(null);
  const myHandRef = useRef(null);
  const leftPlayerRef = useRef(null);
  const topPlayerRef = useRef(null);
  const rightPlayerRef = useRef(null);

  // Tracking refs to detect remote / bot actions for flight animations
  const prevTopCardRef = useRef(null);
  const prevHandCountsRef = useRef({});

  const showToast = (msg) => {
    setToastMessage(msg);
    setTimeout(() => setToastMessage(''), 3500);
  };

  const {
    gameMode = 'ffa',
    myIndex = 0,
    teammateIndex,
    teammateHand = [],
    players = [],
    myHand = [],
    validCards = [],
    topCard,
    currentColor = 'red',
    direction = 1,
    currentTurn = 0,
    stackedDrawCount = 0,
    hasDrawnThisTurn: remoteHasDrawn = false,
    targetScore = 500,
    drawRule = 'draw_one',
    isMatchOver = false,
    matchWinner = null,
    lastRoundPoints = 0,
    drawPileCount = 80,
    log = [],
    isContinuousDrawing = false,
    drawingPlayerIndex = null,
    drawingStepCount = 0,
    isDealing = false,
    turnStartTime = null,
    turnDuration = 15,
    isChoosingColor = false,
    colorChoosingPlayerIndex = null,
    pendingWildCard = null,
    canChallengeWildDraw4 = false,
    lastWildDraw4PlayerName = null
  } = gameState || {};

  const is2v2 = gameMode === '2v2';
  const isMyTurn = currentTurn === myIndex;

  // Visually synchronized hand cards & opponent counts (cards only enter hand upon landing!)
  const [displayedHand, setDisplayedHand] = useState(myHand);
  const [displayedCounts, setDisplayedCounts] = useState({});
  const initialSyncRef = useRef(false);
  const inflightCardIdsRef = useRef(new Set());
  const inflightOpponentCountsRef = useRef({});

  useEffect(() => {
    if (!initialSyncRef.current && myHand && myHand.length > 0) {
      initialSyncRef.current = true;
      setDisplayedHand(myHand);
      const counts = {};
      players.forEach(p => { counts[p.id] = p.cardCount; });
      setDisplayedCounts(counts);
    }
  }, [myHand, players]);

  useEffect(() => {
    if (gameState?.gameStatus === 'game_over') {
      setDisplayedHand(myHand);
      const counts = {};
      players.forEach(p => { counts[p.id] = p.cardCount; });
      setDisplayedCounts(counts);
    }
  }, [gameState?.gameStatus]);

  const myPlayer = players[myIndex] || { name: '你 (玩家)', cardCount: displayedHand.length };

  // Turn-based state for contextual actions
  const [localHasDrawn, setLocalHasDrawn] = useState(false);
  const hasDrawnThisTurn = isMyTurn && (localHasDrawn || remoteHasDrawn);

  // Reset local hasDrawn state on turn change
  useEffect(() => {
    setLocalHasDrawn(false);
  }, [currentTurn]);

  // Auto penalty draw when facing +2/+4 penalty without matching stack cards (guarded against +4 challenge phase)
  const autoPenaltyTimerRef = useRef(null);

  useEffect(() => {
    if (isMyTurn && !isDealing && stackedDrawCount > 0 && validCards.length === 0 && !canChallengeWildDraw4) {
      showToast(`💥 無對應牌可疊！自動承受累積罰抽【+${stackedDrawCount} 張】...`);
      autoPenaltyTimerRef.current = setTimeout(() => {
        handleDrawWithAnimation();
      }, 750);
      return () => {
        if (autoPenaltyTimerRef.current) {
          clearTimeout(autoPenaltyTimerRef.current);
          autoPenaltyTimerRef.current = null;
        }
      };
    }
  }, [isMyTurn, isDealing, stackedDrawCount, validCards.length, canChallengeWildDraw4]);

  // Calculate Seats (Top, Left, Right)
  const totalP = players.length;
  // Clockwise (順時針): Turn advances to your LEFT (下家: +1), Teammate/Opposite (+2) is TOP, Previous (+3) is RIGHT (上家)
  const leftSeatIdx = totalP === 4 ? (myIndex + 1) % 4 : (totalP === 3 ? (myIndex + 1) % 3 : null);
  const topSeatIdx = totalP === 4 ? (myIndex + 2) % 4 : (totalP === 3 ? (myIndex + 2) % 3 : (totalP === 2 ? (myIndex + 1) % 2 : null));
  const rightSeatIdx = totalP === 4 ? (myIndex + 3) % 4 : null;

  const leftPlayer = leftSeatIdx !== null ? players[leftSeatIdx] : null;
  const topPlayer = topSeatIdx !== null ? players[topSeatIdx] : null;
  const rightPlayer = rightSeatIdx !== null ? players[rightSeatIdx] : null;

  const isTeammateTop = is2v2 && topSeatIdx === teammateIndex;

  const getPlayerRef = (seatIdx) => {
    if (seatIdx === myIndex) return myHandRef.current;
    if (seatIdx === leftSeatIdx) return leftPlayerRef.current;
    if (seatIdx === topSeatIdx) return topPlayerRef.current;
    if (seatIdx === rightSeatIdx) return rightPlayerRef.current;
    return null;
  };

  // Trigger Opening Deal Animation when isDealing is true
  const hasAnimatedDealRef = useRef(false);
  const dealTimerRef = useRef(null);
  const wasDealingRef = useRef(false);

  useEffect(() => {
    if (isDealing) {
      wasDealingRef.current = true;
      if (hasAnimatedDealRef.current) return;

      // Sync displayed hand & counts for the deal
      if (myHand && myHand.length > 0) {
        setDisplayedHand(myHand);
        const counts = {};
        players.forEach(p => { counts[p.id] = p.cardCount; });
        setDisplayedCounts(counts);
      }

      // Smooth fan out of hand cards on game start/deal
      setIsHandCollapsed(true);
      const collapseTimer = setTimeout(() => {
        setIsHandCollapsed(false);
        soundManager.playShuffle();
      }, 260);

      let attempts = 0;
      const runDealAnimation = () => {
        const seats = [
          myHandRef.current,
          leftPlayerRef.current,
          topPlayerRef.current,
          rightPlayerRef.current
        ].filter(Boolean);

        const drawEl = drawPileRef.current;
        const discardEl = discardPileRef.current;

        if (drawEl && discardEl && seats.length > 0) {
          hasAnimatedDealRef.current = true;
          const firstCardKey = topCard?.displayAssetKey || topCard?.assetKey || 'card_back';
          cardAnimationService.animateOpeningDeal({
            drawPileEl: drawEl,
            seatElements: seats,
            discardPileEl: discardEl,
            firstCardKey
          });
        } else if (attempts < 15) {
          attempts++;
          dealTimerRef.current = setTimeout(runDealAnimation, 60);
        }
      };

      dealTimerRef.current = setTimeout(runDealAnimation, 120);

      return () => {
        clearTimeout(collapseTimer);
        if (dealTimerRef.current) {
          clearTimeout(dealTimerRef.current);
          dealTimerRef.current = null;
        }
        hasAnimatedDealRef.current = false;
      };
    } else {
      hasAnimatedDealRef.current = false;
      if (wasDealingRef.current) {
        wasDealingRef.current = false;
        if (isMyTurn) {
          soundManager.playTurn();
        }
      }
    }
  }, [isDealing]);

  // Remote / AI animation detection & Action Events
  useEffect(() => {
    if (!gameState) return;

    // 1. Precise action-driven animations from engine
    const lastAction = gameState.lastAction;
    if (lastAction && lastAction.timestamp && lastAction.timestamp !== prevActionTimeRef.current) {
      prevActionTimeRef.current = lastAction.timestamp;

      if (lastAction.type === 'play') {
        // If not human player, trigger flight animation from player seat to discard pile
        if (lastAction.playerId !== myIndex) {
          const fromEl = getPlayerRef(lastAction.playerId);
          if (fromEl && discardPileRef.current) {
            const cardKey = lastAction.card.displayAssetKey || lastAction.card.assetKey;
            cardAnimationService.animatePlayCard(fromEl, discardPileRef.current, cardKey);
          }
        }

        // Action card transitions & sound effects
        if (lastAction.card.value === 'skip') {
          soundManager.playSkip();
          setSkippedPlayerInfo({
            playerId: lastAction.skippedPlayerId,
            playerName: lastAction.skippedPlayerName,
            sourceName: lastAction.playerName
          });
          setTimeout(() => setSkippedPlayerInfo(null), 2400);
        } else if (lastAction.card.value === 'reverse') {
          soundManager.playAction();
        } else if (['draw2', 'wild_draw4'].includes(lastAction.card.value)) {
          soundManager.playAction();
        } else if (lastAction.card.color === 'wild') {
          soundManager.playWild();
        }
      } else if (lastAction.type === 'draw_autopass') {
        if (lastAction.playerId === myIndex) {
          showToast('💨 抽到的牌無法出，系統已自動跳過回合！');
        }
      }
    } else if (topCard && prevTopCardRef.current && prevTopCardRef.current.id !== topCard.id) {
      // Fallback topCard diffing
      const prevTurn = (currentTurn - direction + totalP) % totalP;
      if (prevTurn !== myIndex) {
        const fromEl = getPlayerRef(prevTurn);
        if (fromEl && discardPileRef.current) {
          const cardKey = topCard.displayAssetKey || topCard.assetKey;
          cardAnimationService.animatePlayCard(fromEl, discardPileRef.current, cardKey);
        }
      }
    }
    prevTopCardRef.current = topCard;

    // 2. Synchronize drawn card flights and exact landing additions
    // For local player's hand:
    if (myHand.length < displayedHand.length) {
      setDisplayedHand(myHand);
    } else if (myHand.length > displayedHand.length) {
      const newCards = myHand.filter(c => !displayedHand.some(dh => dh.id === c.id) && !inflightCardIdsRef.current.has(c.id));
      newCards.forEach((c, idx) => {
        inflightCardIdsRef.current.add(c.id);
        setTimeout(() => {
          if (drawPileRef.current && myHandRef.current) {
            cardAnimationService.animateDrawCard(drawPileRef.current, myHandRef.current, 'card_back', () => {
              inflightCardIdsRef.current.delete(c.id);
              setDisplayedHand(prev => {
                if (prev.some(p => p.id === c.id)) return prev;
                return [...prev, c];
              });
            });
          } else {
            inflightCardIdsRef.current.delete(c.id);
            setDisplayedHand(prev => {
              if (prev.some(p => p.id === c.id)) return prev;
              return [...prev, c];
            });
          }
        }, idx * 280);
      });
    }

    // For opponents:
    players.forEach((p) => {
      if (p.id === myIndex) return;
      const scheduledCount = inflightOpponentCountsRef.current[p.id] !== undefined
        ? inflightOpponentCountsRef.current[p.id]
        : (displayedCounts[p.id] !== undefined ? displayedCounts[p.id] : p.cardCount);

      if (p.cardCount < scheduledCount) {
        inflightOpponentCountsRef.current[p.id] = p.cardCount;
        setDisplayedCounts(prev => ({ ...prev, [p.id]: p.cardCount }));
      } else if (p.cardCount > scheduledCount) {
        const diff = p.cardCount - scheduledCount;
        inflightOpponentCountsRef.current[p.id] = p.cardCount;
        const toEl = getPlayerRef(p.id);
        for (let k = 0; k < diff; k++) {
          setTimeout(() => {
            if (toEl && drawPileRef.current) {
              cardAnimationService.animateDrawCard(drawPileRef.current, toEl, 'card_back', () => {
                setDisplayedCounts(prev => ({
                  ...prev,
                  [p.id]: Math.min(p.cardCount, (prev[p.id] !== undefined ? prev[p.id] : scheduledCount) + 1)
                }));
              });
            } else {
              setDisplayedCounts(prev => ({ ...prev, [p.id]: p.cardCount }));
            }
          }, k * 280);
        }
      }
    });
  }, [gameState]);

  const handleMuteToggle = () => {
    const isMuted = soundManager.toggleMute();
    setMuted(isMuted);
  };

  const handleCopyCode = () => {
    navigator.clipboard.writeText(roomCode);
    setCopiedCode(true);
    setTimeout(() => setCopiedCode(false), 2000);
  };

  // Manual Hand Sort & Ripple Fan-out Trigger
  const handleSortHand = () => {
    soundManager.playShuffle();
    setIsHandCollapsed(true);
    setTimeout(() => {
      setIsSorted((prev) => !prev);
      setIsHandCollapsed(false);
      showToast('✨ 已為您整理手牌並展開！');
    }, 180);
  };

  // Play card with flight animation
  const handleCardClick = (card, cardEl) => {
    if (isDealing) {
      showToast('🎴 開局發牌中，請稍候...');
      return;
    }
    if (isContinuousDrawing) {
      showToast('正在連續抽牌中，請稍候...');
      return;
    }
    if (isChoosingColor) {
      showToast('🌈 正在選擇顏色階段，請選擇牌面顏色！');
      return;
    }
    if (!isMyTurn) {
      showToast(`尚未輪到你的回合！目前輪到【${players[currentTurn]?.name || '對手'}】出牌`);
      return;
    }
    if (!validCards.includes(card.id)) {
      showToast(`此牌不符合出牌規則！頂牌需出同顏色或同數字/功能，或萬用牌！`);
      return;
    }

    const hasPreCalledUno = !!myPlayer.calledUno;

    if (card.color === 'wild') {
      soundManager.playWild();
      setLocalHasDrawn(false);
      setDisplayedHand(prev => prev.filter(c => c.id !== card.id));

      if (cardEl && discardPileRef.current) {
        const cardKey = card.displayAssetKey || card.assetKey;
        cardAnimationService.animatePlayCard(cardEl, discardPileRef.current, cardKey, () => {
          onPlayCard(card.id, null, hasPreCalledUno);
        });
      } else {
        onPlayCard(card.id, null, hasPreCalledUno);
      }
    } else {
      // Skip card transition
      if (card.value === 'skip') {
        soundManager.playSkip();
        const skippedIdx = (currentTurn + direction + totalP) % totalP;
        setSkippedPlayerInfo({
          playerId: skippedIdx,
          playerName: players[skippedIdx]?.name || '下家',
          sourceName: '你'
        });
        setTimeout(() => setSkippedPlayerInfo(null), 2400);
      } else if (card.value === 'reverse' || card.value === 'draw2') {
        soundManager.playAction();
      }

      setLocalHasDrawn(false);
      setDisplayedHand(prev => prev.filter(c => c.id !== card.id));

      if (cardEl && discardPileRef.current) {
        const cardKey = card.displayAssetKey || card.assetKey;
        cardAnimationService.animatePlayCard(cardEl, discardPileRef.current, cardKey, () => {
          onPlayCard(card.id, null, hasPreCalledUno);
        });
      } else {
        onPlayCard(card.id, null, hasPreCalledUno);
      }
    }
  };

  const handleConfirmWildColor = (chosenColor) => {
    if (onChooseColor) {
      onChooseColor(chosenColor);
    }
  };

  // Draw card with flight animation
  const handleDrawWithAnimation = () => {
    if (isDealing) {
      showToast('🎴 開局發牌中，請稍候...');
      return;
    }
    if (isContinuousDrawing) return;
    if (isChoosingColor) return;
    if (!isMyTurn) {
      showToast(`尚未輪到你的回合！目前輪到【${players[currentTurn]?.name || '對手'}】出牌`);
      return;
    }
    if (hasDrawnThisTurn && stackedDrawCount === 0) {
      showToast('⚠️ 本回合你已經主動抽過牌了！請打出手牌或點擊「過牌 (Pass)」！');
      return;
    }

    setLocalHasDrawn(true);
    onDrawCard();
  };

  const myColorCounts = {
    red: displayedHand.filter((c) => c.color === 'red').length,
    blue: displayedHand.filter((c) => c.color === 'blue').length,
    green: displayedHand.filter((c) => c.color === 'green').length,
    yellow: displayedHand.filter((c) => c.color === 'yellow').length
  };

  const colorLabels = {
    red: { name: '紅色', hex: '#ef4444', emoji: '🔴' },
    blue: { name: '藍色', hex: '#3b82f6', emoji: '🔵' },
    green: { name: '綠色', hex: '#22c55e', emoji: '🟢' },
    yellow: { name: '黃色', hex: '#eab308', emoji: '🟡' },
    wild: { name: '指定色', hex: '#ffffff', emoji: '🌈' }
  };

  const activeColorInfo = colorLabels[currentColor] || colorLabels.red;
  const handToDisplay = isSorted ? sortHandCards(displayedHand) : displayedHand;

  return (
    <div className="relative w-screen min-h-screen felt-table flex flex-col justify-between overflow-x-hidden select-none">
      {/* Toast Notification */}
      {toastMessage && (
        <div className="fixed top-14 left-1/2 -translate-x-1/2 z-50 px-4 py-2 rounded-xl bg-amber-500 text-black font-extrabold text-xs sm:text-sm shadow-2xl animate-bounce flex items-center gap-1.5">
          <span>⚠️ {toastMessage}</span>
        </div>
      )}

      {/* TOP HEADER */}
      <header className="relative z-30 flex items-center justify-between px-3 sm:px-6 py-2.5 bg-black/50 border-b border-emerald-500/20 backdrop-blur-md">
        <div className="flex items-center gap-2.5">
          <div className="flex items-center gap-1.5 px-3 py-1 rounded-full bg-red-600 text-yellow-300 font-black text-xs tracking-wider shadow">
            UNO
          </div>

          <button
            type="button"
            onClick={handleCopyCode}
            title="點擊複製房號"
            className="flex items-center gap-1.5 px-3 py-1 rounded-full bg-emerald-950/80 border border-emerald-500/40 text-amber-400 font-mono text-xs font-bold hover:bg-emerald-900 transition"
          >
            <span>{roomCode}</span>
            {copiedCode ? <Check className="w-3.5 h-3.5 text-green-400" /> : <span className="text-[10px] text-emerald-400">複製</span>}
          </button>

          <div className="flex items-center gap-1 px-2.5 py-1 rounded-full bg-amber-500/15 border border-amber-500/30 text-xs text-amber-300 font-semibold">
            {is2v2 ? <UserCheck className="w-3.5 h-3.5 text-amber-400" /> : <Swords className="w-3.5 h-3.5 text-amber-400" />}
            <span>{is2v2 ? '2V2 雙人組隊戰' : '多人混戰'}</span>
          </div>

          {targetScore > 0 ? (
            <div className="hidden md:flex items-center gap-1 px-2.5 py-1 rounded-full bg-amber-500/10 border border-amber-400/25 text-xs text-amber-300 font-bold">
              <span>🏆 目標 {targetScore} 分</span>
            </div>
          ) : (
            <div className="hidden md:flex items-center gap-1 px-2.5 py-1 rounded-full bg-emerald-500/10 border border-emerald-400/20 text-xs text-emerald-300 font-medium">
              <span>🎮 暢玩模式</span>
            </div>
          )}

          {drawRule === 'draw_until_playable' && (
            <div className="hidden lg:flex items-center gap-1 px-2 py-0.5 rounded-full bg-sky-500/15 border border-sky-400/30 text-[11px] text-sky-300 font-bold">
              <span>🔄 連續抽牌</span>
            </div>
          )}
        </div>

        <div className="flex items-center gap-2">
          <button
            type="button"
            onClick={handleMuteToggle}
            className="p-1.5 rounded-xl bg-emerald-950/60 hover:bg-emerald-900 border border-emerald-500/20 text-emerald-300 transition"
          >
            {muted ? <VolumeX className="w-4 h-4 text-red-400" /> : <Volume2 className="w-4 h-4 text-emerald-400" />}
          </button>
          <button
            type="button"
            onClick={() => setShowLogDrawer(!showLogDrawer)}
            className="p-1.5 px-2.5 rounded-xl bg-emerald-950/60 hover:bg-emerald-900 border border-emerald-500/20 text-emerald-300 transition flex items-center gap-1 text-xs"
          >
            <History className="w-4 h-4" />
            <span className="hidden sm:inline">對局紀錄</span>
          </button>
          <button
            type="button"
            onClick={() => {
              if (isHost) {
                if (window.confirm('確定要解散房間嗎？對局將立即結束，所有玩家將返回首頁。')) {
                  if (onLeaveRoom) onLeaveRoom();
                }
              } else {
                if (window.confirm('確定要離開對局嗎？你將退出並轉由電腦託管。')) {
                  if (onLeaveRoom) onLeaveRoom();
                }
              }
            }}
            title={isHost ? '解散房間' : '離開對局'}
            className="p-1.5 px-2.5 rounded-xl bg-red-950/70 hover:bg-red-900 border border-red-500/30 text-red-300 transition flex items-center gap-1 text-xs font-bold"
          >
            <LogOut className="w-3.5 h-3.5" />
            <span className="hidden sm:inline">{isHost ? '解散' : '離開'}</span>
          </button>
        </div>
      </header>

      {/* ============================================================== */}
      {/* GAME ARENA TABLE (1:1 from 螢幕擷取畫面 2026-10-13 150340.png) */}
      {/* ============================================================== */}
      <main className="relative flex-1 flex items-center justify-center p-2 sm:p-5">
        <div className="table-surface">

          {/* ---------------------------------------------------------- */}
          {/* TOP ROW: OPPONENT 2 (Or Teammate in 2V2)                   */}
          {/* ---------------------------------------------------------- */}
          <div className="w-full flex flex-col items-center justify-center min-h-[90px] z-10">
            {topPlayer && (
              <div
                ref={topPlayerRef}
                className="flex flex-col items-center gap-1.5 transition-all duration-300"
              >
                {/* Player Info Card (Pill Badge) & Turn Timer Circle */}
                <div className="flex items-center gap-2">
                  <div
                    className={`flex items-center gap-2.5 px-3.5 py-1.5 rounded-full border shadow-lg backdrop-blur-md transition-all duration-200 ${
                      skippedPlayerInfo && topPlayer && topPlayer.id === skippedPlayerInfo.playerId
                        ? 'skip-shake ring-4 ring-red-500 bg-red-950/90 border-red-400'
                        : (((currentTurn === topPlayer.id && !isDealing) || (isChoosingColor && colorChoosingPlayerIndex === topPlayer.id)))
                        ? 'active-turn-ring scale-105'
                        : 'bg-[#0a1c12]/90 border-white/15'
                    }`}
                  >
                    <div className="w-7 h-7 rounded-full bg-[#1e3a2b] border border-white/20 flex items-center justify-center text-sm">
                      {isTeammateTop ? '🤝' : '🤖'}
                    </div>
                    <div className="flex flex-col">
                      <span className="text-xs font-bold text-white flex items-center gap-1">
                        {topPlayer.name}
                        {isTeammateTop && (
                          <span className="text-[10px] px-1.5 py-0.2 rounded-full bg-amber-400/20 text-amber-300 font-extrabold border border-amber-400/40">
                            隊友
                          </span>
                        )}
                      </span>
                      <span className="text-[10px] text-gray-300">{(displayedCounts[topPlayer.id] !== undefined ? displayedCounts[topPlayer.id] : topPlayer.cardCount)} 張牌</span>
                    </div>

                    {skippedPlayerInfo && topPlayer && topPlayer.id === skippedPlayerInfo.playerId && (
                      <span className="px-2 py-0.5 rounded-full bg-red-600 text-white font-black text-[10px] shadow-2xl animate-bounce border border-yellow-300 flex items-center gap-1">
                        🚫 跳過！
                      </span>
                    )}
                    {topPlayer.calledUno && (
                      <span className="px-2 py-0.5 rounded-full bg-red-600 text-yellow-300 font-black text-[10px] shadow animate-pulse">
                        UNO!
                      </span>
                    )}
                    {isChoosingColor && colorChoosingPlayerIndex === topPlayer.id ? (
                      <span className="text-[10px] font-bold text-purple-300 animate-pulse flex items-center gap-1">
                        🌈 選色中 (6s)
                      </span>
                    ) : isContinuousDrawing && drawingPlayerIndex === topPlayer.id ? (
                      <span className="text-[10px] font-bold text-sky-300 animate-pulse flex items-center gap-1">
                        <RotateCw className="w-2.5 h-2.5 animate-spin" />
                        抽牌中 ({drawingStepCount || 1})
                      </span>
                    ) : currentTurn === topPlayer.id && !skippedPlayerInfo && !isDealing && (
                      <span className="text-[10px] font-bold text-yellow-300 animate-pulse">
                        思考中 💭
                      </span>
                    )}
                  </div>
                  {((currentTurn === topPlayer.id && !isChoosingColor) || (isChoosingColor && colorChoosingPlayerIndex === topPlayer.id)) && !isDealing && !isContinuousDrawing && gameState?.gameStatus !== 'game_over' && (
                    <TurnTimerCircle turnStartTime={turnStartTime} duration={turnDuration || (isChoosingColor ? 6 : 15)} />
                  )}
                </div>

                {/* Hand Display: If 2V2 Teammate, cards face-up! If opponent, card back */}
                <div className="flex items-center justify-center mt-1">
                  {isTeammateTop ? (
                    <div className="flex items-center -space-x-4 sm:-space-x-5">
                      {teammateHand.map((c, cIdx) => (
                        <div
                          key={c.id || cIdx}
                          className="transition-transform duration-150 hover:-translate-y-2 hover:scale-120 cursor-pointer"
                          title={`隊友手牌: ${c.color} ${c.value}`}
                        >
                          <CardView card={c} isSmall className="drop-shadow-md" />
                        </div>
                      ))}
                    </div>
                  ) : (
                    <div className="relative">
                      <CardView isBack isSmall className="drop-shadow-md" />
                    </div>
                  )}
                </div>

                {topPlayer.unoVulnerable && (
                  <button
                    type="button"
                    onClick={() => onChallengeUno(topPlayer.id)}
                    className="py-0.5 px-2.5 rounded-full bg-red-600 hover:bg-red-500 text-white font-bold text-[10px] shadow-lg animate-bounce flex items-center gap-1"
                  >
                    <AlertTriangle className="w-3 h-3" />
                    抓漏 UNO!
                  </button>
                )}
              </div>
            )}
          </div>

          {/* ---------------------------------------------------------- */}
          {/* MIDDLE ROW: OPPONENT 1 | CENTER ARENA | OPPONENT 3        */}
          {/* ---------------------------------------------------------- */}
          <div className="flex-1 flex items-center justify-between gap-4 px-2 sm:px-6 z-10">

            {/* LEFT OPPONENT (Player 1) */}
            <div className="w-32 flex flex-col items-center">
              {leftPlayer && (
                <div
                  ref={leftPlayerRef}
                  className="flex flex-col items-center gap-2 transition-all duration-300"
                >
                  <div className="flex items-center gap-2">
                    <div
                      className={`flex items-center gap-2 px-3 py-1.5 rounded-full border shadow-lg backdrop-blur-md transition-all duration-200 ${
                        skippedPlayerInfo && leftPlayer && leftPlayer.id === skippedPlayerInfo.playerId
                          ? 'skip-shake ring-4 ring-red-500 bg-red-950/90 border-red-400'
                          : (((currentTurn === leftPlayer.id && !isDealing) || (isChoosingColor && colorChoosingPlayerIndex === leftPlayer.id)))
                          ? 'active-turn-ring scale-105'
                          : 'bg-[#0a1c12]/90 border-white/15'
                      }`}
                    >
                      <div className="w-7 h-7 rounded-full bg-[#1e3a2b] border border-white/20 flex items-center justify-center text-sm">
                        👾
                      </div>
                      <div className="flex flex-col">
                        <span className="text-xs font-bold text-white max-w-[65px] truncate">
                          {leftPlayer.name}
                        </span>
                        <span className="text-[10px] text-gray-300">{(displayedCounts[leftPlayer.id] !== undefined ? displayedCounts[leftPlayer.id] : leftPlayer.cardCount)} 張牌</span>
                      </div>
                      {skippedPlayerInfo && leftPlayer && leftPlayer.id === skippedPlayerInfo.playerId && (
                        <span className="px-1.5 py-0.5 rounded-full bg-red-600 text-white font-black text-[9px] shadow-2xl animate-bounce border border-yellow-300">
                          🚫 跳過！
                        </span>
                      )}
                      {leftPlayer.calledUno && (
                        <span className="px-1.5 py-0.5 rounded-full bg-red-600 text-yellow-300 font-black text-[9px] shadow animate-pulse">
                          UNO!
                        </span>
                      )}
                      {isChoosingColor && colorChoosingPlayerIndex === leftPlayer.id && (
                        <span className="px-1.5 py-0.5 rounded-full bg-purple-600 text-white font-bold text-[9px] animate-pulse">
                          🌈 選色中 (6s)
                        </span>
                      )}
                      {isContinuousDrawing && drawingPlayerIndex === leftPlayer.id && (
                        <span className="px-1.5 py-0.5 rounded-full bg-sky-600 text-white font-bold text-[9px] animate-pulse flex items-center gap-0.5">
                          <RotateCw className="w-2.5 h-2.5 animate-spin" />
                          抽牌({drawingStepCount || 1})
                        </span>
                      )}
                    </div>
                    {((currentTurn === leftPlayer.id && !isChoosingColor) || (isChoosingColor && colorChoosingPlayerIndex === leftPlayer.id)) && !isDealing && !isContinuousDrawing && gameState?.gameStatus !== 'game_over' && (
                      <TurnTimerCircle turnStartTime={turnStartTime} duration={turnDuration || (isChoosingColor ? 6 : 15)} />
                    )}
                  </div>

                  <div className="mt-1">
                    <CardView isBack isSmall className="drop-shadow-md" />
                  </div>

                  {leftPlayer.unoVulnerable && (
                    <button
                      type="button"
                      onClick={() => onChallengeUno(leftPlayer.id)}
                      className="py-0.5 px-2 rounded-full bg-red-600 hover:bg-red-500 text-white font-bold text-[10px] shadow-lg animate-bounce flex items-center gap-1"
                    >
                      <AlertTriangle className="w-3 h-3" />
                      抓漏 UNO!
                    </button>
                  )}
                </div>
              )}
            </div>

            {/* CENTER ARENA (Draw Pile, Discard Pile, Status Bar) */}
            <div className="relative flex flex-col items-center justify-center gap-4">
              {/* Skip Floating Banner */}
              {skippedPlayerInfo && (
                <div className="absolute -top-12 left-1/2 -translate-x-1/2 z-40 px-4 py-1.5 rounded-full bg-red-600 border-2 border-yellow-300 text-white font-black text-xs sm:text-sm shadow-2xl animate-bounce flex items-center gap-1.5 whitespace-nowrap">
                  <span className="text-sm">🚫</span>
                  <span>【{skippedPlayerInfo.sourceName}】出禁止牌！跳過【{skippedPlayerInfo.playerName}】！</span>
                </div>
              )}

              {/* Dealing Opening Banner */}
              {isDealing && (
                <div className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 z-40 px-5 py-2 rounded-full bg-black/90 border-2 border-amber-400 text-amber-300 font-extrabold text-xs sm:text-sm shadow-2xl animate-pulse flex items-center gap-2 whitespace-nowrap backdrop-blur-md">
                  <RotateCw className="w-4 h-4 animate-spin text-amber-400" />
                  <span>🎴 開局發牌中，請稍候...</span>
                </div>
              )}

              {/* Piles Row */}
              <div className="flex items-center justify-center gap-8 sm:gap-12">

                {/* Draw Pile (Left) */}
                <div className="flex flex-col items-center gap-2">
                  <div
                    ref={drawPileRef}
                    onClick={isContinuousDrawing ? undefined : handleDrawWithAnimation}
                    title={
                      isContinuousDrawing
                        ? '正在連續抽牌中...'
                        : (hasDrawnThisTurn && stackedDrawCount === 0)
                        ? '本回合已抽過牌，請打出手牌或點擊過牌'
                        : '點擊抽一張牌'
                    }
                    className={`relative transition-transform duration-150 ${
                      isContinuousDrawing
                        ? 'cursor-wait opacity-80'
                        : (hasDrawnThisTurn && stackedDrawCount === 0)
                        ? 'cursor-not-allowed opacity-75'
                        : 'cursor-pointer hover:-translate-y-1 hover:scale-105 active:scale-95'
                    }`}
                  >
                    {/* Subtle deck stack depth layers */}
                    <div className="absolute top-1 left-1 w-20 h-30 sm:w-24 sm:h-36 rounded-xl bg-black/40 border border-white/10" />
                    <div className="absolute top-0.5 left-0.5 w-20 h-30 sm:w-24 sm:h-36 rounded-xl bg-[#0a1c12] border border-white/15" />
                    <CardView isBack />
                  </div>
                  {/* Pile Count Badge (80 張) */}
                  <div className="bg-black/75 px-3 py-0.5 rounded-full text-xs font-bold text-gray-200 border border-white/15 shadow">
                    {drawPileCount || 80} 張
                  </div>
                </div>

                {/* Discard Pile (Right) */}
                <div className="flex flex-col items-center gap-2">
                  <div
                    ref={discardPileRef}
                    className="relative transition-transform duration-300"
                    style={{ transform: 'rotate(-3deg)' }}
                  >
                    <CardView card={topCard} isTopCard />
                  </div>
                  {/* Active Color Badge (🔴 紅色) */}
                  <div className="flex items-center gap-1.5 px-3.5 py-1 rounded-full bg-[#0a1c12]/95 border border-white/20 shadow-lg text-xs font-bold text-white">
                    <span
                      className="w-3 h-3 rounded-full inline-block shadow-sm"
                      style={{
                        backgroundColor: activeColorInfo.hex,
                        boxShadow: `0 0 8px ${activeColorInfo.hex}`
                      }}
                    />
                    <span>{activeColorInfo.name}</span>
                  </div>
                </div>

              </div>

              {/* Direction & Game Status Bar */}
              <div className="flex items-center gap-3 mt-1">
                <div className="flex items-center gap-1.5 px-3.5 py-1 rounded-full bg-black/60 border border-white/15 text-xs font-bold text-gray-200 shadow">
                  {direction === 1 ? (
                    <>
                      <RotateCw className="w-3.5 h-3.5 text-sky-400" />
                      <span>順時針出牌</span>
                    </>
                  ) : (
                    <>
                      <RotateCcw className="w-3.5 h-3.5 text-amber-400" />
                      <span>逆時針出牌</span>
                    </>
                  )}
                </div>

                {stackedDrawCount > 0 && (
                  <div className="flex items-center gap-1.5 px-3.5 py-1 rounded-full bg-gradient-to-r from-red-600 to-amber-600 border border-red-300 text-white font-extrabold text-xs shadow-lg animate-pulse">
                    <Flame className="w-3.5 h-3.5 text-yellow-300 fill-current" />
                    <span>累積罰抽：+{stackedDrawCount} 張</span>
                  </div>
                )}
              </div>
            </div>

            {/* RIGHT OPPONENT (Player 3) */}
            <div className="w-32 flex flex-col items-center">
              {rightPlayer && (
                <div
                  ref={rightPlayerRef}
                  className="flex flex-col items-center gap-2 transition-all duration-300"
                >
                  <div className="flex items-center gap-2">
                    {((currentTurn === rightPlayer.id && !isChoosingColor) || (isChoosingColor && colorChoosingPlayerIndex === rightPlayer.id)) && !isDealing && !isContinuousDrawing && gameState?.gameStatus !== 'game_over' && (
                      <TurnTimerCircle turnStartTime={turnStartTime} duration={turnDuration || (isChoosingColor ? 6 : 15)} />
                    )}
                    <div
                      className={`flex items-center gap-2 px-3 py-1.5 rounded-full border shadow-lg backdrop-blur-md transition-all duration-200 ${
                        skippedPlayerInfo && rightPlayer && rightPlayer.id === skippedPlayerInfo.playerId
                          ? 'skip-shake ring-4 ring-red-500 bg-red-950/90 border-red-400'
                          : (((currentTurn === rightPlayer.id && !isDealing) || (isChoosingColor && colorChoosingPlayerIndex === rightPlayer.id)))
                          ? 'active-turn-ring scale-105'
                          : 'bg-[#0a1c12]/90 border-white/15'
                      }`}
                    >
                      <div className="w-7 h-7 rounded-full bg-[#1e3a2b] border border-white/20 flex items-center justify-center text-sm">
                        🎯
                      </div>
                      <div className="flex flex-col">
                        <span className="text-xs font-bold text-white max-w-[65px] truncate">
                          {rightPlayer.name}
                        </span>
                        <span className="text-[10px] text-gray-300">{(displayedCounts[rightPlayer.id] !== undefined ? displayedCounts[rightPlayer.id] : rightPlayer.cardCount)} 張牌</span>
                      </div>
                      {skippedPlayerInfo && rightPlayer && rightPlayer.id === skippedPlayerInfo.playerId && (
                        <span className="px-1.5 py-0.5 rounded-full bg-red-600 text-white font-black text-[9px] shadow-2xl animate-bounce border border-yellow-300">
                          🚫 跳過！
                        </span>
                      )}
                      {rightPlayer.calledUno && (
                        <span className="px-1.5 py-0.5 rounded-full bg-red-600 text-yellow-300 font-black text-[9px] shadow animate-pulse">
                          UNO!
                        </span>
                      )}
                      {isChoosingColor && colorChoosingPlayerIndex === rightPlayer.id && (
                        <span className="px-1.5 py-0.5 rounded-full bg-purple-600 text-white font-bold text-[9px] animate-pulse">
                          🌈 選色中 (6s)
                        </span>
                      )}
                      {isContinuousDrawing && drawingPlayerIndex === rightPlayer.id && (
                        <span className="px-1.5 py-0.5 rounded-full bg-sky-600 text-white font-bold text-[9px] animate-pulse flex items-center gap-0.5">
                          <RotateCw className="w-2.5 h-2.5 animate-spin" />
                          抽牌({drawingStepCount || 1})
                        </span>
                      )}
                    </div>
                  </div>

                  <div className="mt-1">
                    <CardView isBack isSmall className="drop-shadow-md" />
                  </div>

                  {rightPlayer.unoVulnerable && (
                    <button
                      type="button"
                      onClick={() => onChallengeUno(rightPlayer.id)}
                      className="py-0.5 px-2 rounded-full bg-red-600 hover:bg-red-500 text-white font-bold text-[10px] shadow-lg animate-bounce flex items-center gap-1"
                    >
                      <AlertTriangle className="w-3 h-3" />
                      抓漏 UNO!
                    </button>
                  )}
                </div>
              )}
            </div>

          </div>

          {/* ---------------------------------------------------------- */}
          {/* BOTTOM ROW: HUMAN PLAYER CONTROLS & FANNED HAND            */}
          {/* ---------------------------------------------------------- */}
          <div className="w-full flex flex-col items-center z-20 pb-2">

            {/* Controls Bar */}
            <div className="w-full max-w-4xl flex items-center justify-between px-4 mb-2">
              {/* Human Player Badge & Turn Timer Circle (Bottom-Left) */}
              <div className="flex items-center gap-2">
                <div
                  className={`flex items-center gap-2.5 px-3.5 py-1.5 rounded-full border shadow-lg backdrop-blur-md transition-all duration-200 ${
                    skippedPlayerInfo && skippedPlayerInfo.playerId === myIndex
                      ? 'skip-shake ring-4 ring-red-500 bg-red-950/90 border-red-400'
                      : (((isMyTurn && !isDealing) || (isChoosingColor && colorChoosingPlayerIndex === myIndex))) ? 'active-turn-ring scale-105' : 'bg-[#0a1c12]/90 border-white/15'
                  }`}
                >
                  <div className="w-8 h-8 rounded-full bg-[#1e3a2b] border border-white/20 flex items-center justify-center text-sm">
                    👤
                  </div>
                  <div className="flex flex-col">
                    <span className="text-xs font-bold text-white">{myPlayer.name || '你 (玩家)'}</span>
                    <span className="text-[10px] text-gray-300">{displayedHand.length} 張牌</span>
                  </div>
                  {skippedPlayerInfo && skippedPlayerInfo.playerId === myIndex && (
                    <span className="px-2 py-0.5 rounded-full bg-red-600 text-white font-black text-[10px] shadow-2xl animate-bounce border border-yellow-300">
                      🚫 你的回合被跳過！
                    </span>
                  )}
                  {myPlayer.calledUno && (
                    <span className="px-2 py-0.5 rounded-full bg-red-600 text-yellow-300 font-black text-[10px] shadow animate-pulse">
                      UNO!
                    </span>
                  )}
                  {isChoosingColor && colorChoosingPlayerIndex === myIndex && (
                    <span className="px-2 py-0.5 rounded-full bg-purple-600 text-white font-black text-[10px] shadow-lg animate-pulse">
                      🌈 選色階段 (6s)
                    </span>
                  )}
                </div>
                {((isMyTurn && !isChoosingColor) || (isChoosingColor && colorChoosingPlayerIndex === myIndex)) && !isDealing && !isContinuousDrawing && gameState?.gameStatus !== 'game_over' && (
                  <TurnTimerCircle turnStartTime={turnStartTime} duration={turnDuration || (isChoosingColor ? 6 : 15)} isLocal />
                )}
              </div>

              {/* Action Buttons Group (Bottom-Right) */}
              <div className="flex items-center gap-2 sm:gap-2.5">
                {/* 整理手牌 按鈕 */}
                <button
                  type="button"
                  onClick={handleSortHand}
                  title="依顏色與數字整理手牌並重新展開"
                  className="py-1.5 px-3 sm:px-3.5 rounded-full bg-emerald-950/90 hover:bg-emerald-900 border border-emerald-400/40 text-emerald-300 font-bold text-xs shadow-md transition active:scale-95 flex items-center gap-1"
                >
                  <Sparkles className="w-3.5 h-3.5 text-amber-300" />
                  <span>整理手牌</span>
                </button>

                {isDealing ? (
                  <span className="text-xs text-amber-300 font-bold px-3.5 py-1.5 rounded-full bg-amber-500/15 border border-amber-400/30 flex items-center gap-1.5 animate-pulse">
                    <RotateCw className="w-3.5 h-3.5 animate-spin text-amber-400" />
                    <span>🎴 開局發牌中...</span>
                  </span>
                ) : (
                  <>
                    {!isMyTurn && !isChoosingColor && (
                      <span className="text-xs text-gray-300 font-medium px-3 py-1 rounded-full bg-black/40 border border-white/10 hidden sm:inline-block">
                        ⏳ 等待對手行動中...
                      </span>
                    )}

                    {/* Challenge UNO Button */}
                    {players.some((p) => p.unoVulnerable && p.id !== myIndex) && (
                      <button
                        type="button"
                        onClick={() => {
                          const target = players.find((p) => p.unoVulnerable && p.id !== myIndex);
                          if (target) onChallengeUno(target.id);
                        }}
                        className="py-1.5 px-3.5 rounded-full bg-red-600/80 hover:bg-red-600 border border-red-400 text-white font-bold text-xs shadow-lg animate-pulse"
                      >
                        ⚖️ 抓漏
                      </button>
                    )}

                    {/* Pass Button: ONLY when isMyTurn && hasDrawnThisTurn && stackedDrawCount === 0 */}
                    {isMyTurn && !isChoosingColor && hasDrawnThisTurn && stackedDrawCount === 0 && (
                      <button
                        type="button"
                        onClick={() => {
                          setLocalHasDrawn(false);
                          onPassTurn();
                        }}
                        className="py-1.5 px-4 rounded-full bg-white/10 hover:bg-white/20 border border-white/20 text-white font-bold text-xs shadow transition animate-in fade-in"
                      >
                        過牌 (Pass)
                      </button>
                    )}

                    {/* Manual UNO Button:
                        1. During turn when player has 2 cards with playable card (can pre-call before playing)
                        2. Or anytime with 1 card when player hasn't called UNO yet (can rescue call before being challenged) */}
                    {!isDealing && (((isMyTurn && !isChoosingColor && displayedHand.length === 2 && (validCards.length > 0 || myPlayer.calledUno))) || (displayedHand.length === 1)) && (
                      <button
                        type="button"
                        onClick={onCallUno}
                        disabled={myPlayer.calledUno}
                        className={`py-1.5 px-4 rounded-full font-black text-xs shadow-xl transition active:scale-95 ${
                          myPlayer.calledUno
                            ? 'bg-emerald-700 text-white opacity-80 cursor-default'
                            : 'bg-red-600 hover:bg-red-500 text-yellow-300 border-2 border-yellow-300 uno-alert-btn animate-bounce'
                        }`}
                      >
                        {myPlayer.calledUno ? '✓ 已喊 UNO！' : 'UNO！'}
                      </button>
                    )}

                    {/* Challenge Wild Draw 4 Button (Appears when victim faces +4) */}
                    {isMyTurn && !isChoosingColor && canChallengeWildDraw4 && (
                      <button
                        type="button"
                        onClick={onChallengeWildDraw4}
                        className="py-1.5 px-4 rounded-full font-black text-xs shadow-xl transition active:scale-95 bg-amber-500 hover:bg-amber-400 text-black border-2 border-yellow-200 animate-bounce flex items-center gap-1.5"
                      >
                        <span>⚖️ 質疑 +4！{lastWildDraw4PlayerName ? `(${lastWildDraw4PlayerName})` : ''}</span>
                      </button>
                    )}

                    {/* Draw Button or Auto Penalty Badge or Continuous Drawing State */}
                    {isMyTurn && !isChoosingColor && (!hasDrawnThisTurn || stackedDrawCount > 0) && (
                      stackedDrawCount > 0 && validCards.length === 0 && !canChallengeWildDraw4 ? (
                        <div className="py-1.5 px-3.5 sm:px-4 rounded-full font-bold text-xs bg-red-950/90 border border-red-500/60 text-red-300 flex items-center gap-1.5 shadow-lg animate-pulse">
                          <span>💥 自動承受罰抽 (+{stackedDrawCount})</span>
                        </div>
                      ) : isContinuousDrawing && drawingPlayerIndex === myIndex ? (
                        <div className="py-1.5 px-4 rounded-full font-extrabold text-xs shadow-lg bg-sky-900/90 border border-sky-400/50 text-sky-200 flex items-center gap-1.5 animate-pulse">
                          <RotateCw className="w-3.5 h-3.5 animate-spin text-sky-300" />
                          <span>連續抽牌中... (第 {drawingStepCount || 1} 張)</span>
                        </div>
                      ) : (
                        <button
                          type="button"
                          disabled={isContinuousDrawing}
                          onClick={handleDrawWithAnimation}
                          className="py-1.5 px-4 rounded-full font-extrabold text-xs shadow-lg transition duration-150 flex items-center gap-1 bg-gradient-to-r from-sky-600 to-sky-700 hover:from-sky-500 hover:to-sky-600 text-white active:scale-95 disabled:opacity-50"
                        >
                          <span>{stackedDrawCount > 0 ? '💥 承受罰抽' : '🎴 抽牌'}</span>
                          {drawRule === 'draw_until_playable' && stackedDrawCount === 0 && (
                            <span className="text-yellow-300 text-[10px] font-bold">(抽到能出)</span>
                          )}
                          {stackedDrawCount > 0 && <span className="text-yellow-300 font-black">(+{stackedDrawCount})</span>}
                        </button>
                      )
                    )}
                  </>
                )}
              </div>
            </div>

            {/* Fanned Hand Cards with Smooth Staggered Fan & Sorting Animation */}
            <div
              ref={myHandRef}
              className="w-full max-w-4xl px-4 pt-4 pb-1 overflow-visible flex items-center justify-center min-h-[140px]"
            >
              <div className="flex items-center justify-center -space-x-6 sm:-space-x-8 md:-space-x-10 overflow-visible transition-all">
                {handToDisplay.map((card, idx) => {
                  const isPlayable = !isDealing && isMyTurn && validCards.includes(card.id);
                  const count = handToDisplay.length;
                  const rotation = isHandCollapsed ? 0 : (idx - (count - 1) / 2) * 3;
                  const baseTranslateY = isHandCollapsed ? 22 : Math.abs(idx - (count - 1) / 2) * 2;
                  const sinkOffset = isMyTurn ? 0 : 38;
                  const translateY = baseTranslateY + sinkOffset;
                  const scale = isMyTurn ? (isHandCollapsed ? 0.94 : 1) : 0.93;

                  return (
                    <div
                      key={card.id}
                      style={{
                        transform: `rotate(${rotation}deg) translateY(${translateY}px) scale(${scale})`,
                        transformOrigin: 'bottom center',
                        filter: isDealing
                          ? 'brightness(0.7) saturate(80%)'
                          : (isMyTurn ? 'brightness(1) saturate(100%)' : 'brightness(0.62) saturate(75%)'),
                        transitionProperty: 'transform, filter',
                        transitionDuration: '380ms',
                        transitionTimingFunction: 'cubic-bezier(0.34, 1.4, 0.64, 1)',
                        transitionDelay: isHandCollapsed ? '0ms' : `${idx * 25}ms`,
                        pointerEvents: (isMyTurn && !isDealing) ? 'auto' : 'none'
                      }}
                      className={`overflow-visible transition-transform duration-200 ${
                        (isMyTurn && !isDealing) ? 'hover:z-40 hover:!rotate-0 hover:!-translate-y-6 cursor-pointer' : 'select-none'
                      }`}
                    >
                      <CardView
                        card={card}
                        isPlayable={isPlayable}
                        onClick={(e) => handleCardClick(card, e?.currentTarget)}
                        className="shadow-2xl"
                      />
                    </div>
                  );
                })}
              </div>
            </div>

          </div>

          {/* Floating Wild Color Picker Modal (Dedicated 6s Color Selection Phase) */}
          {isChoosingColor && colorChoosingPlayerIndex === myIndex && (
            <div className="absolute z-50 top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 p-5 rounded-3xl bg-[#0a1c12]/95 border-2 border-amber-400 shadow-2xl backdrop-blur-md flex flex-col items-center gap-3 animate-in fade-in zoom-in-95">
              <div className="text-sm font-black text-white flex items-center justify-between w-full">
                <span className="flex items-center gap-1.5">
                  <span className="text-base">🌈</span>
                  <span>請指定變色牌顏色 (限時 6 秒)</span>
                </span>
                <TurnTimerCircle turnStartTime={turnStartTime} duration={turnDuration || 6} isLocal />
              </div>

              <div className="text-[11px] text-amber-200/90 text-center px-2">
                超時未選將自動以你手中最多顏色的牌出發！
              </div>

              <div className="grid grid-cols-2 gap-2.5 w-64">
                <button
                  type="button"
                  onClick={() => handleConfirmWildColor('red')}
                  className="py-2.5 px-3 rounded-2xl bg-red-600 hover:bg-red-500 text-white font-black text-xs shadow-lg transition active:scale-95 flex flex-col items-center border border-red-300/40"
                >
                  <span>🔴 紅色 RED</span>
                  <span className="text-[10px] opacity-80 mt-0.5">手中 {myColorCounts.red} 張</span>
                </button>

                <button
                  type="button"
                  onClick={() => handleConfirmWildColor('yellow')}
                  className="py-2.5 px-3 rounded-2xl bg-yellow-500 hover:bg-yellow-400 text-black font-black text-xs shadow-lg transition active:scale-95 flex flex-col items-center border border-yellow-300/40"
                >
                  <span>🟡 黃色 YELLOW</span>
                  <span className="text-[10px] opacity-80 mt-0.5">手中 {myColorCounts.yellow} 張</span>
                </button>

                <button
                  type="button"
                  onClick={() => handleConfirmWildColor('green')}
                  className="py-2.5 px-3 rounded-2xl bg-green-600 hover:bg-green-500 text-white font-black text-xs shadow-lg transition active:scale-95 flex flex-col items-center border border-green-300/40"
                >
                  <span>🟢 綠色 GREEN</span>
                  <span className="text-[10px] opacity-80 mt-0.5">手中 {myColorCounts.green} 張</span>
                </button>

                <button
                  type="button"
                  onClick={() => handleConfirmWildColor('blue')}
                  className="py-2.5 px-3 rounded-2xl bg-blue-600 hover:bg-blue-500 text-white font-black text-xs shadow-lg transition active:scale-95 flex flex-col items-center border border-blue-300/40"
                >
                  <span>🔵 藍色 BLUE</span>
                  <span className="text-[10px] opacity-80 mt-0.5">手中 {myColorCounts.blue} 張</span>
                </button>
              </div>
            </div>
          )}

        </div>
      </main>

      {/* Game Log Drawer */}
      {showLogDrawer && (
        <div className="fixed inset-y-0 right-0 z-50 w-full sm:w-80 bg-[#071626]/95 border-l border-emerald-500/20 shadow-2xl p-4 backdrop-blur-md flex flex-col animate-fade-in">
          <div className="flex items-center justify-between pb-3 border-b border-emerald-500/20 mb-3">
            <div className="font-bold text-white text-sm flex items-center gap-1.5">
              <History className="w-4 h-4 text-amber-400" />
              對局歷史紀錄
            </div>
            <button
              type="button"
              onClick={() => setShowLogDrawer(false)}
              className="p-1 rounded-lg hover:bg-white/10 text-gray-400 hover:text-white"
            >
              <X className="w-4 h-4" />
            </button>
          </div>

          <div className="flex-1 overflow-y-auto space-y-2 pr-1 text-xs">
            {log.length === 0 ? (
              <div className="text-gray-400 text-center py-6">尚無紀錄</div>
            ) : (
              log.map((item, idx) => (
                <div key={idx} className="p-2 rounded-lg bg-black/40 border border-white/10">
                  <span className="text-[10px] text-gray-400 block">{item.time}</span>
                  <span className="text-gray-200">{item.text}</span>
                </div>
              ))
            )}
          </div>
        </div>
      )}
    </div>
  );
}

`

---

## src/components/CardView.jsx

`javascript
// CardView.jsx - 3D Modern UNO Card Renderer
import React, { useState } from 'react';

export function CardView({
  card,
  isPlayable = false,
  isSmall = false,
  isBack = false,
  isTopCard = false,
  onClick,
  style = {},
  className = ''
}) {
  const [imgError, setImgError] = useState(false);

  let assetKey = 'card_back';
  if (!isBack && card) {
    if (card.color === 'wild') {
      // In hand, Wild cards MUST ALWAYS be pristine uncolored (wild or wild_draw4)!
      // ONLY the active topCard on the table's discard pile shows the chosen color variant.
      if (isTopCard && card.chosenColor) {
        assetKey = card.value === 'wild_draw4' ? `wild_draw4_${card.chosenColor}` : `wild_${card.chosenColor}`;
      } else {
        assetKey = card.value === 'wild_draw4' ? 'wild_draw4' : 'wild';
      }
    } else {
      assetKey = card.displayAssetKey || card.assetKey || 'card_back';
    }
  }

  const imgSrc = `/cards_modern/${assetKey}.png`;

  const sizeClasses = isSmall
    ? 'w-10 h-14 sm:w-12 sm:h-16 rounded-md'
    : 'w-20 h-30 sm:w-24 sm:h-36 md:w-28 md:h-42 rounded-xl';

  const playableClasses = isPlayable
    ? 'ring-2 ring-amber-300 shadow-[0_0_16px_rgba(251,191,36,0.6)] -translate-y-2.5'
    : '';

  return (
    <div
      onClick={onClick}
      style={style}
      className={`relative select-none transition-all duration-200 transform-gpu ${sizeClasses} ${playableClasses} ${onClick ? 'cursor-pointer' : ''} ${className}`}
    >
      {!imgError ? (
        <img
          src={imgSrc}
          alt={assetKey}
          onError={() => setImgError(true)}
          className="w-full h-full object-contain pointer-events-none drop-shadow-md"
          loading="eager"
        />
      ) : (
        // Fallback CSS card in case of unexpected image issue
        <div
          className={`w-full h-full flex flex-col items-center justify-center font-bold text-white border-2 border-white/20 ${sizeClasses}`}
          style={{
            backgroundColor:
              card?.color === 'red' ? '#ef4444' :
              card?.color === 'blue' ? '#3b82f6' :
              card?.color === 'green' ? '#22c55e' :
              card?.color === 'yellow' ? '#eab308' : '#1f2937'
          }}
        >
          <span className="text-sm sm:text-base">{card?.value || 'UNO'}</span>
        </div>
      )}
    </div>
  );
}

`

---

## src/components/VictoryModal.jsx

`javascript
// VictoryModal.jsx - Victory Celebration Modal with Multi-round Match Scoring & Lobby Return
import React, { useEffect } from 'react';
import confetti from 'canvas-confetti';
import { Trophy, RotateCcw, Home, Crown, ArrowRight, LayoutDashboard, Sparkles } from 'lucide-react';

export function VictoryModal({
  winner,
  isHost,
  players = [],
  targetScore = 500,
  isMatchOver = false,
  matchWinner = null,
  lastRoundPoints = 0,
  onNextRound,
  onReturnToLobby,
  onRestart,
  onLeave
}) {
  useEffect(() => {
    try {
      const duration = 2.8 * 1000;
      const animationEnd = Date.now() + duration;
      const interval = setInterval(() => {
        const timeLeft = animationEnd - Date.now();
        if (timeLeft <= 0) {
          return clearInterval(interval);
        }
        confetti({
          startVelocity: 35,
          spread: 360,
          ticks: 70,
          origin: { x: Math.random(), y: Math.random() - 0.2 }
        });
      }, 250);
      return () => clearInterval(interval);
    } catch {
      // Confetti fallback
    }
  }, [isMatchOver]);

  const is2v2Win = !!winner?.teamName;
  const sortedPlayers = [...players].sort((a, b) => (b.score || 0) - (a.score || 0));

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/85 backdrop-blur-md animate-fade-in">
      <div className="w-full max-w-lg bg-[#0e2a1b] border-2 border-amber-400 rounded-3xl shadow-2xl p-6 sm:p-8 text-center relative overflow-hidden">
        {/* Ambient Glow */}
        <div className="absolute -top-24 left-1/2 -translate-x-1/2 w-56 h-56 bg-amber-400/20 rounded-full blur-3xl pointer-events-none" />

        {/* Trophy Avatar */}
        <div className="w-16 h-16 sm:w-20 sm:h-20 mx-auto mb-4 rounded-full bg-amber-400/20 border-2 border-amber-400 flex items-center justify-center shadow-[0_0_30px_rgba(244,196,48,0.4)]">
          {isMatchOver ? (
            <Crown className="w-9 h-9 sm:w-11 sm:h-11 text-amber-300 animate-bounce" />
          ) : (
            <Trophy className="w-8 h-8 sm:w-10 sm:h-10 text-amber-300 animate-bounce" />
          )}
        </div>

        {/* Title Header */}
        <div className="text-xs uppercase tracking-widest text-amber-300 font-extrabold mb-1">
          {isMatchOver
            ? '🏆 賽事總冠軍誕生 (MATCH CHAMPION)'
            : is2v2Win
            ? '2V2 雙人隊伍本局獲勝'
            : '本局對戰結束 (ROUND COMPLETE)'}
        </div>

        <h2 className="text-2xl sm:text-3xl font-black text-white mb-2">
          {isMatchOver
            ? `🎉 【${matchWinner?.teamName || matchWinner?.name}】奪得總冠軍！`
            : is2v2Win
            ? `🎉 【${winner.teamName}】本局獲勝！`
            : winner
            ? `🎉 【${winner.name}】本局獲勝！`
            : '遊戲結束！'}
        </h2>

        <p className="text-xs sm:text-sm text-emerald-300/80 mb-5">
          {isMatchOver
            ? `累計積分達到 ${matchWinner?.score} 分（賽事目標 ${targetScore} 分），登頂總冠軍榮耀！`
            : `率先出清手牌，本局斬獲 +${lastRoundPoints || 0} 結算積分！`}
        </p>

        {/* Match Leaderboard & Score Progress */}
        <div className="bg-[#081a10] border border-emerald-500/20 rounded-2xl p-3.5 mb-6 text-left">
          <div className="flex items-center justify-between text-[11px] font-bold text-emerald-400/90 mb-2 px-1">
            <span>賽事累計積分榜 (LEADERBOARD)</span>
            {targetScore > 0 && <span>目標：{targetScore} 分</span>}
          </div>

          <div className="divide-y divide-emerald-500/10">
            {sortedPlayers.map((p, idx) => {
              const isRoundWinner = is2v2Win ? p.teamId === winner?.teamId : winner && p.id === winner.id;
              const isGrandChampion = isMatchOver && (p.id === matchWinner?.id || (matchWinner?.teamId && p.teamId === matchWinner.teamId));
              const progressPct = targetScore > 0 ? Math.min(100, Math.round(((p.score || 0) / targetScore) * 100)) : 0;

              return (
                <div key={p.id} className="py-2.5 px-2 flex flex-col gap-1.5">
                  <div className="flex items-center justify-between text-xs sm:text-sm">
                    <div className="flex items-center gap-2">
                      <span className="font-mono text-xs text-emerald-400/60 font-bold">#{idx + 1}</span>
                      <span className={`font-bold flex items-center gap-1.5 ${isGrandChampion ? 'text-amber-300' : isRoundWinner ? 'text-emerald-200' : 'text-gray-300'}`}>
                        <span>{p.name}</span>
                        {p.teamName && (
                          <span className="text-[10px] px-1.5 py-0.2 rounded bg-white/10 text-gray-300">
                            {p.teamName.slice(0, 2)}
                          </span>
                        )}
                        {isGrandChampion ? '👑' : isRoundWinner ? '✨' : ''}
                      </span>
                    </div>

                    <div className="flex items-center gap-3">
                      <span className="text-[11px] text-gray-400">
                        剩 {p.cardCount} 張牌
                      </span>
                      <span className="font-mono text-amber-400 font-extrabold text-sm">
                        {p.score || 0} 分
                      </span>
                    </div>
                  </div>

                  {/* Score Progress Bar (Only when targetScore > 0) */}
                  {targetScore > 0 && (
                    <div className="w-full bg-black/50 h-2 rounded-full overflow-hidden border border-emerald-500/20">
                      <div
                        className={`h-full transition-all duration-700 rounded-full ${
                          isGrandChampion
                            ? 'bg-gradient-to-r from-amber-400 to-yellow-300'
                            : 'bg-gradient-to-r from-emerald-500 to-teal-400'
                        }`}
                        style={{ width: `${progressPct}%` }}
                      />
                    </div>
                  )}
                </div>
              );
            })}
          </div>
        </div>

        {/* Action Controls */}
        <div className="flex flex-col sm:flex-row gap-2.5">
          {isHost ? (
            <>
              {isMatchOver ? (
                <>
                  <button
                    type="button"
                    onClick={onReturnToLobby}
                    className="flex-1 py-3 px-4 bg-gradient-to-r from-amber-500 to-amber-400 hover:from-amber-400 hover:to-amber-300 text-black font-extrabold text-xs sm:text-sm rounded-xl shadow-lg shadow-amber-500/20 active:translate-y-0.5 transition flex items-center justify-center gap-1.5"
                  >
                    <LayoutDashboard className="w-4 h-4" />
                    結算回傳大廳
                  </button>
                  <button
                    type="button"
                    onClick={onRestart}
                    className="py-3 px-4 bg-emerald-950/80 hover:bg-emerald-900 text-emerald-300 border border-emerald-500/30 text-xs sm:text-sm font-bold rounded-xl transition flex items-center justify-center gap-1.5"
                  >
                    <RotateCcw className="w-4 h-4 text-amber-300" />
                    新賽事重開
                  </button>
                </>
              ) : (
                <>
                  <button
                    type="button"
                    onClick={onNextRound}
                    className="flex-1 py-3 px-4 bg-gradient-to-r from-amber-500 to-amber-400 hover:from-amber-400 hover:to-amber-300 text-black font-extrabold text-xs sm:text-sm rounded-xl shadow-lg shadow-amber-500/20 active:translate-y-0.5 transition flex items-center justify-center gap-1.5"
                  >
                    <Sparkles className="w-4 h-4" />
                    進行下一局 (Next Round)
                  </button>
                  <button
                    type="button"
                    onClick={onReturnToLobby}
                    className="py-3 px-4 bg-emerald-950/80 hover:bg-emerald-900 text-emerald-300 border border-emerald-500/30 text-xs sm:text-sm font-bold rounded-xl transition flex items-center justify-center gap-1.5"
                  >
                    <LayoutDashboard className="w-4 h-4" />
                    回大廳結算
                  </button>
                </>
              )}
            </>
          ) : (
            <div className="flex-1 py-3 px-4 bg-emerald-950/60 border border-emerald-500/30 text-emerald-300 text-xs font-semibold rounded-xl flex items-center justify-center gap-1.5">
              等待房主開啟下一局或返回大廳...
            </div>
          )}

          <button
            type="button"
            onClick={onLeave}
            className="py-3 px-4 bg-emerald-900/40 hover:bg-emerald-800/60 text-emerald-300 border border-emerald-500/30 text-xs sm:text-sm font-semibold rounded-xl transition flex items-center justify-center gap-1.5"
          >
            <Home className="w-4 h-4" />
            返回首頁
          </button>
        </div>
      </div>
    </div>
  );
}

`

---

